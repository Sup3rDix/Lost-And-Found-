CampusFind – NORSU Blue/White/Yellow Seven-Section UI Update
=============================================================

This source update implements the approved seven-section reference board
as working JavaFX screens while retaining the original application logic.

01  LOGIN & REGISTRATION
    Transparent, borderless NORSU campus-photo login/registration screens.
    Student registration retains Program/Course and Year Level; no Expected
    Graduation Year field.

02  STUDENT DASHBOARD
    NORSU photo banner; four live statistic tiles; Search Found Items;
    four quick actions; Recent Reports; four-stage My Claim Tracking;
    KITA AI assistance and links to other screens. No placeholder metrics.

03  ADMIN DASHBOARD
    Shared NORSU courtyard banner; live user/report/claim totals;
    Needs Attention; Recent Activity; Campus Hotspots; KITA AI matching;
    additional report analytics and Recent Reports panels.

04  MANAGE USERS & ADMIN FORM
    University banner, real account counts, search and filter chips,
    account table, responsive Assistant Admin form and existing permissions.
    Current student status displays Course and Year Level instead of a
    graduation-year label. Legacy graduation metadata is left in storage
    for existing account-policy compatibility.

05  MESSENGER – BOTH ROLES
    One Messenger layout for Admin and Student: conversation list, search,
    All/Unread/Active/Resolved filters, chat bubbles and working composer.

06  CHAT + LINKED ITEM DETAILS
    When a conversation is selected, its linked report photo, title, status,
    location, reporter, date and an Open Item action are shown on the right.
    On smaller windows this panel hides; the View Item button remains.

07  REPORT / BROWSE / CLAIMS
    Branded Browse gallery with section/status filters and quick actions;
    report wizard retains validation and ownership verification; My Reports
    and My Claims have dedicated Student navigation options.

KITA AI remains available in the app. The old green KITA design was
removed from the reference board, not from application functionality.

Run on Windows 11 (JDK 21 required)
-----------------------------------
1. Extract the ZIP.
2. Open PowerShell inside the extracted CampusFind folder (where pom.xml is).
3. Run:  .\mvnw.cmd clean javafx:run

Testing and scope
-----------------
All 17 Java source files were syntax-parsed using JDK 21, the source
is UTF-8 without BOM, and the ZIP is integrity-checked. A full Maven
compile and JavaFX GUI run could not be performed in the build environment
because JavaFX dependencies were unavailable. Please verify layout and
behaviour on Windows and send any compilation/runtime error lines.

Messenger currently saves conversations locally. Different-computer live
messaging, online presence, real-time push and cloud synchronization need
a shared backend; this UI update does NOT claim to provide those services.

No sample user accounts, messages or report statistics are injected by this
update. The original source project is preserved outside this ZIP.

CampusFind — NORSU Courtyard Welcome Header Fix

Changes
- Updated the single campusBanner(boolean) helper in main.java.
- Both Admin and Student dashboards now use the NORSU courtyard photo in a real ImageView.
- Added wide-banner photo cropping without stretching, a navy gradient overlay,
  a curved yellow bottom accent, and rounded clipping.
- Kept dashboard labels, accounts, report/claim logic, and authentication untouched.

Run in Windows PowerShell from the CampusFind folder:
  .\mvnw.cmd clean javafx:run

The exact final appearance should be checked on Windows using JavaFX.

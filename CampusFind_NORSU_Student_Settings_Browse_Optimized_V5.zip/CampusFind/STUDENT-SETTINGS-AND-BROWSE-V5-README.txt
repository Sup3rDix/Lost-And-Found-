CAMPUSFIND / NORSU - STUDENT SETTINGS + BROWSE PERFORMANCE V5
==============================================================

This copy is based on the supplied CampusFind_NORSU_Compact_Settings_V4_Admin_Student(1).zip.
The original ZIP was not changed. Existing account, report, claim and local-data
file formats remain unchanged.

1. APPROVED STUDENT SETTINGS DESIGN
-----------------------------------
* Select STUDENT > Settings to see the compact Profile & Academic editor.
* Two-column desktop layout: profile/photo and editable form on the left,
  Academic Overview and Profile Completeness on the right.
* Current form values and overview cards update as you type; completion is
  calculated from actual profile fields rather than a fixed 100% label.
* Change Photo, Reset, and Save Changes are functional.
* Changing name or email still requires your CURRENT password. The password
  box appears only when name/email differ from saved values.
* Existing data validation, local account saving, and Manage Users visibility
  remain intact. Photo changes save immediately; Reset resets form inputs only.
* Other options are still available via the new "Notifications, Privacy &
  Preferences" button (opens the previous compact settings menu).
* The editor is sized for desktop windows without scrolling. When the window is
  too small or Windows text scaling is large, scrolling remains available so
  fields and action buttons are never clipped.

2. BROWSE ITEMS OPTIMIZATION
----------------------------
* Only 12 item cards are created per visible page.
* Page numbers, Previous and Next controls, and a showing N-M count.
* Search uses a 275ms debounce while typing.
* Existing Available/Unresolved, Claims in Progress, Recovered, type, category,
  date, sort and status filters are retained; a filter change resets to page 1.
* Claim statuses are calculated in one pass per refresh instead of rescanning
  every claim for every item.
* Sort ties use a precomputed item position map instead of source.indexOf()
  inside each comparator call.
* Expensive matching calculations no longer run for every Browse card; matching
  still exists in KITA AI and item details.
* Stored report photos are read at a bounded size (1000x1000 maximum), and
  image load can happen in the background with a viewport update on completion.
* Report records and photos are not deleted, and no data migration is needed.

3. HOW TO RUN (WINDOWS 11)
--------------------------
* Extract the ZIP, then open the CampusFind folder in PowerShell.
* Ensure Java JDK 21 is installed and java -version reports 21.
* Run:  .\mvnw.cmd clean javafx:run
* If Maven needs dependencies for the first time, keep an internet connection.
* If you use the Run-CampusFind.cmd launcher, it remains included.

4. RECOMMENDED TESTS
--------------------
* Student > Settings: edit course, year and section; Reset; Save Changes.
* Try changing name/email with a wrong password (must be rejected), then with
  the correct password; verify Admin > Manage Users shows the saved profile.
* Change a photo after typing in the form and check that inputs are preserved.
* Open Notifications/Privacy/Preferences and verify the original pages work.
* Browse Items: change status, category and date filters; page through results.
* Check first, middle and final pages with 100, 500 and 1000 sample reports.
* Search quickly; the gallery should refresh after a short typing pause.
* Confirm actions/claims still work after returning from item details.
* Test at your display resolution, and again at a narrower window.

5. TEST STATUS / CAPACITY
------------------------
All 17 Java source files were parsed successfully using JDK 21's Java compiler
parser (zero syntax diagnostics). A live JavaFX build/run and interaction tests
could not be performed here because Maven and JavaFX dependencies are not
installed in this execution environment. Runtime behavior and the exact visual
fit should be checked on your Windows 11 machine.

This release improves Browse UI scaling; it is NOT a shared multi-computer
backend. CampusFind still stores reports locally on each computer. Automatic
synchronization between many students' PCs requires a separate shared database
and server/backend design.

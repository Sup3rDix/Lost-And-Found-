CampusFind - fixed appearance edition

Changes:
- Removed Appearance/theme controls from Student Profile and Admin Settings.
- Removed account color picker, presets and light/dark selectors.
- Removed message-chat theme selector; kept messaging functional.
- Both roles now use the same fixed Emerald/cream styling.
- Preserved other preferences (notifications, KITA mascot, AI suggestions).
- Did not change login layout, user records, reporting, claims, or other application functions.

Run on Windows:
  cd CampusFind
  .\mvnw.cmd javafx:run

Note: Maven and JavaFX dependencies may need to download on first run.

module com.example.campuslostandfounditem {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.prefs;

    opens com.example.campuslostandfounditem to javafx.fxml;
    exports com.example.campuslostandfounditem;
}
package com.example.campuslostandfounditem;

public enum ItemType {
    LOST,
    FOUND
}
package com.example.campuslostandfounditem;

import javafx.scene.paint.Color;

final class CampusStyle {
    private CampusStyle() {}

    static void install(javafx.scene.Parent root) {
        String sheet = Theme.class.getResource("campus.css").toExternalForm();
        if (!root.getStylesheets().contains(sheet)) root.getStylesheets().add(sheet);
        root.getStyleClass().removeAll("campus-dark", "campus-light");
        root.getStyleClass().add(Theme.dark ? "campus-dark" : "campus-light");
        root.setStyle(root.getStyle() + " -cf-accent: " + Theme.BLUE + "; -cf-on-accent: " + Theme.onAccent + ";");
    }

    /** #rrggbb text of a color */
    public static String hex(Color c) {
        return String.format("#%02x%02x%02x",
                (int) Math.round(c.getRed() * 255),
                (int) Math.round(c.getGreen() * 255),
                (int) Math.round(c.getBlue() * 255));
    }
}
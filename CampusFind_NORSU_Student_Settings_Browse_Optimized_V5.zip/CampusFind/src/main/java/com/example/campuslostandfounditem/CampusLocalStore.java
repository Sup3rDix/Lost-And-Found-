package com.example.campuslostandfounditem;

import java.io.*;
import java.nio.file.*;

/** Local-only data storage. No network synchronization is implied. */
final class CampusLocalStore {
    private CampusLocalStore() {}
    private static final Path FOLDER = Path.of(System.getProperty("user.home"), ".campusfind");
    private static final Path ACCOUNTS = FOLDER.resolve("accounts.dat");
    private static final Path DATA = FOLDER.resolve("campus-data.dat");

    /** Keep selected report photos inside the local profile so they survive moving the original. */
    static String keepPhoto(java.io.File selected) throws IOException {
        Path media = FOLDER.resolve("media");
        Files.createDirectories(media);
        String filename = selected.getName().toLowerCase();
        String suffix = filename.endsWith(".png") ? ".png" : filename.endsWith(".gif") ? ".gif" : ".jpg";
        Path destination = media.resolve(java.util.UUID.randomUUID() + suffix);
        Files.copy(selected.toPath(), destination);
        return destination.toUri().toString();
    }

    /** Copy both local data files to a dated folder selected by the main administrator. */
    static Path backupTo(Path destination) throws IOException {
        if (!Files.isDirectory(destination)) throw new IOException("Choose an existing folder.");
        Path folder = destination.resolve("CampusFind-Backup-" + java.time.LocalDateTime.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")));
        Files.createDirectory(folder);
        if (Files.isRegularFile(ACCOUNTS)) {
            Files.copy(ACCOUNTS, folder.resolve("accounts.dat"));
        }
        if (Files.isRegularFile(DATA)) {
            Files.copy(DATA, folder.resolve("campus-data.dat"));
        }
        Path media = FOLDER.resolve("media");
        if (Files.isDirectory(media)) {
            Path target = folder.resolve("media");
            Files.createDirectory(target);
            try (java.util.stream.Stream<Path> files = Files.list(media)) {
                for (Path original : (Iterable<Path>) files::iterator) {
                    if (Files.isRegularFile(original)) Files.copy(original, target.resolve(original.getFileName()));
                }
            }
        }
        return folder;
    }

    static Object loadAccounts() { return load(ACCOUNTS); }
    static void saveAccounts(Object accounts) { save(ACCOUNTS, accounts); }
    static Object loadData() { return load(DATA); }
    static void saveData(Object data) { save(DATA, data); }

    private static Object load(Path path) {
        if (!Files.isRegularFile(path)) return null;
        try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(path))) {
            in.setObjectInputFilter(ObjectInputFilter.Config.createFilter(
                    "maxdepth=64;maxrefs=100000;maxbytes=30000000;java.base/*;com.example.campuslostandfounditem.*;!*"));
            return in.readObject();
        } catch (IOException | ClassNotFoundException | SecurityException e) {
            System.err.println("CampusFind: unable to read local data at " + path + ": " + e.getMessage());
            return null;
        }
    }

    private static void save(Path target, Object content) {
        try {
            Files.createDirectories(FOLDER);
            Path temp = Files.createTempFile(FOLDER, "campusfind-", ".tmp");
            try {
                try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(temp))) {
                    out.writeObject(content);
                }
                try {
                    Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE,
                            StandardCopyOption.REPLACE_EXISTING);
                } catch (AtomicMoveNotSupportedException ex) {
                    Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
                }
            } finally {
                Files.deleteIfExists(temp);
            }
        } catch (IOException | SecurityException e) {
            System.err.println("CampusFind: unable to save local data at " + target + ": " + e.getMessage());
        }
    }
}

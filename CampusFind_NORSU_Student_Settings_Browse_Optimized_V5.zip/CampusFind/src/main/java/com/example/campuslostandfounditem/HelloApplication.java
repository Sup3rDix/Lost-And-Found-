package com.example.campuslostandfounditem;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.SVGPath;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class HelloApplication extends Application {

    private static final String DARK_TEXT = "-cf-ink";
    private static final String FIELD = "-fx-background-color: transparent; -fx-padding: 8 0 8 0;";

    // icons (Material design paths, 24 x 24)
    private static final String ICON_MAIL = "M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z";
    private static final String ICON_LOCK = "M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z";
    private static final String ICON_EYE = "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z";
    private static final String ICON_PERSON = "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z";
    private static final String ICON_PEOPLE = "M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z";

    // shown on the login page after a successful registration
    private String loginNotice;

    @Override
    public void start(Stage stage) {
        stage.setTitle("CampusFind - Lost and Found");
        stage.getIcons().add(new javafx.scene.image.Image(HelloApplication.class.getResource("icon.png").toExternalForm()));
        showLogin(stage);
        stage.show();
    }

    @Override
    public void stop() {
        main.persist();
        UserService.saveAccounts();
    }

    // =====================================================
    // SMALL HELPERS
    // =====================================================
    private static SVGPath svg(String content, double size, String color) {
        SVGPath p = new SVGPath();
        p.setContent(content);
        p.setFill(Color.web(color));
        double sc = size / 24.0;
        p.setScaleX(sc);
        p.setScaleY(sc);
        return p;
    }

    // CampusFind logo: white circle, purple magnifying glass with a graduation cap inside
    static StackPane makeLogo(double size) {
        return makeLogo(size, "#1559c8");
    }

    private static StackPane makeLogo(double size, String c) {
        double s = size / 100.0;

        Pane p = new Pane();
        p.setMinSize(size, size);
        p.setPrefSize(size, size);
        p.setMaxSize(size, size);



        Line handle = new Line(60 * s, 60 * s, 82 * s, 82 * s);
        handle.setStroke(Color.web(c));
        handle.setStrokeWidth(9 * s);
        handle.setStrokeLineCap(StrokeLineCap.ROUND);

        Circle lens = new Circle(44 * s, 44 * s, 23 * s, Color.web(c, 0.10));
        lens.setStroke(Color.web(c));
        lens.setStrokeWidth(7 * s);

        Polygon base = new Polygon(34 * s, 42 * s, 34 * s, 50 * s, 44 * s, 55 * s, 54 * s, 50 * s, 54 * s, 42 * s);
        base.setFill(Color.web(Theme.mix(c, "#ffffff", 0.35)));
        Polygon board = new Polygon(44 * s, 32 * s, 60 * s, 39 * s, 44 * s, 46 * s, 28 * s, 39 * s);
        board.setFill(Color.web(c));

        Line tassel = new Line(58 * s, 40.5 * s, 58 * s, 49 * s);
        tassel.setStroke(Color.web(c));
        tassel.setStrokeWidth(2 * s);
        tassel.setStrokeLineCap(StrokeLineCap.ROUND);

        p.getChildren().addAll(handle, lens, base, board, tassel);
        return new StackPane(p);
    }

    private String buttonStyle(String color) {
        return "-fx-background-color: " + color + "; -fx-text-fill: " + Theme.foreground(color) + "; -fx-font-size: 15px; "
                + "-fx-font-weight: bold; -fx-background-radius: 14; -fx-padding: 10; -fx-cursor: hand;";
    }

    private Button primaryButton(String text) {
        Button b = new Button(text);
        b.setMaxWidth(Double.MAX_VALUE);
        b.setDefaultButton(true);
        b.getStyleClass().add("auth-primary-button");
        return b;
    }

    private Label link(String text, Runnable action) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: #ffde73; -fx-font-weight: bold;");
        l.setCursor(javafx.scene.Cursor.HAND);
        l.setFocusTraversable(true);
        l.setAccessibleRole(javafx.scene.AccessibleRole.HYPERLINK);
        l.setOnKeyPressed(e -> { if (e.getCode() == javafx.scene.input.KeyCode.ENTER) action.run(); });
        l.setOnMouseClicked(e -> action.run());
        return l;
    }

    private Label heading(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("editorial-title");
        l.setStyle("-fx-font-size: 40px; -fx-text-fill: white;");
        return l;
    }

    private Label subText(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: rgba(255,255,255,0.84);");
        return l;
    }

    private Label labelText(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: rgba(255,255,255,0.86);");
        return l;
    }


    private Label errorLabel() {
        Label l = new Label();
        l.setWrapText(true);
        l.setStyle("-fx-text-fill: #ffd6d6; -fx-font-weight: bold;");
        return l;
    }

    // rounded grey box with an icon on the left (and optional extra node on the right)
    private HBox fieldBox(String icon, Node input, Node... extra) {
        HBox h = new HBox(10);
        h.getChildren().addAll(new Group(svg(icon, 18, "#f9fbff")), input);
        h.getChildren().addAll(extra);
        HBox.setHgrow(input, Priority.ALWAYS);
        h.setAlignment(Pos.CENTER_LEFT);
        h.setPadding(new Insets(1, 14, 1, 14));
        h.getStyleClass().add("auth-field");
        h.setMinHeight(44);
        h.setPrefHeight(46);
        h.setMaxWidth(Double.MAX_VALUE);
        return h;
    }

    private TextField input(String prompt) {
        TextField t = new TextField();
        t.setPromptText(prompt);
        t.setStyle(FIELD);
        t.setMaxWidth(Double.MAX_VALUE);
        return t;
    }

    // password field with a lock icon and an eye to show / hide it
    private HBox passRow(PassBox pb) {
        StackPane holder = new StackPane(pb.pass, pb.text);
        Button eye = new Button();
        eye.setStyle("-fx-background-color: transparent;");
        eye.setAccessibleText("Show or hide password");
        eye.setGraphic(new Group(svg(ICON_EYE, 18, "#ffffff")));
        eye.setCursor(javafx.scene.Cursor.HAND);
        eye.setOnAction(e -> pb.show.setSelected(!pb.show.isSelected()));
        return fieldBox(ICON_LOCK, holder, eye);
    }

    private VBox labeled(String label, Node field) {
        Label l = new Label(label);
        l.setStyle("-fx-font-weight: bold; -fx-font-size: 13px; -fx-text-fill: rgba(255,255,255,0.96);");
        return new VBox(4, l, field);
    }

    // a password box: two fields (hidden / shown) + a check that switches them
    private static class PassBox {
        final PasswordField pass = new PasswordField();
        final TextField text = new TextField();
        final CheckBox show = new CheckBox();

        PassBox(String prompt) {
            pass.setPromptText(prompt);
            text.setPromptText(prompt);
            pass.setStyle(FIELD);
            text.setStyle(FIELD);
            text.textProperty().bindBidirectional(pass.textProperty());
            text.managedProperty().bind(text.visibleProperty());
            pass.managedProperty().bind(pass.visibleProperty());
            text.setVisible(false);
            show.selectedProperty().addListener((o, a, selected) -> {
                text.setVisible(selected);
                pass.setVisible(!selected);
            });
        }

        String get() {
            return pass.getText();
        }
    }

    private Label noticeLabel() {
        Label notice = new Label();
        notice.setWrapText(true);
        if (loginNotice != null) {
            notice.setText(loginNotice);
            notice.setStyle("-fx-text-fill: #ffefaa; -fx-font-weight: bold;");
            loginNotice = null;
        }
        notice.setManaged(!notice.getText().isEmpty());
        notice.setVisible(!notice.getText().isEmpty());
        return notice;
    }

    // The photo remains the full page. The transparent form has no card fill or
    // border; a feathered, full-screen tint supplies contrast without a box edge.
    private void showCard(Stage stage, VBox form) {
        form.setSpacing(11);
        form.setPadding(new Insets(14, 20, 22, 20));
        form.setAlignment(Pos.CENTER);
        form.setPrefWidth(490);
        form.setMaxWidth(530);
        form.setMinWidth(0);
        form.getStyleClass().add("auth-floating-form");

        ImageView officialSeal = new ImageView(new Image(
                HelloApplication.class.getResource("norsu-official-seal.png").toExternalForm()));
        officialSeal.setFitWidth(78);
        officialSeal.setFitHeight(78);
        officialSeal.setPreserveRatio(true);
        officialSeal.setSmooth(true);

        Label campusWord = new Label("Campus");
        campusWord.setStyle("-fx-text-fill: white; -fx-font-size: 32px; -fx-font-weight: bold;");
        Label findWord = new Label("Find");
        findWord.setStyle("-fx-text-fill: #ffcf24; -fx-font-size: 32px; -fx-font-weight: bold;");
        HBox wordmark = new HBox(0, campusWord, findWord);
        wordmark.setAlignment(Pos.CENTER);
        HBox brand = new HBox(8, makeLogo(43, "#ffcf24"), wordmark);
        brand.setAlignment(Pos.CENTER);

        Label caption = new Label("Campus Lost & Found");
        caption.setStyle("-fx-text-fill: white; -fx-font-size: 15px; -fx-font-weight: bold;");
        Label university = new Label("NEGROS ORIENTAL STATE UNIVERSITY");
        university.setStyle("-fx-text-fill: #f9fcff; -fx-font-size: 11px; -fx-font-weight: bold;");
        VBox header = new VBox(3, officialSeal, brand, caption, university);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(0, 0, 13, 0));
        form.getChildren().add(0, header);

        // The real selected image is visible edge to edge; the soft overlay is
        // also full-screen, so there can be no rectangular blur boundary.
        CampusPhoto photo = new CampusPhoto();
        CampusPhoto softPhoto = new CampusPhoto();
        softPhoto.setEffect(new GaussianBlur(12));
        softPhoto.setOpacity(0.28);
        softPhoto.setMouseTransparent(true);

        StackPane imageLayer = new StackPane(photo);
        imageLayer.setMinSize(0, 0);
        Rectangle tint = new Rectangle();
        tint.setMouseTransparent(true);
        tint.setFill(new RadialGradient(0, 0, .5, .49, .77, true,
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.rgb(0, 24, 78, .77)),
                new Stop(.52, Color.rgb(0, 27, 77, .51)),
                new Stop(1, Color.rgb(0, 25, 66, .27))));

        StackPane cardHost = new StackPane(form);
        cardHost.setAlignment(Pos.CENTER);
        cardHost.setPadding(new Insets(20, 22, 30, 22));
        cardHost.setMinSize(0, 0);

        ScrollPane scroll = new ScrollPane(cardHost);
        scroll.setFitToWidth(true);
        scroll.setFitToHeight(true);
        scroll.getStyleClass().add("auth-scroll");
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scroll.setPannable(true);
        scroll.setStyle("-fx-background-color: transparent; -fx-background: transparent; -fx-border-color: transparent;");

        // The fine yellow-and-blue waves in the design are decorative only.
        Canvas waves = new Canvas();
        waves.setHeight(72);
        waves.setMouseTransparent(true);
        waves.widthProperty().addListener((obs, oldVal, newVal) -> drawAuthWaves(waves));
        StackPane.setAlignment(waves, Pos.BOTTOM_CENTER);

        Button change = photo.changeButton(softPhoto);
        change.getStyleClass().add("auth-photo-action");
        StackPane.setAlignment(change, Pos.BOTTOM_LEFT);
        StackPane.setMargin(change, new Insets(0, 0, 17, 18));

        StackPane root = new StackPane(imageLayer, softPhoto, tint, waves, scroll, change);
        root.setStyle("-fx-background-color: #062a72;");
        photo.prefWidthProperty().bind(root.widthProperty());
        photo.prefHeightProperty().bind(root.heightProperty());
        softPhoto.prefWidthProperty().bind(root.widthProperty());
        softPhoto.prefHeightProperty().bind(root.heightProperty());
        tint.widthProperty().bind(root.widthProperty());
        tint.heightProperty().bind(root.heightProperty());
        waves.widthProperty().bind(root.widthProperty());
        setPage(stage, root);
    }

    private void drawAuthWaves(Canvas canvas) {
        double w = canvas.getWidth();
        double h = canvas.getHeight();
        if (w <= 0) return;
        GraphicsContext g = canvas.getGraphicsContext2D();
        g.clearRect(0, 0, w, h);
        g.setFill(Color.rgb(2, 42, 126, 0.88));
        g.beginPath();
        g.moveTo(0, h * .67);
        g.bezierCurveTo(w * .24, h * .13, w * .54, h * 1.04, w * .76, h * .55);
        g.bezierCurveTo(w * .90, h * .23, w * .95, h * .21, w, h * .08);
        g.lineTo(w, h); g.lineTo(0, h); g.closePath(); g.fill();
        g.setStroke(Color.rgb(255, 207, 33, .98));
        g.setLineWidth(8);
        g.beginPath();
        g.moveTo(0, h * .67);
        g.bezierCurveTo(w * .24, h * .13, w * .54, h * 1.04, w * .76, h * .55);
        g.bezierCurveTo(w * .90, h * .23, w * .95, h * .21, w, h * .08);
        g.stroke();
    }

    private void setPage(Stage stage, javafx.scene.Parent root) {
        CampusStyle.install(root);
        if (stage.getScene() == null) {
            Rectangle2D screen = Screen.getPrimary().getVisualBounds();
            stage.setScene(new Scene(root, Math.min(1220, screen.getWidth() - 20),
                    Math.min(800, screen.getHeight() - 52)));
            stage.setMinWidth(Math.min(880, screen.getWidth() - 16));
            stage.setMinHeight(Math.min(560, screen.getHeight() - 36));
            stage.centerOnScreen();
        } else {
            stage.getScene().setRoot(root);
        }
    }

    private void backToLogin(Stage stage) {
        showLogin(stage);
    }

    // the account decides if the person is a student or an admin (one login for everybody)
    private void attemptLogin(Stage stage, String id, String password, Label msg, boolean remember) {
        UserService.Account acc = UserService.login(id, password);
        if (acc == null) {
            msg.setText("Wrong ID / email or password.");
            return;
        }
        java.util.prefs.Preferences prefs = java.util.prefs.Preferences.userNodeForPackage(HelloApplication.class);
        if (remember) prefs.put("rememberedCampusFindID", id);
        else prefs.remove("rememberedCampusFindID");
        boolean isAdmin = acc.role.equals("Admin");
        CurrentUser.set(acc.name, isAdmin);
        CurrentUser.setProfile(acc.studentId, acc.email);
        Theme.loadFor(acc.studentId);
        main.audit(acc.name, "Logged in", acc.role);
        showMain(stage, isAdmin);
    }

    private String roleOf(String id) {
        for (UserService.Account a : UserService.accounts()) {
            if (a.studentId.equalsIgnoreCase(id)) return a.role;
        }
        return "Student";
    }

    // =====================================================
    // LOGIN  (ONE login page for students and admins)
    // =====================================================
    private void showLogin(Stage stage) {
        Theme.useDefault();

        Label title = heading("Welcome Back!");
        Label subtitle = subText("Sign in to your account");
        VBox titles = new VBox(2, title, subtitle);
        titles.setAlignment(Pos.CENTER);
        Label notice = noticeLabel();

        TextField id = input("Student ID / Email");
        PassBox pb = new PassBox("Password");
        String remembered = java.util.prefs.Preferences.userNodeForPackage(HelloApplication.class)
                .get("rememberedCampusFindID", "");
        id.setText(remembered);
        CheckBox remember = new CheckBox("Remember my ID");
        remember.setSelected(!remembered.isBlank());
        remember.setStyle("-fx-text-fill: white; -fx-font-size: 12px;");
        HBox forgot = new HBox(remember, new Region(),
                link("Forgot password?", () -> showForgot(stage)));
        HBox.setHgrow(forgot.getChildren().get(1), Priority.ALWAYS);
        forgot.setAlignment(Pos.CENTER_LEFT);

        Label msg = errorLabel();
        Button login = primaryButton("Sign In");
        login.setOnAction(e -> attemptLogin(stage, id.getText().trim(), pb.get(), msg,
                remember.isSelected()));

        HBox registerRow = new HBox(6, labelText("Don't have an account?"),
                link("Register", () -> showRegister(stage, "Student")));
        registerRow.setAlignment(Pos.CENTER);

        VBox form = new VBox(14, titles, notice, fieldBox(ICON_MAIL, id), passRow(pb), forgot, msg,
                login, registerRow);
        showCard(stage, form);
    }

    // =====================================================
    // FORGOT PASSWORD
    // =====================================================
    private void showForgot(Stage stage) {
        Theme.useDefault();

        Label title = heading("Reset Password");
        Label subtitle = subText("Confirm who you are and choose a new password");
        VBox titles = new VBox(2, title, subtitle);
        titles.setAlignment(Pos.CENTER);

        TextField id = input("Enter your student ID or admin ID");
        TextField email = input("The email you registered with");
        PassBox pb = new PassBox("New password (at least 6 characters)");
        PassBox cpb = new PassBox("Type the new password again");
        pb.show.selectedProperty().bindBidirectional(cpb.show.selectedProperty());

        // the admin access code only shows up when the ID belongs to an admin
        PassBox codePb = new PassBox("Ask the school for the admin access code");
        VBox codeBox = labeled("Admin Access Code", passRow(codePb));
        codeBox.setVisible(false);
        codeBox.setManaged(false);
        id.textProperty().addListener((o, a, t) -> {
            boolean adm = roleOf(t.trim()).equals("Admin");
            codeBox.setVisible(adm);
            codeBox.setManaged(adm);
        });

        Label error = errorLabel();
        Button reset = primaryButton("Reset Password");
        reset.setOnAction(e -> {
            String err = UserService.resetPassword(roleOf(id.getText().trim()), id.getText().trim(),
                    email.getText().trim(), pb.get(), cpb.get(), codePb.get().trim());
            if (err != null) {
                error.setText(err);
                return;
            }
            loginNotice = "Password updated! You can log in now.";
            backToLogin(stage);
        });

        HBox back = new HBox(6, labelText("Remembered it?"),
                link("Back to login", () -> backToLogin(stage)));
        back.setAlignment(Pos.CENTER);

        VBox form = new VBox(10, titles,
                labeled("Student / Admin ID", fieldBox(ICON_PEOPLE, id)),
                labeled("Email Address", fieldBox(ICON_MAIL, email)),
                labeled("New Password", passRow(pb)),
                labeled("Confirm Password", passRow(cpb)),
                codeBox, error, reset, back);
        showCard(stage, form);
    }

    // =====================================================
    // REGISTER
    // =====================================================
    private void showRegister(Stage stage, String startRole) {
        Theme.useDefault();

        Label title = heading("Create Student Account");
        title.setStyle("-fx-font-size: 28px; -fx-text-fill: white; -fx-font-weight: bold;");
        Label sub = subText("Register as a student to use CampusFind.");
        VBox titles = new VBox(2, title, sub);
        titles.setAlignment(Pos.CENTER);

        TextField fullName = input("Full Name");
        TextField idField = input("Student ID");
        TextField program = input("Program / Course (e.g. BSIT)");
        ComboBox<String> year = new ComboBox<>();
        year.getItems().addAll("1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year");
        year.setPromptText("Year Level");
        year.setMaxWidth(Double.MAX_VALUE);
        year.getStyleClass().add("auth-combo");
        HBox yearRow = fieldBox(ICON_PERSON, year);
        yearRow.setMaxWidth(Double.MAX_VALUE);
        TextField email = input("Email Address");
        PassBox pb = new PassBox("Create a password (at least 6 characters)");
        PassBox cpb = new PassBox("Confirm your password");

        Label error = errorLabel();
        Button register = primaryButton("Register Account");
        register.setOnAction(e -> {
            int level = year.getSelectionModel().getSelectedIndex() + 1;
            String err = UserService.registerStudent(fullName.getText().trim(), idField.getText().trim(),
                    email.getText().trim(), pb.get(), cpb.get(), program.getText().trim(), level);
            if (err != null) {
                error.setText(err);
                return;
            }
            loginNotice = "Account created! You can log in now.";
            backToLogin(stage);
        });

        HBox loginRow = new HBox(6, labelText("Already have an account?"),
                link("Sign In", () -> backToLogin(stage)));
        loginRow.setAlignment(Pos.CENTER);

        VBox form = new VBox(9, titles,
                fieldBox(ICON_PERSON, fullName),
                fieldBox(ICON_PEOPLE, idField),
                fieldBox(ICON_PEOPLE, program),
                yearRow,
                fieldBox(ICON_MAIL, email),
                passRow(pb),
                passRow(cpb),
                error, register, loginRow);
        showCard(stage, form);
    }

    // =====================================================
    // MAIN APP (sized to fit the screen, so the bottom bar is never hidden)
    // =====================================================
    private void showMain(Stage stage, boolean admin) {
        main.rebuild = () -> showMain(stage, admin);
        main view = new main(admin, () -> confirmLogout(stage));

        setPage(stage, view.getRoot());
    }

    // =====================================================
    // LOG OUT (Facebook-style confirm)
    // =====================================================
    private void confirmLogout(Stage owner) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.initStyle(StageStyle.TRANSPARENT);

        Label title = new Label("Log out of your account?");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + DARK_TEXT + ";");
        Label text = new Label("Are you sure you want to log out?");
        text.setWrapText(true);
        text.setStyle("-fx-font-size: 14px; -fx-text-fill: -cf-muted;");

        Button cancel = new Button("Cancel");
        cancel.setCancelButton(true);
        cancel.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-ink; -fx-font-weight: bold; "
                + "-fx-background-radius: 6; -fx-padding: 8 20 8 20; -fx-cursor: hand;");
        cancel.setOnAction(e -> dialog.close());

        Button logout = new Button("Log out");
        logout.setDefaultButton(true);
        logout.setStyle("-fx-background-color: " + Theme.BLUE + "; -fx-text-fill: -cf-on-accent; -fx-font-weight: bold; "
                + "-fx-background-radius: 6; -fx-padding: 8 20 8 20; -fx-cursor: hand;");
        logout.setOnAction(e -> {
            dialog.close();
            main.persist();
            CurrentUser.clear();
            Theme.useDefault();
            showLogin(owner);
        });

        HBox buttons = new HBox(10, cancel, logout);
        buttons.setAlignment(Pos.CENTER_RIGHT);
        VBox.setMargin(buttons, new Insets(12, 0, 0, 0));

        VBox box = new VBox(8, title, text, buttons);
        box.setPadding(new Insets(22));
        box.setPrefWidth(380);
        box.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 12; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.35), 18, 0, 0, 4);");

        StackPane wrapper = new StackPane(box);
        wrapper.setPadding(new Insets(20));
        wrapper.setStyle("-fx-background-color: transparent;");

        CampusStyle.install(wrapper);
        Scene scene = new Scene(wrapper);
        scene.setFill(Color.TRANSPARENT);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
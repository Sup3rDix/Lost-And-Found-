package com.example.campuslostandfounditem;

import java.util.prefs.Preferences;

/** Per-account settings on this computer. These are not cloud-synced. */
final class CampusPreferences {
    boolean notifications = true;
    boolean claimAlerts = true;
    boolean messageAlerts = true;
    boolean matchAlerts = true;
    boolean showMessagePopup = true;
    boolean showMessagePreview = true;
    boolean openUnreadOnLogin = true;
    boolean mascot = true;
    boolean aiSuggestions = true;
    boolean largeText = false;
    private final Preferences node;

    private CampusPreferences(String id) {
        node = Preferences.userRoot().node("CampusFind/settings/account_" + id.toLowerCase()
                .replaceAll("[^a-z0-9_-]", "_"));
        notifications = node.getBoolean("notifications", true);
        claimAlerts = node.getBoolean("claimAlerts", true);
        messageAlerts = node.getBoolean("messageAlerts", true);
        matchAlerts = node.getBoolean("matchAlerts", true);
        showMessagePopup = node.getBoolean("showMessagePopup", true);
        showMessagePreview = node.getBoolean("showMessagePreview", true);
        openUnreadOnLogin = node.getBoolean("openUnreadOnLogin", true);
        mascot = node.getBoolean("mascot", true);
        aiSuggestions = node.getBoolean("aiSuggestions", true);
        largeText = node.getBoolean("largeText", false);
    }

    static CampusPreferences forAccount(String id) { return new CampusPreferences(id == null ? "guest" : id); }
    static CampusPreferences current() { return forAccount(CurrentUser.getStudentId()); }
    static int unclaimedMonths() {
        return Preferences.userRoot().node("CampusFind/settings/adminPolicy").getInt("unclaimedMonths", 6);
    }
    static void setUnclaimedMonths(int n) {
        Preferences.userRoot().node("CampusFind/settings/adminPolicy").putInt("unclaimedMonths", n);
    }

    void save() {
        node.putBoolean("notifications", notifications);
        node.putBoolean("claimAlerts", claimAlerts);
        node.putBoolean("messageAlerts", messageAlerts);
        node.putBoolean("matchAlerts", matchAlerts);
        node.putBoolean("showMessagePopup", showMessagePopup);
        node.putBoolean("showMessagePreview", showMessagePreview);
        node.putBoolean("openUnreadOnLogin", openUnreadOnLogin);
        node.putBoolean("mascot", mascot);
        node.putBoolean("aiSuggestions", aiSuggestions);
        node.putBoolean("largeText", largeText);
    }
}

package com.example.campuslostandfounditem;

import java.time.LocalDate;
import java.util.List;
import javafx.scene.image.Image;

/** Read-only examples. These records are never inserted into the live reports or claims. */
final class ReferenceItems {
    private ReferenceItems() {}

    private static final List<main.Item> ITEMS = List.of(
            item("backpack", "Found", "Navy backpack", "Library", "Bag", "A navy canvas backpack with a tan patch."),
            item("umbrella", "Lost", "Foldable umbrella", "Main Gate", "Umbrellas", "A rust-orange folding umbrella."),
            item("bottle", "Found", "Metal water bottle", "Gym", "Bottles & Tumblers", "A silver bottle with a black cap."),
            item("notebook", "Lost", "Yellow spiral notebook", "Cafeteria", "School Supplies", "A yellow notebook with a spiral binding.")
    );

    private static main.Item item(String asset, String type, String name, String location, String category, String description) {
        main.Item item = new main.Item(type, name, location, description, "Sample finder");
        item.category = category;
        item.date = LocalDate.of(2026, 11, 12);
        item.photo = new Image(ReferenceItems.class.getResource("sample/" + asset + ".jpg").toExternalForm());
        return item;
    }

    static List<main.Item> all() { return ITEMS.reversed(); }

    static main.Claim claim() {
        main.Item bag = ITEMS.get(0);
        bag.secretQuestion = "What is inside the front pocket?";
        bag.secretAnswer = "Green keychain";
        bag.storageLocation = "Library desk · Cabinet B";
        main.Claim claim = new main.Claim(bag, "Sample student", "A green keychain inside the front pocket.",
                "SAMPLE-1042", "student@example.edu");
        claim.submittedAnswer = "green keychain";
        claim.hadQuestion = true;
        claim.verified = true;
        return claim;
    }
}

package com.example.campuslostandfounditem;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.control.TitledPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.Group;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.ClosePath;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Line;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.QuadCurveTo;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.layout.FlowPane;
import javafx.scene.Cursor;
import javafx.scene.control.Tooltip;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;

import java.io.File;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

public class main {

    // ---------- colors / styles ----------
    private static final String DARK = "-cf-ink";
    private static final String GREY_TEXT = "-cf-muted";
    private static final String CARD =
            "-fx-background-color: -cf-panel; -fx-background-radius: 12; -fx-border-radius: 12; -fx-border-color: -cf-edge; "
                    + "-fx-effect: dropshadow(gaussian, rgba(24,52,40,0.045), 8, 0, 0, 2);";

    // ---------- data ----------
    static class Item implements java.io.Serializable {
        private static final long serialVersionUID = 1L;
        String type;
        String title;
        String location;
        String description;
        String reporter;
        boolean claimed;
        transient Image photo;
        String category = "Other";
        LocalDate date = LocalDate.now();
        LocalDateTime created = LocalDateTime.now();
        String whereNow = "";          // Found items: where the item is right now
        String secretQuestion = "";    // Found items: question only the real owner can answer
        String secretAnswer = "";
        String storageLocation = "";       // Staff-only shelf or cabinet

        private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
            out.defaultWriteObject();
            out.writeObject(photo == null ? null : photo.getUrl());
        }

        private void readObject(java.io.ObjectInputStream in)
                throws java.io.IOException, ClassNotFoundException {
            in.defaultReadObject();
            String url = (String) in.readObject();
            if (url != null && !url.isBlank()) {
                try { photo = new Image(url, 1000, 1000, true, true, true); } catch (RuntimeException ignored) { }
            }
        }

        Item(String type, String title, String location, String description, String reporter) {
            this.type = type;
            this.title = title;
            this.location = location;
            this.description = description;
            this.reporter = reporter;
        }
    }

    private static final ObservableList<Item> items = FXCollections.observableArrayList();

    static class Claim implements java.io.Serializable {
        private static final long serialVersionUID = 1L;
        Item item;
        String claimant;
        String proof;
        LocalDateTime time = LocalDateTime.now();
        LocalDateTime released;
        LocalDateTime decided;
        String status = "Pending";
        String studentId;
        String email;
        final String accountId;
        String submittedAnswer = "";
        transient Image evidencePhoto;
        boolean privateDetailReviewed;
        boolean evidenceReviewed;
        final List<DetailRequest> requests = new ArrayList<>();
        boolean hadQuestion;            // the item had a verification question
        boolean verified;               // the claimant answered it correctly

        private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
            out.defaultWriteObject();
            out.writeObject(evidencePhoto == null ? null : evidencePhoto.getUrl());
        }

        private void readObject(java.io.ObjectInputStream in)
                throws java.io.IOException, ClassNotFoundException {
            in.defaultReadObject();
            String url = (String) in.readObject();
            if (url != null && !url.isBlank()) {
                try { evidencePhoto = new Image(url); } catch (RuntimeException ignored) { }
            }
        }

        Claim(Item item, String claimant, String proof, String studentId, String email) {
            this.item = item;
            this.claimant = claimant;
            this.accountId = CurrentUser.getStudentId();
            this.proof = proof;
            this.studentId = studentId;
            this.email = email;
        }
    }

    static class DetailRequest implements java.io.Serializable {
        private static final long serialVersionUID = 1L;
        final String question;
        final LocalDateTime asked = LocalDateTime.now();
        String reply = "";
        LocalDateTime answered;

        DetailRequest(String question) { this.question = question; }
    }

    private static final List<Claim> claims = new ArrayList<>();

    private static final Map<String, String> users = new LinkedHashMap<>();

    // ---------- audit log ----------
    static class LogEntry implements java.io.Serializable {
        private static final long serialVersionUID = 1L;
        LocalDateTime time = LocalDateTime.now();
        String actor;
        String action;
        String detail;

        LogEntry(String actor, String action, String detail) {
            this.actor = actor;
            this.action = action;
            this.detail = detail;
        }
    }

    private static final ObservableList<LogEntry> auditLog = FXCollections.observableArrayList();

    static void audit(String actor, String action, String detail) {
        auditLog.add(new LogEntry(actor, action, detail));
        saveState();
    }

    private static final Map<String, LocalDateTime> userSince = new HashMap<>();

    private void markRecovered(Item it) {
        it.claimed = true;
        audit(CurrentUser.getName(), "Item marked recovered", it.title);
    }

    private void deleteItem(Item it) {
        items.remove(it);
        audit(CurrentUser.getName(), "Item deleted", it.title);
    }

    private static int countClaims(String status) {
        int n = 0;
        for (Claim c : claims) {
            if (c.status.equals(status) && items.contains(c.item)) n++;
        }
        return n;
    }

    private static int approvedCount() {
        int n = 0;
        for (Claim c : claims) {
            if (c.accountId.equalsIgnoreCase(CurrentUser.getStudentId()) && c.status.equals("Approved")
                    && items.contains(c.item)) n++;
        }
        return n;
    }

    static String statusOf(Item it) {
        if (it.claimed) return "Recovered";
        boolean pending = false;
        for (Claim c : claims) {
            if (c.item != it) continue;
            if (c.status.equals("Approved")) return "Awaiting handover";
            if (c.status.equals("Pending")) pending = true;
        }
        return pending ? "Claim pending" : "Open";
    }

    private static Claim myActiveClaim(Item it) {
        for (Claim c : claims) {
            if (c.item == it && c.accountId.equalsIgnoreCase(CurrentUser.getStudentId())
                    && (c.status.equals("Pending") || c.status.equals("Approved"))) {
                return c;
            }
        }
        return null;
    }

    private static boolean canClaim(Item it, String me) {
        if (!it.type.equals("Found") || it.claimed) return false;
        if (it.reporter.equalsIgnoreCase(me)) return false;
        if (myActiveClaim(it) != null) return false;
        for (Claim c : claims) {
            if (c.item == it && c.status.equals("Approved")) return false;
        }
        return true;
    }

    private static Claim releasedClaim(Item it) {
        for (Claim c : claims) {
            if (c.item == it && c.status.equals("Released")) return c;
        }
        return null;
    }

    private static String claimLabel(String status) {
        switch (status) {
            case "Approved": return "Approved";
            case "Released": return "Released";
            case "Rejected": return "Rejected";
            default: return "Pending review";
        }
    }

    // ---------- screen state ----------
    private final boolean admin;
    private final Runnable onLogout;
    private final BorderPane root = new BorderPane();

    private static final String BG = "-cf-bg";
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("MMM d, yyyy");

    private TextField search;
    private HBox searchBox;
    private Label bellBadge;
    private Label workspaceTitle;

    private Node browseView;
    private enum BrowseSection {
        UNCLAIMED("Available / unresolved"),
        IN_PROGRESS("Claims in progress"),
        RECOVERED("Recovered");

        final String label;
        BrowseSection(String label) { this.label = label; }

        static BrowseSection forStatus(String status) {
            return switch (status) {
                case "Claim pending", "Awaiting handover" -> IN_PROGRESS;
                case "Recovered" -> RECOVERED;
                default -> UNCLAIMED;
            };
        }
    }

    private BrowseSection browseSection = BrowseSection.UNCLAIMED;
    private final Map<BrowseSection, Button> sectionButtons = new java.util.EnumMap<>(BrowseSection.class);
    private FlowPane grid;
    private Label resultCount;
    private ComboBox<String> catFilter, statusFilter, dateFilter, sortFilter;
    private String browseType = "All items";
    private final Map<String, Button> typeChips = new LinkedHashMap<>();
    private boolean browsePreview, claimPreview;
    private DoubleBinding browseCardWidth;
    private static final int BROWSE_PAGE_SIZE = 12;
    private int browsePage = 0; // zero-based
    private List<Item> browseResults = List.of();
    private boolean browseSample;
    private HBox browsePagination;
    private ScrollPane browseScroller;
    private boolean updatingBrowseFilters;
    private final PauseTransition browseSearchDelay = new PauseTransition(Duration.millis(275));

    private static boolean notifOn = true;
    private static boolean mascotOn = true;
    private static boolean aiSuggestOn = true;

    static Runnable rebuild;
    private static boolean reopenProfile = false;

    // bottom navigation item
    static class NavItem {
        Button box;
        SVGPath icon;
        Label label;
        Label badge;
    }

    private final List<NavItem> navItems = new ArrayList<>();
    private NavItem dashNav, reportNav, browseNav, matchNav, myNav, chatsNav, notifNav, aiNav, profileNav, settingsNav;
    private NavItem reportsNav, claimsNav, usersNav, auditNav;

    private Item detailItem;
    private boolean assistantOpen;
    private boolean browseOpen;
    private String myReportsTab = "Posts";
    private String noticeTab = "All";
    private List<Notice> noticeList = new ArrayList<>();
    private Set<String> noticeUnread = new HashSet<>();

    private StackPane fab;
    private StackPane container;

    private Node assistantView;
    private VBox chatBox;
    private ScrollPane chatScroll;

    // icons
    private static final String ICON_SEARCH = "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z";
    private static final String ICON_PERSON = "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z";
    private static final String ICON_CHAT = "M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z";
    private static final String ICON_ADD = "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z";
    private static final String ICON_BELL = "M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z";
    private static final String ICON_MATCH = "M9.01 14H2v2h7.01v3L13 15l-3.99-4v3zm5.98-1v-3H22V8h-7.01V5L11 9l3.99 4z";
    private static final String ICON_DASH = "M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z";
    private static final String ICON_CLAIM = "M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z";
    private static final String ICON_BACK = "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z";
    private static final String ICON_LOGOUT = "M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z";
    private static final String ICON_PIN = "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z";
    private static final String ICON_CAMERA = "M12 12m-3.2 0a3.2 3.2 0 1 0 6.4 0a3.2 3.2 0 1 0 -6.4 0M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z";
    private static final String ICON_CHECK = "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z";
    private static final String ICON_SPARK = "M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 4 6.5 9.5 1 12l5.5 2.5L9 20l2.5-5.5L17 12l-5.5-2.5zM19 15l-1.25 2.75L15 19l2.75 1.25L19 23l1.25-2.75L23 19l-2.75-1.25L19 15z";
    private static final String ICON_LIST = "M4 10.5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5 1.5-.67 1.5-1.5-.67-1.5-1.5-1.5zm0-6c-.83 0-1.5.67-1.5 1.5S3.17 7.5 4 7.5 5.5 6.83 5.5 6 4.83 4.5 4 4.5zm0 12c-.83 0-1.5.68-1.5 1.5s.68 1.5 1.5 1.5 1.5-.68 1.5-1.5-.67-1.5-1.5-1.5zM7 19h14v-2H7v2zm0-6h14v-2H7v2zm0-8v2h14V5H7z";
    private static final String ICON_USERS = "M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z";
    private static final String ICON_HISTORY = "M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z";
    private static final String ICON_SETTINGS = "M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z";

    public main(boolean admin, Runnable onLogout) {
        this.admin = admin;
        this.onLogout = onLogout;
        if (!admin) {
            users.putIfAbsent(CurrentUser.getName().toLowerCase(), CurrentUser.getName());
            userSince.putIfAbsent(CurrentUser.getName().toLowerCase(), LocalDateTime.now());
        }

        CampusPreferences pref = CampusPreferences.current();
        notifOn = pref.notifications;
        mascotOn = pref.mascot;
        aiSuggestOn = pref.aiSuggestions;
        root.setStyle("-fx-background-color: " + BG + "; -fx-font-size: " + (pref.largeText ? 15 : 13) + "px;");


        profileui.setPostsProvider(this::buildMyPosts);

        fab = buildFab();
        fab.managedProperty().bind(fab.visibleProperty());
        root.setTop(buildWorkspaceHeader());
        root.setLeft(buildNavigation());
        container = new StackPane(root);

        browseView = buildBrowse();
        showDashboard();
        updateMessagesBadge();
        List<Convo> incomingOnLogin = collectConvos(CurrentUser.getName());
        for (Convo conversation : incomingOnLogin) {
            if (conversation.unread > 0 && pref.notifications && pref.messageAlerts) {
                selectedChatItem = conversation.item;
                selectedChatInquirer = conversation.inquirer;
                if (pref.openUnreadOnLogin) showMessages();
                if (pref.showMessagePopup) javafx.application.Platform.runLater(() -> showIncomingToast(conversation));
                break;
            }
        }

        if (reopenProfile) {
            reopenProfile = false;
            showProfile();
        }
    }

    public Parent getRoot() {
        return container;
    }

    private static SVGPath svg(String content, double size, String color) {
        SVGPath p = new SVGPath();
        p.setContent(content);
        p.setFill(Color.web(color));
        double s = size / 24.0;
        p.setScaleX(s);
        p.setScaleY(s);
        return p;
    }

    // =====================================================
    // WORKSPACE NAVIGATION
    // =====================================================
    private NavItem navItem(String iconPath, String text, Runnable action) {
        NavItem n = new NavItem();
        n.icon = svg(iconPath, 18, "#ffffff");
        n.label = new Label(text);
        n.label.setStyle("-fx-font-size: 13px; -fx-text-fill: white;");

        n.badge = new Label();
        n.badge.setStyle("-fx-background-color: #b42340; -fx-text-fill: white; -fx-font-size: 10px; "
                + "-fx-font-weight: bold; -fx-background-radius: 9; -fx-padding: 0 5 0 5;");
        n.badge.setVisible(false);

        StackPane iconWrap = new StackPane(new Group(n.icon), n.badge);
        StackPane.setAlignment(n.badge, Pos.TOP_RIGHT);
        n.badge.setTranslateX(10);
        n.badge.setTranslateY(-6);

        n.box = new Button();
        HBox row = new HBox(6, iconWrap, n.label);
        row.setAlignment(Pos.CENTER_LEFT);
        n.box.setGraphic(row);
        n.box.setAccessibleText(text);
        n.box.setTooltip(new Tooltip(text));
        n.box.getStyleClass().add("workspace-nav-button");
        n.box.setMaxWidth(Double.MAX_VALUE);
        n.box.setAlignment(Pos.CENTER_LEFT);
        n.box.setOnAction(e -> action.run());

        navItems.add(n);
        return n;
    }

    // Shared NORSU branding on both the admin and student workspaces.
    private ImageView officialSeal(double size) {
        ImageView view = new ImageView(new Image(main.class.getResource("norsu-official-seal.png").toExternalForm()));
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setAccessibleText("Negros Oriental State University official seal");
        return view;
    }

    private Node buildWorkspaceHeader() {
        HBox top = (HBox) buildTopBar();
        List<Node> parts = new ArrayList<>(top.getChildren());
        top.getChildren().clear();
        Label university = new Label("NEGROS ORIENTAL STATE UNIVERSITY");
        university.setStyle("-fx-text-fill: #0c2d6a; -fx-font-size: 13px; -fx-font-weight: bold;");
        Label tagline = new Label("Campus Lost & Found System");
        tagline.setStyle("-fx-text-fill: #516b95; -fx-font-size: 11px;");
        VBox school = new VBox(1, university, tagline);
        school.setAlignment(Pos.CENTER_LEFT);
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label account = new Label(admin ? "Admin" : "Student");
        account.setStyle("-fx-text-fill: #1559c8; -fx-font-size: 13px; -fx-font-weight: bold;");
        HBox header = new HBox(13, officialSeal(46), school, spacer, account,
                parts.get(3), parts.get(4), parts.get(5));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(8, 22, 8, 18));
        header.getStyleClass().add("workspace-topbar");
        header.setStyle("-fx-background-color: #ffffff; -fx-border-color: transparent transparent #cbdcf5 transparent;");
        header.setId("workspace-header");
        return header;
    }

    private Node buildNavigation() {
        navItems.clear();
        VBox bar = new VBox(5);
        bar.setId(admin ? "admin-navigation" : "student-navigation");
        bar.getStyleClass().add("workspace-nav");
        bar.setAlignment(Pos.TOP_CENTER);
        bar.setPrefWidth(214);
        bar.setMinWidth(192);
        bar.setMaxWidth(218);

        Label campusName = new Label("Campus");
        campusName.setStyle("-fx-font-weight: bold; -fx-font-size: 21px; -fx-text-fill: white;");
        Label findName = new Label("Find");
        findName.setStyle("-fx-font-weight: bold; -fx-font-size: 21px; -fx-text-fill: #ffca23;");
        HBox wordmark = new HBox(0, campusName, findName);
        HBox brand = new HBox(8, new Group(svg(ICON_SEARCH, 24, "#ffca23")), wordmark);
        brand.setAlignment(Pos.CENTER);
        Label role = new Label(admin ? "Admin Panel" : "Student Portal");
        role.setStyle("-fx-text-fill: #dce9ff; -fx-font-size: 12px;");
        VBox mark = new VBox(2, brand, role);
        mark.setAlignment(Pos.CENTER);
        mark.setPadding(new Insets(7, 2, 13, 2));
        bar.getChildren().add(mark);

        dashNav = navItem(ICON_DASH, "Dashboard", this::showDashboard);
        if (admin) {
            reportsNav = navItem(ICON_LIST, "Manage Reports", this::showReports);
            claimsNav = navItem(ICON_CLAIM, "Manage Claims", this::showAdminClaims);
            usersNav = navItem(ICON_USERS, "Manage Users", this::showUsers);
            aiNav = navItem(ICON_SPARK, "KITA AI", this::showAssistant);
            matchNav = aiNav;
            chatsNav = navItem(ICON_CHAT, "Messages", this::showMessages);
            auditNav = navItem(ICON_HISTORY, "Audit Logs", this::showAudit);
            settingsNav = navItem(ICON_SETTINGS, "Settings", this::showSettings);
        } else {
            reportNav = navItem(ICON_ADD, "Report Item", this::showReport);
            browseNav = navItem(ICON_SEARCH, "Browse Items", this::showBrowse);
            myNav = navItem(ICON_LIST, "My Reports", this::showMyPosts);
            claimsNav = navItem(ICON_CLAIM, "My Claims", this::showClaims);
            chatsNav = navItem(ICON_CHAT, "Messages", this::showMessages);
            aiNav = navItem(ICON_SPARK, "KITA AI", this::showAssistant);
            matchNav = aiNav;
            notifNav = navItem(ICON_BELL, "Notifications", this::showNotifications);
            profileNav = navItem(ICON_PERSON, "Profile", this::showProfile);
            settingsNav = navItem(ICON_SETTINGS, "Settings", this::showSettings);
        }
        for (NavItem item : navItems) bar.getChildren().add(item.box);

        Button logout = new Button("Sign Out");
        logout.setGraphic(new Group(svg(ICON_LOGOUT, 17, "#ffffff")));
        logout.setStyle("-fx-background-color: #0c4aab; -fx-border-color: #6ba5ef; "
                + "-fx-border-radius: 18; -fx-background-radius: 18; -fx-text-fill: white; "
                + "-fx-font-weight: bold; -fx-padding: 10 20;");
        logout.setMaxWidth(Double.MAX_VALUE);
        logout.setOnAction(e -> onLogout.run());
        Region fill = new Region();
        VBox.setVgrow(fill, Priority.ALWAYS);
        bar.getChildren().addAll(fill, logout);
        return bar;
    }

    private void setActive(NavItem active) {
        for (NavItem n : navItems) {
            boolean on = n == active;
            n.box.pseudoClassStateChanged(javafx.css.PseudoClass.getPseudoClass("selected"), on);
            n.icon.setFill(Color.web(on ? "#0d2d69" : "#ffffff"));
            n.label.setStyle("-fx-font-size: 13px; -fx-font-weight: " + (on ? "bold" : "normal")
                    + "; -fx-text-fill: " + (on ? "#0d2d69" : "#ffffff") + ";");
        }
    }

    private void setBadge(NavItem n, int count) {
        if (n == null) return;
        n.badge.setText(String.valueOf(count));
        n.badge.setVisible(count > 0);
    }

    // =====================================================
    // WORKSPACE HEADER
    // =====================================================
    private Node buildTopBar() {
        search = new TextField();
        search.setPromptText("Search campus items");
        search.setStyle("-fx-background-color: transparent; -fx-padding: 9 4 9 4;");
        HBox.setHgrow(search, Priority.ALWAYS);
        browseSearchDelay.setOnFinished(event -> refresh());
        search.textProperty().addListener((o, a, b) -> {
            browsePage = 0;
            if (!browseOpen) return;
            browseSearchDelay.playFromStart();
        });
        searchBox = new HBox(8, new Group(svg(ICON_SEARCH, 20, "#98a2b3")), search);
        searchBox.setAlignment(Pos.CENTER_LEFT);
        searchBox.setPadding(new Insets(0, 14, 0, 14));
        searchBox.setMaxWidth(Double.MAX_VALUE);
        searchBox.getStyleClass().add("browse-search");

        Label title = new Label();
        workspaceTitle = title;
        title.setStyle("-fx-text-fill: #e7f0ff; -fx-font-size: 13px;");


        bellBadge = new Label();
        bellBadge.setStyle("-fx-background-color: #b42340; -fx-text-fill: white; -fx-font-size: 10px; "
                + "-fx-font-weight: bold; -fx-background-radius: 9; -fx-padding: 0 5 0 5;");
        bellBadge.setVisible(false);
        StackPane.setAlignment(bellBadge, Pos.TOP_RIGHT);
        bellBadge.setTranslateX(4);
        bellBadge.setTranslateY(-2);
        StackPane bellIcon = new StackPane(new Group(svg(ICON_BELL, 19, "#1559c8")), bellBadge);
        Button bell = new Button();
        bell.setGraphic(bellIcon);
        bell.setMinSize(36, 36);
        bell.setPrefSize(36, 36);
        bell.setStyle("-fx-background-color: #e5efff; -fx-background-radius: 22; -fx-cursor: hand;");
        bell.setAccessibleText("Notifications");
        bell.setOnAction(e -> showNotifications());
        Tooltip.install(bell, new Tooltip("Notifications"));

        StackPane avatar = profileui.avatar(34);
        avatar.setCursor(Cursor.HAND);
        avatar.setOnMouseClicked(e -> showAccountMenu(avatar));

        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        Label brand = new Label("CampusFind");
        brand.getStyleClass().add("workspace-brand");
        StackPane emblem = new StackPane(new Group(svg(ICON_SEARCH, 22, "#ffca23")));
        emblem.setMinSize(32, 32);
        emblem.setStyle("-fx-border-color: #ffca23; -fx-border-radius: 8; -fx-background-radius: 8; -fx-background-color: #0d438f;");
        brand.setGraphic(emblem);
        brand.setGraphicTextGap(8);
        HBox bar = new HBox(14, brand, title, gap, fab, bell, avatar);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(8, 20, 10, 20));
        bar.getStyleClass().add("workspace-topbar");
        return bar;
    }

    // =====================================================
    // ACCOUNT MENU (click the picture, like Facebook)
    // =====================================================
    private javafx.stage.Popup accountMenu;

    private HBox menuRow(String icon, String text, Runnable action) {
        StackPane bubble = new StackPane(new Group(svg(icon, 18, Theme.ink)));
        bubble.setMinSize(36, 36);
        bubble.setPrefSize(36, 36);
        bubble.setMaxSize(36, 36);
        bubble.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 18;");
        Label l = new Label(text);
        l.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: " + DARK + ";");
        HBox row = new HBox(12, bubble, l);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(8, 10, 8, 10));
        row.setCursor(Cursor.HAND);
        row.setStyle("-fx-background-radius: 10;");
        row.setOnMouseEntered(e -> row.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 10;"));
        row.setOnMouseExited(e -> row.setStyle("-fx-background-radius: 10;"));
        row.setOnMouseClicked(e -> {
            if (accountMenu != null) accountMenu.hide();
            action.run();
        });
        return row;
    }

    private void showAccountMenu(Node anchor) {
        if (accountMenu != null && accountMenu.isShowing()) {
            accountMenu.hide();
            return;
        }
        Label name = new Label();
        name.textProperty().bind(CurrentUser.nameProperty());
        name.setStyle("-fx-font-weight: bold; -fx-font-size: 15px; -fx-text-fill: " + DARK + ";");
        Label role = new Label(admin ? "Admin" : "Student");
        role.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        HBox who = new HBox(12, profileui.avatar(44), new VBox(1, name, role));
        who.setAlignment(Pos.CENTER_LEFT);
        who.setPadding(new Insets(10));
        who.setCursor(Cursor.HAND);
        who.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 12; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.10), 6, 0, 0, 1);");
        who.setOnMouseClicked(e -> {
            accountMenu.hide();
            showProfile();
        });

        VBox box = new VBox(6, who,
                menuRow(admin ? ICON_SETTINGS : ICON_PERSON, admin ? "Settings" : "Profile", admin ? this::showSettings : this::showProfile),
                menuRow(ICON_LOGOUT, "Log Out", onLogout));
        box.setPadding(new Insets(10));
        box.setPrefWidth(270);
        box.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 14; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.30), 16, 0, 0, 4);");

        StackPane wrap = new StackPane(box);
        wrap.setPadding(new Insets(14));
        wrap.setStyle("-fx-background-color: transparent;");
        CampusStyle.install(wrap);

        accountMenu = new javafx.stage.Popup();
        accountMenu.setAutoHide(true);
        accountMenu.getContent().add(wrap);
        javafx.geometry.Bounds b = anchor.localToScreen(anchor.getBoundsInLocal());
        accountMenu.show(anchor, b.getMaxX() - 284, b.getMaxY() + 2);
    }

    private static Label statusChip(Item it) {
        String st = statusOf(it);
        String bg;
        String fg;
        if (st.equals("Recovered")) {
            bg = "#dcfce7";
            fg = "#15803d";
        } else if (st.equals("Awaiting handover")) {
            bg = "#dbeafe";
            fg = "#1d4ed8";
        } else if (st.equals("Claim pending")) {
            bg = "#fef3c7";
            fg = "#b45309";
        } else {
            bg = "#e2e8f0";
            fg = "#475569";
        }
        Label l = new Label(st.equals("Open") ? ("Found".equals(it.type) ? "Available" : "Missing") : st);
        l.setMinWidth(Region.USE_PREF_SIZE);
        l.setStyle("-fx-background-color: " + bg + "; -fx-text-fill: " + fg + "; "
                + "-fx-font-weight: bold; -fx-font-size: 12px; "
                + "-fx-background-radius: 10; -fx-padding: 2 10 2 10;");
        return l;
    }

    // =====================================================
    // SCREENS
    // =====================================================
    private void openScreen(Node content, NavItem active, boolean isAssistant, boolean isBrowse) {
        if (!isBrowse) browseSearchDelay.stop();
        detailItem = null;
        assistantOpen = isAssistant;
        browseOpen = isBrowse;
        root.setCenter(content);
        workspaceTitle.setText(active == dashNav ? (admin ? "Admin dashboard" : greeting() + ", " + firstWord(CurrentUser.getName()))
                : (admin ? "Admin workspace" : "Student workspace"));
        setActive(active);
        if (fab != null) fab.setVisible(mascotOn && !assistantOpen && active != reportNav);
    }

    private void showDashboard() {
        if (admin) {
            adminRefresh = this::showDashboard;
            openScreen(buildAdminDashboard(), dashNav, false, false);
        } else {
            openScreen(buildStudentDashboard(), dashNav, false, false);
        }
    }

    private void showBrowse() {
        openScreen(browseView, browseNav, false, true);
        browseSearchDelay.stop();
        refresh();
    }

    private void showItemDetail(Item it) {
        openScreen(buildDetailScreen(it), browseNav, false, false);
        detailItem = it;
    }

    private void showReport() { showReport("Lost"); }

    private void showReport(String kind) {
        openScreen(buildReportForm(kind), admin ? reportsNav : reportNav, false, false);
    }

    private void showMyReports() {
        NavItem destination = !admin && myReportsTab.equals("Claims") ? claimsNav : myNav;
        openScreen(buildMyReports(), destination, false, false);
    }

    private void showMyPosts() {
        myReportsTab = "Posts";
        showMyReports();
    }

    private void showClaims() {
        myReportsTab = "Claims";
        showMyReports();
    }

    private void showMatches() {
        showAssistant();
    }

    private void showAssistant() {
        if (assistantView == null) assistantView = buildAssistantView();
        aiCardRefreshers.forEach(Runnable::run);
        refreshWatchBox();
        openScreen(assistantView, aiNav, true, false);
    }

    private void showMessages() {
        openScreen(buildMessagesView(), chatsNav, false, false);
    }

    private void showProfile() {
        if (admin) { showSettings(); return; }
        openScreen(buildProfileScreen(), profileNav, false, false);
    }

    private void showSettings() {
        openScreen(admin ? buildSettingsScreen() : buildStudentProfileSettingsScreen(),
                settingsNav, false, false);
    }

    // Long forms have their own focused page; the Settings overview stays compact.
    private void showSettingsCategory(String category) {
        openScreen(buildSettingsEditorScreen(category), settingsNav, false, false);
    }

    private void showNotifications() {
        noticeTab = "All";
        try {
            noticeList = buildNotices();
            noticeUnread = new HashSet<>();
            for (Notice n : noticeList) {
                if (n.unread) noticeUnread.add(n.id);
            }
            for (Notice n : noticeList) seenNotices.add(n.id);
            updateMessagesBadge();
            openScreen(buildNoticesView(), notifNav, false, false);
        } catch (RuntimeException ex) {
            ex.printStackTrace();
            popup("Notifications", wrapLabel("Sorry, the notifications could not be opened: " + ex));
        }
    }

    // =====================================================
    // SMALL HELPERS
    // =====================================================
    private String greeting() {
        int h = LocalTime.now().getHour();
        if (h < 12) return "Good Morning";
        if (h < 18) return "Good Afternoon";
        return "Good Evening";
    }

    private Label pageTitle(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("editorial-title");
        return l;
    }

    private ScrollPane pageOf(Node... nodes) {
        return pageOf(1340, nodes);
    }

    private ScrollPane pageOf(double maxWidth, Node... nodes) {
        VBox content = new VBox(14, nodes);
        content.setPadding(new Insets(20, 24, 24, 24));
        content.getStyleClass().add("workspace-content");
        content.setMaxWidth(maxWidth);
        StackPane holder = new StackPane(content);
        StackPane.setAlignment(content, Pos.TOP_CENTER);
        ScrollPane sp = new ScrollPane(holder);
        sp.setFitToWidth(true);
        sp.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        sp.setPannable(true);
        sp.getStyleClass().add("cf-v2-page");
        sp.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        return sp;
    }

    private void styleChip(Button b, boolean active) {
        String selected = Theme.selected.equalsIgnoreCase(Theme.DEFAULT) ? "#ffca23" : Theme.BLUE;
        b.setStyle("-fx-background-color: " + (active ? selected : Theme.panel) + "; "
                + "-fx-text-fill: " + (active ? Theme.foreground(selected) : Theme.ink) + "; "
                + "-fx-border-color: " + (active ? selected : Theme.edge) + "; -fx-border-radius: 8; "
                + "-fx-font-weight: bold; -fx-background-radius: 8; -fx-padding: 7 16; -fx-cursor: hand;");
    }

    private String primaryBtn() {
        return "-fx-background-color: " + Theme.BLUE + "; -fx-text-fill: -cf-on-accent; -fx-font-weight: bold; "
                + "-fx-font-size: 14px; -fx-background-radius: 10; -fx-padding: 10 22 10 22; "
                + "-fx-cursor: hand;";
    }

    private String smallBtn() {
        return "-fx-background-color: -cf-panel; -fx-text-fill: " + Theme.BLUE + "; -fx-font-weight: bold; "
                + "-fx-font-size: 12px; -fx-background-radius: 8; -fx-border-color: " + Theme.BLUE + "; "
                + "-fx-border-radius: 8; -fx-padding: 5 12 5 12; -fx-cursor: hand;";
    }

    private String smallSolidBtn() {
        return "-fx-background-color: " + Theme.BLUE + "; -fx-text-fill: -cf-on-accent; -fx-font-weight: bold; "
                + "-fx-font-size: 12px; -fx-background-radius: 8; -fx-padding: 5 12 5 12; -fx-cursor: hand;";
    }

    private String outlineBtn() {
        return "-fx-background-color: -cf-panel; -fx-text-fill: " + Theme.BLUE + "; -fx-font-weight: bold; "
                + "-fx-font-size: 14px; -fx-background-radius: 10; -fx-border-color: " + Theme.BLUE + "; "
                + "-fx-border-radius: 10; -fx-padding: 9 20 9 20; -fx-cursor: hand;";
    }

    private Label linkLabel(String text, Runnable action) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: " + Theme.BLUE + "; -fx-font-weight: bold; -fx-font-size: 13px;");
        l.setCursor(Cursor.HAND);
        l.setOnMouseClicked(e -> action.run());
        return l;
    }

    private Node placeholderPhoto(Item it, double w, double h) {
        Label big = new Label(it.category.substring(0, 1).toUpperCase());
        big.setStyle("-fx-font-size: " + (h * 0.32) + "px; -fx-font-weight: bold; "
                + "-fx-text-fill: -cf-muted;");
        Label cat = new Label(it.category);
        cat.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: 12px;");
        VBox v = new VBox(2, big, cat);
        v.setAlignment(Pos.CENTER);
        StackPane p = new StackPane(v);
        p.setMinSize(w, h);
        p.setPrefSize(w, h);
        p.setMaxSize(w, h);
        p.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 12;");
        return p;
    }

    private Node itemPicture(Item it, double w, double h) {
        return it.photo != null ? photoView(it.photo, w, h) : placeholderPhoto(it, w, h);
    }

    private String kindColor(Item it) {
        return Theme.readable(it.type.equals("Lost") ? "#e5ae56" : "#72cda4", Theme.panel);
    }

    private HBox kindAndDate(Item it, double fontSize) {
        Label kind = new Label(it.type);
        kind.setStyle("-fx-text-fill: " + kindColor(it) + "; -fx-font-weight: bold; -fx-font-size: "
                + fontSize + "px;");
        Label date = new Label("-  " + it.date.format(DATE_FMT));
        date.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: " + fontSize + "px;");
        HBox h = new HBox(5, kind, date);
        h.setAlignment(Pos.CENTER_LEFT);
        return h;
    }

    private HBox pinAndPlace(String place, double fontSize) {
        Label l = new Label(place);
        l.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: " + fontSize + "px;");
        l.setMinWidth(0);
        HBox h = new HBox(4, new Group(svg(ICON_PIN, fontSize + 2, "#98a2b3")), l);
        h.setAlignment(Pos.CENTER_LEFT);
        return h;
    }

    private Node toggle(boolean on, Consumer<Boolean> change) {
        Rectangle track = new Rectangle(46, 26);
        track.setArcWidth(26);
        track.setArcHeight(26);
        Circle knob = new Circle(10, Color.WHITE);
        StackPane sw = new StackPane(track, knob);
        sw.setMinSize(46, 26);
        sw.setPrefSize(46, 26);
        sw.setMaxSize(46, 26);

        boolean[] state = {on};
        Runnable paint = () -> {
            track.setFill(Color.web(state[0] ? Theme.BLUE : Theme.edge));
            knob.setTranslateX(state[0] ? 10 : -10);
        };
        paint.run();

        sw.setCursor(Cursor.HAND);
        sw.setOnMouseClicked(e -> {
            state[0] = !state[0];
            paint.run();
            change.accept(state[0]);
            e.consume();
        });
        return sw;
    }

    // =====================================================
    // BROWSE ITEMS
    // =====================================================
    private ComboBox<String> combo(String... values) {
        ComboBox<String> c = new ComboBox<>();
        c.getItems().addAll(values);
        c.setValue(values[0]);
        c.setMaxWidth(Double.MAX_VALUE);
        c.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 10; "
                + "-fx-border-color: -cf-edge; -fx-border-radius: 10;");
        HBox.setHgrow(c, Priority.ALWAYS);
        c.setOnAction(e -> {
            if (updatingBrowseFilters) return;
            browsePage = 0;
            refresh();
        });
        return c;
    }

    private Node buildBrowse() {
        String[] cats = new String[ReportCategory.values().length + 1];
        cats[0] = "All Categories";
        for (ReportCategory option : ReportCategory.values()) cats[option.ordinal() + 1] = option.label;
        catFilter = combo(cats);

        statusFilter = combo("Any claim stage", "Claim pending", "Awaiting handover");
        statusFilter.setVisible(false);
        statusFilter.managedProperty().bind(statusFilter.visibleProperty());
        dateFilter = combo("Any date", "Today", "Last 7 days", "Last 30 days");
        sortFilter = combo("Sort by: Newest", "Sort by: Oldest");

        FlowPane filters = new FlowPane(10, 10, catFilter, statusFilter, dateFilter, sortFilter);
        FlowPane sections = new FlowPane(8, 8);
        for (BrowseSection section : BrowseSection.values()) {
            Button tab = new Button(section.label);
            tab.setAccessibleText(section.label);
            sectionButtons.put(section, tab);
            tab.setOnAction(e -> selectBrowseSection(section));
            sections.getChildren().add(tab);
        }
        HBox types = new HBox(8);
        for (String type : List.of("All items", "Found", "Lost")) {
            Button chip = new Button(type);
            typeChips.put(type, chip);
            styleChip(chip, type.equals(browseType));
            chip.setOnAction(e -> selectBrowseType(type));
            types.getChildren().add(chip);
        }
        javafx.scene.control.ToggleButton more = new javafx.scene.control.ToggleButton("More filters");
        more.getStyleClass().add("filter-toggle");
        filters.visibleProperty().bind(more.selectedProperty());
        filters.managedProperty().bind(filters.visibleProperty());
        types.getChildren().add(more);

        resultCount = new Label();
        resultCount.setStyle("-fx-text-fill: " + GREY_TEXT + ";");
        Button clear = new Button("Clear filters");
        clear.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-muted; -fx-font-weight: bold; "
                + "-fx-background-radius: 10; -fx-cursor: hand;");
        clear.setOnAction(e -> clearFilters());
        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox countRow = new HBox(10, resultCount, gap, clear);
        countRow.setAlignment(Pos.CENTER_LEFT);

        grid = new FlowPane(12, 12);
        grid.setRowValignment(javafx.geometry.VPos.TOP);
        grid.setMinWidth(0);

        browseCardWidth = Bindings.createDoubleBinding(() -> {
            double width = grid.getWidth();
            if (width <= 0) return 230.0;
            double gutter = grid.getHgap();
            int columns = Math.max(1, (int)((width + gutter) / (214 + gutter)));
            return Math.min(266, Math.floor((width - (columns - 1) * gutter) / columns));
        }, grid.widthProperty());
        Label browseTitle = new Label("Browse Found & Lost Items");
        browseTitle.setStyle("-fx-font-size: 23px; -fx-font-weight: bold; -fx-text-fill: #0a327c;");
        Label browseSubtitle = compactEmptyHint("Explore available, claimed and recovered items from your NORSU community.");
        browsePagination = new HBox(8);
        browsePagination.setAlignment(Pos.CENTER);
        browsePagination.getStyleClass().add("cf-browse-pagination");
        VBox listings = new VBox(12, browseTitle, browseSubtitle, sections, searchBox, types,
                filters, countRow, grid, browsePagination);
        listings.setMinWidth(0);
        listings.getStyleClass().add("cf-v2-browse-listings");
        listings.setPadding(new Insets(16));
        listings.setStyle("-fx-background-color: white; -fx-background-radius: 15; "
                + "-fx-border-color: #c6d9f6; -fx-border-radius: 15;");
        VBox sidebar = new VBox(10);
        sidebar.setMinWidth(0);
        sidebar.getStyleClass().add("cf-v2-browse-sidebar");
        sidebar.setPadding(new Insets(16));
        sidebar.setStyle("-fx-background-color: white; -fx-background-radius: 15; "
                + "-fx-border-color: #c6d9f6; -fx-border-radius: 15;");
        Label heading = new Label("What would you like to do?");
        heading.setWrapText(true);
        heading.setStyle("-fx-font-weight: bold; -fx-font-size: 15px; -fx-text-fill: #103778;");
        sidebar.getChildren().add(heading);
        sidebar.getChildren().add(browseSidebarAction(admin ? "Manage Reports" : "Report a Lost Item",
                ICON_ADD, admin ? this::showReports : () -> showReport("Lost"), true));
        if (!admin) {
            sidebar.getChildren().add(browseSidebarAction("My Reports", ICON_LIST, this::showMyReports, false));
            sidebar.getChildren().add(browseSidebarAction("My Claims", ICON_CLAIM, this::showClaims, false));
        } else {
            sidebar.getChildren().add(browseSidebarAction("Claim Review", ICON_CLAIM, this::showAdminClaims, false));
        }
        sidebar.getChildren().add(compactEmptyHint("Click a report to see its status, photo, and details."));
        Node content = dashboardGrid(1010, new double[]{78,22}, listings, sidebar);
        ScrollPane page = pageOf(content);
        page.setId("cf-browse-page");
        browseScroller = page;
        return page;
    }

private Button browseSidebarAction(String title, String icon, Runnable action, boolean highlighted) {
    Label name = new Label(title);
    name.setWrapText(true);
    name.setStyle("-fx-text-fill: " + (highlighted ? "white" : "#0d3a84")
            + "; -fx-font-weight: bold; -fx-font-size: 12px;");
    HBox layout = new HBox(9,new Group(svg(icon,20,highlighted ? "#ffca23" : "#1559c8")),name);
    layout.setAlignment(Pos.CENTER_LEFT);
    Button button = new Button();
    button.setGraphic(layout);
    button.setMaxWidth(Double.MAX_VALUE);
    button.setMinHeight(48);
    button.setAlignment(Pos.CENTER_LEFT);
    button.setStyle("-fx-background-color: " + (highlighted ? "#0e469e" : "#eff5ff")
            + "; -fx-background-radius: 12; -fx-padding: 9 12; -fx-border-color: #cbdcf7; -fx-border-radius: 12;");
    button.setOnAction(e -> action.run());
    return button;
}

        private void selectBrowseSection(BrowseSection section) {
        browseSection = section;
        browsePage = 0;
        statusFilter.setVisible(section == BrowseSection.IN_PROGRESS);
        updatingBrowseFilters = true;
        try { statusFilter.setValue("Any claim stage"); }
        finally { updatingBrowseFilters = false; }
        refresh();
    }

    private void selectBrowseType(String type) {
        browseType = type;
        browsePage = 0;
        typeChips.forEach((name, chip) -> styleChip(chip, name.equals(type)));
        if (!updatingBrowseFilters) refresh();
    }

    private boolean matchesFilters(Item it) {
        if (catFilter != null && catFilter.getValue() != null
                && !catFilter.getValue().equals("All Categories")
                && !catFilter.getValue().equals(it.category)) {
            return false;
        }
        if (!browseType.equals("All items") && !browseType.equals(it.type)) return false;
        if (dateFilter != null && dateFilter.getValue() != null) {
            long days = ChronoUnit.DAYS.between(it.date, LocalDate.now());
            if (days < 0) days = 0;
            String d = dateFilter.getValue();
            if (d.equals("Today") && days > 0) return false;
            if (d.equals("Last 7 days") && days > 7) return false;
            if (d.equals("Last 30 days") && days > 30) return false;
        }
        return true;
    }

    private void clearFilters() {
        // Avoid rebuilding the gallery once per ComboBox change.
        updatingBrowseFilters = true;
        try {
            if (catFilter != null) catFilter.setValue("All Categories");
            browseType = "All items";
            typeChips.forEach((name, chip) -> styleChip(chip, name.equals(browseType)));
            if (statusFilter != null) statusFilter.setValue("Any claim stage");
            if (dateFilter != null) dateFilter.setValue("Any date");
            if (sortFilter != null) sortFilter.setValue("Sort by: Newest");
            if (search != null) search.clear();
        } finally {
            updatingBrowseFilters = false;
        }
        browsePage = 0;
        browseSearchDelay.stop();
        refresh();
    }

    private void refresh() {
        if (grid == null) return;
        String query = search == null || search.getText() == null ? ""
                : search.getText().trim().toLowerCase(java.util.Locale.ROOT);
        browseSample = items.isEmpty() && browsePreview;
        List<Item> source = browseSample ? ReferenceItems.all() : items;

        // Compute claim status in one pass, rather than scanning every claim for
        // every item whenever the user types, changes filters or turns a page.
        Map<Item, String> statuses = new IdentityHashMap<>();
        Map<Item, Integer> insertionOrder = new IdentityHashMap<>();
        for (int i = 0; i < source.size(); i++) {
            Item item = source.get(i);
            insertionOrder.put(item, i);
            statuses.put(item, item.claimed ? "Recovered" : "Open");
        }
        if (!browseSample) {
            for (Claim claim : claims) {
                if (claim.item == null || claim.item.claimed || !statuses.containsKey(claim.item)) continue;
                String existing = statuses.get(claim.item);
                if ("Approved".equals(claim.status)) statuses.put(claim.item, "Awaiting handover");
                else if ("Pending".equals(claim.status) && "Open".equals(existing))
                    statuses.put(claim.item, "Claim pending");
            }
        }

        List<Item> filtered = new ArrayList<>();
        Map<BrowseSection, Integer> counts = new java.util.EnumMap<>(BrowseSection.class);
        for (Item item : source) {
            if (!matchesFilters(item)) continue;
            if (!query.isEmpty()) {
                String text = (item.title + " " + item.location + " " + item.description + " "
                        + item.category).toLowerCase(java.util.Locale.ROOT);
                if (!text.contains(query)) continue;
            }
            String status = statuses.getOrDefault(item, "Open");
            BrowseSection section = BrowseSection.forStatus(status);
            counts.merge(section, 1, Integer::sum);
            if (section != browseSection) continue;
            if (section == BrowseSection.IN_PROGRESS && !"Any claim stage".equals(statusFilter.getValue())
                    && !status.equals(statusFilter.getValue())) continue;
            filtered.add(item);
        }
        sectionButtons.forEach((section, tab) -> {
            tab.setText(section.label + " (" + counts.getOrDefault(section, 0) + ")");
            styleChip(tab, section == browseSection);
        });

        boolean oldest = sortFilter != null && "Sort by: Oldest".equals(sortFilter.getValue());
        Comparator<LocalDate> dates = Comparator.nullsFirst(Comparator.naturalOrder());
        filtered.sort((a, b) -> {
            int dateCompare = dates.compare(a.date, b.date);
            int orderCompare = dateCompare != 0 ? dateCompare
                    : Integer.compare(insertionOrder.get(a), insertionOrder.get(b));
            return oldest ? orderCompare : -orderCompare;
        });
        browseResults = filtered;
        displayBrowsePage();
        updateMessagesBadge();

        if (detailItem != null) {
            if (items.contains(detailItem)) root.setCenter(buildDetailScreen(detailItem));
            else if (admin) showReports();
            else showBrowse();
        }
    }

    /** Render only the current page (12 cards max), never the entire result set. */
    private void displayBrowsePage() {
        if (grid == null) return;
        int pages = Math.max(1, (browseResults.size() + BROWSE_PAGE_SIZE - 1) / BROWSE_PAGE_SIZE);
        browsePage = Math.max(0, Math.min(browsePage, pages - 1));
        int from = browsePage * BROWSE_PAGE_SIZE;
        int to = Math.min(from + BROWSE_PAGE_SIZE, browseResults.size());

        grid.getChildren().clear();
        for (int i = from; i < to; i++) {
            grid.getChildren().add(photoCard(browseResults.get(i), browseCardWidth, browseSample));
        }
        if (browseResults.isEmpty()) {
            String query = search == null || search.getText() == null ? "" : search.getText().trim();
            boolean firstVisit = items.isEmpty() && !browseSample;
            boolean filtered = !query.isEmpty() || !"All items".equals(browseType)
                    || !"All Categories".equals(catFilter.getValue()) || !"Any date".equals(dateFilter.getValue())
                    || !"Any claim stage".equals(statusFilter.getValue());
            String message = switch (browseSection) {
                case UNCLAIMED -> "New lost and found reports appear here.";
                case IN_PROGRESS -> "Items appear here when someone submits a claim.";
                case RECOVERED -> "Items appear here after pickup or when marked recovered.";
            };
            if (firstVisit && browseSection == BrowseSection.UNCLAIMED) {
                grid.getChildren().add(emptyState(ICON_SEARCH, Theme.BLUE, "No campus reports yet",
                        "Explore a sample gallery or select Report Item to add a report.", "Preview sample gallery",
                        () -> { browsePreview = true; clearFilters(); }));
            } else {
                grid.getChildren().add(emptyState(ICON_SEARCH, Theme.BLUE,
                        filtered ? "No matching items" : "No items in this section",
                        filtered ? "Try another search or clear your filters." : message,
                        filtered ? "Clear filters" : null, filtered ? this::clearFilters : null));
            }
            if (grid.getChildren().getFirst() instanceof Region empty) {
                empty.prefWidthProperty().bind(grid.widthProperty());
            }
        }
        resultCount.setText((browseSample ? "Sample gallery · " : "") + browseResults.size()
                + (browseResults.size() == 1 ? " item" : " items")
                + (browseResults.isEmpty() ? "" : "  ·  Showing " + (from + 1) + "–" + to));
        buildBrowsePagination(pages);
    }

    private void buildBrowsePagination(int pages) {
        browsePagination.getChildren().clear();
        browsePagination.setVisible(pages > 1);
        browsePagination.setManaged(pages > 1);
        if (pages <= 1) return;
        browsePagination.getChildren().add(browsePageButton("‹ Previous", browsePage - 1,
                browsePage > 0, false));
        int low = Math.max(0, browsePage - 2);
        int high = Math.min(pages - 1, low + 4);
        low = Math.max(0, high - 4);
        if (low > 0) {
            browsePagination.getChildren().add(browsePageButton("1", 0, true, false));
            if (low > 1) browsePagination.getChildren().add(smallGrey("…"));
        }
        for (int page = low; page <= high; page++) {
            browsePagination.getChildren().add(browsePageButton(Integer.toString(page + 1),
                    page, true, page == browsePage));
        }
        if (high < pages - 1) {
            if (high < pages - 2) browsePagination.getChildren().add(smallGrey("…"));
            browsePagination.getChildren().add(browsePageButton(Integer.toString(pages), pages - 1, true, false));
        }
        browsePagination.getChildren().add(browsePageButton("Next ›", browsePage + 1,
                browsePage < pages - 1, false));
    }

    private Button browsePageButton(String label, int targetPage, boolean enabled, boolean active) {
        Button button = new Button(label);
        button.getStyleClass().add("cf-browse-page-button");
        if (active) button.getStyleClass().add("cf-browse-page-current");
        button.setDisable(!enabled || active);
        button.setOnAction(event -> {
            browsePage = targetPage;
            displayBrowsePage();
            if (browseScroller != null) browseScroller.setVvalue(0);
        });
        return button;
    }

    private Button photoCard(Item it, DoubleBinding width, boolean sample) {
        return photoCard(it, width, sample, false);
    }

    private Button photoCard(Item it, DoubleBinding width, boolean sample, boolean compact) {
        StackPane media = new StackPane();
        media.getStyleClass().add("gallery-media");
        media.setMinWidth(0);
        media.prefWidthProperty().bind(width.subtract(2));
        media.prefHeightProperty().bind(compact ? Bindings.min(64, width.multiply(0.32)) : width.multiply(0.49));
        media.minHeightProperty().bind(media.prefHeightProperty());
        media.maxHeightProperty().bind(media.prefHeightProperty());
        if (it.photo != null) {
            ImageView image = new ImageView(it.photo);
            image.setManaged(false);
            image.fitWidthProperty().bind(media.widthProperty());
            image.fitHeightProperty().bind(media.heightProperty());
            image.viewportProperty().bind(Bindings.createObjectBinding(() -> {
                double iw = it.photo.getWidth(), ih = it.photo.getHeight();
                if (iw <= 0 || ih <= 0) return null; // image may still be loading
                double ratio = Math.max(1, media.getWidth()) / Math.max(1, media.getHeight());
                double w = Math.min(iw, ih * ratio), h = Math.min(ih, iw / ratio);
                return new Rectangle2D((iw - w) / 2, (ih - h) / 2, w, h);
            }, media.widthProperty(), media.heightProperty(),
                    it.photo.widthProperty(), it.photo.heightProperty()));
            media.getChildren().add(image);
        } else {
            VBox placeholder = new VBox(6, new Group(svg(ICON_CAMERA, 28, Theme.muted)), smallGrey(it.category));
            placeholder.setAlignment(Pos.CENTER);
            media.getChildren().add(placeholder);
        }
        Rectangle clip = new Rectangle();
        clip.widthProperty().bind(media.widthProperty());
        clip.heightProperty().bind(media.heightProperty());
        clip.setArcWidth(16);
        clip.setArcHeight(16);
        media.setClip(clip);
        boolean found = it.type.equals("Found");
        Label tag = pillLabel(it.type, found ? "#e4f0ff" : "#fff0bd", found ? "#1559c8" : "#661f28");
        media.getChildren().add(tag);
        StackPane.setAlignment(tag, Pos.TOP_LEFT);
        StackPane.setMargin(tag, new Insets(10));
        Label title = new Label(it.title);
        title.getStyleClass().add("gallery-title");
        title.setMinWidth(0);
        title.maxWidthProperty().bind(width.subtract(30));
        Tooltip.install(title, new Tooltip(it.title));
        Label place = smallGrey(it.location + "  ·  " + it.date.format(DATE_FMT));
        place.setMinWidth(0);
        place.maxWidthProperty().bind(width.subtract(30));
        VBox caption = new VBox(4, title, place);
        caption.setPadding(compact ? new Insets(5, 10, 6, 10) : new Insets(9, 14, 12, 14));
        String status = statusOf(it);
        caption.getChildren().add(statusChip(it));
        if (!compact && !sample && found && !it.claimed) caption.getChildren().add(countdownChip(it));
        // KITA AI matching remains available in the assistant/detail pages.
        // Running it once for every gallery card made large browse sets slow.
        VBox face = new VBox(media, caption);
        face.prefWidthProperty().bind(width.subtract(2));
        Button card = new Button();
        card.setGraphic(face);
        card.getStyleClass().add("gallery-card");
        card.prefWidthProperty().bind(width);
        card.setMinWidth(0);
        card.setAccessibleText(it.type + " " + it.title + ", " + it.location);
        card.setOnAction(e -> {
            if (sample) popup("Sample item", new VBox(10, itemPicture(it, 340, 180),
                    sectionTitle(it.title), wrapLabel(it.description), smallGrey("Preview only · " + it.location)));
            else showItemDetail(it);
        });
        return card;
    }

    // =====================================================
    // ADMIN PANEL
    // =====================================================
    private Runnable adminRefresh = () -> { };
    private String adminReportsTab = "Available";
    private String auditTab = "All";

    private static final DateTimeFormatter LOG_FMT = DateTimeFormatter.ofPattern("MMM d, h:mm a");

    private void refreshAdmin() {
        adminRefresh.run();
    }

    private void showReports() {
        adminRefresh = this::showReports;
        openScreen(buildAdminReports(), reportsNav, false, false);
    }

    private void showAdminClaims() {
        adminRefresh = this::showAdminClaims;
        openScreen(pageOf(pageTitle("Claim review"), buildClaimsTab()), claimsNav, false, false);
    }

    private void showAudit() {
        adminRefresh = this::showAudit;
        openScreen(buildAuditView(), auditNav, false, false);
    }

    private int userCount() {
        Set<String> names = new HashSet<>();
        for (UserService.Account a : UserService.accounts()) names.add(a.name.toLowerCase());
        names.addAll(users.keySet());
        return names.size();
    }

    private int newUsersSince(LocalDateTime from) {
        Set<String> seen = new HashSet<>();
        int n = 0;
        for (UserService.Account a : UserService.accounts()) {
            seen.add(a.name.toLowerCase());
            if (a.created.isAfter(from)) n++;
        }
        for (Map.Entry<String, LocalDateTime> en : userSince.entrySet()) {
            if (!seen.contains(en.getKey()) && en.getValue().isAfter(from)) n++;
        }
        return n;
    }

    // ---------- Admin Dashboard ----------
    private HBox statTile(String title, String value, String note, String color, String icon) {
        boolean pending = title.toLowerCase().contains("pending");
        color = Theme.readable(pending ? "#a76b00" : "#1559c8", Theme.panel);
        StackPane bubble = new StackPane(new Group(svg(icon, 22, color)));
        bubble.setMinSize(36, 36);
        bubble.setMaxSize(36, 36);
        bubble.setStyle("-fx-background-color: " + soft(color) + "; -fx-background-radius: 10;");
        Label label = new Label(title);
        label.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: 12px;");
        Label number = new Label(value);
        number.setStyle("-fx-font-family: Serif; -fx-font-size: 25px; -fx-font-weight: bold; -fx-text-fill: -cf-ink;");
        VBox text = new VBox(0, label, number);
        text.setMinWidth(0);
        HBox card = new HBox(12, bubble, text);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setPadding(new Insets(9, 12, 9, 12));
        card.setPrefWidth(0);
        card.setMinWidth(0);
        card.setMaxWidth(Double.MAX_VALUE);
        card.setStyle(CARD);
        card.setAccessibleText(title + ": " + value + ". " + note);
        Tooltip.install(card, new Tooltip(note));
        HBox.setHgrow(card, Priority.ALWAYS);
        return card;
    }

    private VBox quickTile(String text, String icon, String color, Runnable action) {
        StackPane bubble = new StackPane(new Group(svg(icon, 22, color)));
        bubble.setMinSize(36, 36);
        bubble.setPrefSize(36, 36);
        bubble.setMaxSize(36, 36);
        bubble.setStyle("-fx-background-color: " + soft(color) + "; -fx-background-radius: 23;");

        Label l = new Label(text);
        l.setWrapText(true);
        l.setAlignment(Pos.CENTER);
        l.setStyle("-fx-font-size: 12px; -fx-text-fill: " + DARK + ";");

        VBox tile = new VBox(8, bubble, l);
        tile.setAlignment(Pos.CENTER);
        tile.setPadding(new Insets(8, 6, 8, 6));
        tile.setPrefWidth(0);
        tile.setMaxWidth(Double.MAX_VALUE);
        tile.setCursor(Cursor.HAND);
        tile.setStyle(CARD);
        tile.setOnMouseClicked(e -> action.run());
        HBox.setHgrow(tile, Priority.ALWAYS);
        return tile;
    }

    // admin = true: chip shows Pending / Available / Resolved. student: Lost / Found
    private HBox activityRow(Item it, boolean forAdmin) {
        Label title = new Label(it.title);
        title.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label kind = new Label(it.type);
        kind.setStyle("-fx-text-fill: " + kindColor(it) + "; -fx-font-weight: bold; -fx-font-size: 12px;");
        Label when = new Label("•  " + ago(it.created));
        when.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        VBox info = new VBox(3, title, new HBox(5, kind, when));
        HBox.setHgrow(info, Priority.ALWAYS);

        boolean lost = it.type.equals("Lost");
        String text;
        String bg;
        String fg;
        if (forAdmin) {
            if (it.claimed) { text = "Resolved"; bg = "#dcfce7"; fg = "#15803d"; }
            else if (lost) { text = "Pending"; bg = "#fef3c7"; fg = "#b45309"; }
            else { text = "Available"; bg = "#d1fae5"; fg = "#047857"; }
        } else {
            text = it.type;
            bg = lost ? "#fee2e2" : "#d1fae5";
            fg = lost ? "#b91c1c" : "#047857";
        }
        Label chip = new Label(text);
        chip.setStyle("-fx-background-color: " + bg + "; -fx-text-fill: " + fg + "; "
                + "-fx-font-weight: bold; -fx-font-size: 12px; -fx-background-radius: 12; -fx-padding: 4 14 4 14;");

        HBox row = new HBox(12, itemPicture(it, 40, 40), info, chip);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(10));
        row.setCursor(Cursor.HAND);
        row.setStyle(CARD);
        row.setOnMouseClicked(e -> showItemDetail(it));
        return row;
    }

    // ---------- Reports ----------
    private Node buildAdminReports() {
        Label sub = new Label("All lost and found reports on campus.");
        sub.setStyle("-fx-text-fill: " + GREY_TEXT + ";");

        FlowPane seg = new FlowPane(8, 8);
        FlowPane types = new FlowPane(8, 8);
        for (String t : new String[]{"Available", "Claims in progress", "Recovered", "Lost", "Found", "Unclaimed", "All"}) {
            Button b = new Button(t);
            styleChip(b, t.equals(adminReportsTab));
            b.setOnAction(e -> {
                adminReportsTab = t;
                showReports();
            });
            (List.of("Available", "Claims in progress", "Recovered").contains(t) ? seg : types).getChildren().add(b);
        }

        Node body;
        if (adminReportsTab.equals("Available") || adminReportsTab.equals("Claims in progress")) {
            VBox list = new VBox(8);
            for (int i = items.size() - 1; i >= 0; i--) {
                Item item = items.get(i);
                boolean available = statusOf(item).equals("Open");
                boolean inProgress = !item.claimed && !available;
                if (adminReportsTab.equals("Available") ? available : inProgress) list.getChildren().add(buildAdminRow(item));
            }
            if (list.getChildren().isEmpty()) list.getChildren().add(emptyState(ICON_LIST, Theme.BLUE, "No items in this section", "Reports appear here as items are posted and claims progress.", null, null));
            body = new VBox(10, sectionTitle(adminReportsTab.equals("Available")
                    ? "Available found items and unresolved lost reports" : "Items with active claims"), list);
        } else if (adminReportsTab.equals("Lost") || adminReportsTab.equals("Found")) {
            body = buildReportsTab(adminReportsTab);
        } else if (adminReportsTab.equals("Recovered")) {
            body = buildRecoveredTab();
        } else if (adminReportsTab.equals("Unclaimed")) {
            body = buildUnclaimedTab();
        } else {
            VBox list = new VBox(8);
            for (int i = items.size() - 1; i >= 0; i--) {
                list.getChildren().add(buildAdminRow(items.get(i)));
            }
            if (items.isEmpty()) list.getChildren().add(emptyLine("No reports yet."));
            VBox card = new VBox(10, sectionTitle("All reports (" + items.size() + ")"), list);
            card.setPadding(new Insets(14));
            card.setStyle(CARD);
            body = card;
        }
        Button export = new Button("Export CSV");
        export.setStyle(smallBtn());
        export.setOnAction(e -> exportCsv());
        Region exGap = new Region();
        HBox.setHgrow(exGap, Priority.ALWAYS);
        HBox topRow = new HBox(10, pageTitle("Reports"), exGap, export);
        topRow.setAlignment(Pos.CENTER_LEFT);
        VBox results = new VBox(14, seg, types, body);
        results.setPadding(new Insets(18));
        results.setStyle(CARD);
        return pageOf(topRow, sub, results);
    }

    // ---------- Users ----------
    private void confirmDeleteAccount(UserService.Account a) {
        int reports = 0;
        for (Item it : items) {
            if (it.reporter.equalsIgnoreCase(a.name)) reports++;
        }
        int myClaims = 0;
        for (Claim c : claims) {
            if (c.accountId.equalsIgnoreCase(a.studentId)) myClaims++;
        }
        VBox body = new VBox(8, wrapLabel("Delete the account of " + a.name + " (graduated " + a.gradYear
                + ")? This also removes " + reports + " report(s) with their photos, " + myClaims
                + " claim(s) and all chats of this account. It cannot be undone."));
        confirmBox("Delete account", body, "Delete", () -> deleteAccountAndFiles(a));
    }

    private void deleteAccountAndFiles(UserService.Account a) {
        String name = a.name;
        List<Item> mine = new ArrayList<>();
        for (Item it : items) {
            if (it.reporter.equalsIgnoreCase(name)) mine.add(it);
        }
        items.removeAll(mine);
        claims.removeIf(c -> c.accountId.equalsIgnoreCase(a.studentId) || mine.contains(c.item));
        messages.removeIf(m -> m.from.equalsIgnoreCase(name) || m.to.equalsIgnoreCase(name)
                || mine.contains(m.item));
        users.remove(name.toLowerCase());
        userSince.remove(name.toLowerCase());
        UserService.accounts().remove(a);
        UserService.saveAccounts();
        audit(CurrentUser.getName(), "User account deleted (graduated)", name + ", " + mine.size() + " report(s) removed");
        updateMessagesBadge();
        refresh();
        refreshAdmin();
    }

    // popup with Cancel + a red confirm button
    private void confirmBox(String heading, Node body, String yesText, Runnable onYes) {
        Stage dialog = new Stage();
        dialog.initOwner(root.getScene().getWindow());
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.initStyle(StageStyle.TRANSPARENT);

        Label h = new Label(heading);
        h.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");

        boolean[] yes = new boolean[1];
        Button cancel = new Button("Cancel");
        cancel.setCancelButton(true);
        cancel.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: " + DARK + "; -fx-font-weight: bold; "
                + "-fx-background-radius: 6; -fx-padding: 8 20 8 20; -fx-cursor: hand;");
        cancel.setOnAction(e -> dialog.close());
        Button ok = new Button(yesText);
        ok.setStyle("-fx-background-color: #dc2626; -fx-text-fill: white; -fx-font-weight: bold; "
                + "-fx-background-radius: 6; -fx-padding: 8 20 8 20; -fx-cursor: hand;");
        ok.setOnAction(e -> {
            yes[0] = true;
            dialog.close();
        });
        HBox buttons = new HBox(10, cancel, ok);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        VBox box = new VBox(12, h, body, buttons);
        box.setPadding(new Insets(22));
        box.setPrefWidth(440);
        box.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 12; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.35), 18, 0, 0, 4);");
        StackPane wrapper = new StackPane(box);
        wrapper.setPadding(new Insets(20));
        wrapper.setStyle("-fx-background-color: transparent;");
        CampusStyle.install(wrapper);
        Scene scene = new Scene(wrapper);
        scene.setFill(Color.TRANSPARENT);
        dialog.setScene(scene);
        dialog.showAndWait();

        if (yes[0]) onYes.run();
    }

    // ---------- Audit Logs ----------
    private Node buildAuditView() {
        Label sub = new Label("A record of everything that happens in the system.");
        sub.setStyle("-fx-text-fill: " + GREY_TEXT + ";");

        FlowPane seg = new FlowPane(8, 8);
        for (String t : new String[]{"All", "Reports", "Claims", "Users"}) {
            Button b = new Button(t);
            styleChip(b, t.equals(auditTab));
            b.setOnAction(e -> {
                auditTab = t;
                showAudit();
            });
            seg.getChildren().add(b);
        }

        VBox list = new VBox(0);
        int shown = 0;
        for (int i = auditLog.size() - 1; i >= 0; i--) {
            LogEntry le = auditLog.get(i);
            String a = le.action.toLowerCase();
            boolean isClaim = a.contains("claim") || a.contains("approval");
            boolean isUser = a.contains("user") || a.contains("logged") || a.contains("password");
            boolean isReport = !isClaim && !isUser;
            if (auditTab.equals("Reports") && !isReport) continue;
            if (auditTab.equals("Claims") && !isClaim) continue;
            if (auditTab.equals("Users") && !isUser) continue;

            Label when = new Label(le.time.format(LOG_FMT));
            col(when, 160);
            when.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
            Label who = new Label(le.actor);
            col(who, 160);
            who.setStyle("-fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
            Label what = new Label(le.action + " (" + le.detail + ")");
            what.setWrapText(true);
            what.setStyle("-fx-text-fill: -cf-ink;");
            HBox.setHgrow(what, Priority.ALWAYS);

            HBox row = new HBox(10, when, who, what);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(12, 14, 12, 14));
            if (shown > 0) list.getChildren().add(new Separator());
            list.getChildren().add(row);
            shown++;
        }
        if (shown == 0) {
            list.getChildren().add(emptyLine("No activity yet."));
            list.setPadding(new Insets(24));
        }

        HBox header = new HBox(10, headerCell("TIME", 160), headerCell("USER", 160), headerCell("ACTIVITY", -1));
        header.setPadding(new Insets(14));
        header.getStyleClass().add("table-heading");
        VBox card = new VBox(header, new Separator(), list);
        card.setStyle(CARD);
        return pageOf(pageTitle("Audit Logs"), sub, seg, card);
    }

    // =====================================================
    // SMALL SHARED HELPERS (new)
    // =====================================================

    // sets a fixed width on a node, used to line up table columns
    private static <T extends Region> T col(T r, double w) {
        r.setMinWidth(w);
        r.setPrefWidth(w);
        r.setMaxWidth(w);
        return r;
    }

    private Label pillLabel(String text, String bg, String fg) {
        Label l = new Label(text);
        l.setStyle("-fx-background-color: " + bg + "; -fx-text-fill: " + fg + "; "
                + "-fx-font-weight: bold; -fx-font-size: 11.5px; "
                + "-fx-background-radius: 10; -fx-padding: 2 10 2 10;");
        return l;
    }

    // a friendly "nothing here yet" box with an optional button
    private Node emptyState(String icon, String color, String title, String text,
                            String btnText, Runnable action) {
        StackPane bubble = new StackPane(new Group(svg(icon, 24, color)));
        bubble.setMinSize(38, 38);
        bubble.setPrefSize(38, 38);
        bubble.setMaxSize(38, 38);
        bubble.setStyle("-fx-background-color: " + soft(color) + "; -fx-background-radius: 19;");

        Label t = new Label(title);
        t.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label d = new Label(text);
        d.setWrapText(true);
        d.setMaxWidth(640);
        d.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        d.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");

        VBox box = new VBox(5, bubble, t, d);
        if (btnText != null && action != null) {
            Button b = new Button(btnText);
            b.setStyle(smallSolidBtn());
            b.setOnAction(e -> action.run());
            box.getChildren().add(b);
        }
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(10));
        box.setMaxWidth(Double.MAX_VALUE);
        box.getStyleClass().add("empty-state");
        return box;
    }

    // =====================================================
    // ADMIN DASHBOARD (upgraded)
    // =====================================================
    private Node dashboardColumns(VBox left, VBox right) {
        javafx.scene.layout.GridPane columns = new javafx.scene.layout.GridPane();
        columns.setHgap(14);
        columns.setVgap(14);
        left.setMinWidth(0);
        right.setMinWidth(0);
        columns.add(left, 0, 0);
        columns.add(right, 1, 0);
        javafx.scene.layout.ColumnConstraints first = new javafx.scene.layout.ColumnConstraints();
        javafx.scene.layout.ColumnConstraints second = new javafx.scene.layout.ColumnConstraints();
        second.setPercentWidth(44);
        Runnable fit = () -> {
            boolean stacked = columns.getWidth() < 960;
            first.setPercentWidth(stacked ? 100 : 56);
            if (stacked) columns.getColumnConstraints().setAll(first);
            else columns.getColumnConstraints().setAll(first, second);
            javafx.scene.layout.GridPane.setColumnIndex(right, stacked ? 0 : 1);
            javafx.scene.layout.GridPane.setRowIndex(right, stacked ? 1 : 0);
        };
        fit.run();
        columns.widthProperty().addListener((obs, old, width) -> {
            if ((old.doubleValue() < 960) != (width.doubleValue() < 960)) fit.run();
        });
        return columns;
    }

    private Node dashboardGrid(double breakpoint, double[] widths, Node... cards) {
        javafx.scene.layout.GridPane grid = new javafx.scene.layout.GridPane();
        grid.setHgap(10); grid.setVgap(8);
        for (Node card : cards) {
            if (card instanceof Region region) region.setMinWidth(0);
            grid.getChildren().add(card);
            javafx.scene.layout.GridPane.setValignment(card, javafx.geometry.VPos.TOP);
            javafx.scene.layout.GridPane.setFillHeight(card, true);
        }
        Runnable arrange = () -> {
            boolean stacked = grid.getWidth() < breakpoint;
            grid.getColumnConstraints().clear();
            for (int i = 0; i < (stacked ? 1 : cards.length); i++) {
                javafx.scene.layout.ColumnConstraints col = new javafx.scene.layout.ColumnConstraints();
                col.setPercentWidth(stacked ? 100 : widths[i]);
                grid.getColumnConstraints().add(col);
            }
            for (int i = 0; i < cards.length; i++)
                javafx.scene.layout.GridPane.setConstraints(cards[i], stacked ? 0 : i, stacked ? i : 0);
        };
        grid.widthProperty().addListener((o, old, value) -> {
            if ((old.doubleValue() < breakpoint) != (value.doubleValue() < breakpoint)) arrange.run();
        });
        arrange.run();
        return grid;
    }

    /** Keep Student Dashboard cards at their natural height instead of
     * expanding Search and Quick Actions to fill an unexpectedly tall grid row.
     * Responsive column stacking is delegated to the existing dashboardGrid.
     */
    private Node studentDashboardGrid(double breakpoint, double[] widths, Node... cards) {
        Node grid = dashboardGrid(breakpoint, widths, cards);
        for (Node card : cards) {
            javafx.scene.layout.GridPane.setFillHeight(card, false);
            javafx.scene.layout.GridPane.setValignment(card, javafx.geometry.VPos.TOP);
        }
        return grid;
    }

    /**
     * Dashboard cards keep their natural height. The page itself owns the vertical
     * scrollbar, so buttons and whole cards remain reachable even on short screens.
     * This also avoids competing nested scrollbars under the mouse wheel.
     */
    private ScrollPane scrollingDashboard(Node... sections) {
        ScrollPane page = pageOf(sections);
        page.setFitToWidth(true);
        page.setPannable(true);
        page.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        page.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        page.setMinSize(0, 0);
        return page;
    }

    /**
     * One shared, photo-backed welcome banner for both Admin and Student dashboards.
     * A real ImageView is used here rather than a CSS BackgroundImage: the earlier
     * background could be visually replaced by Region CSS styles at runtime.
     */
    private Node campusBanner(boolean forAdmin) {
        StackPane banner = new StackPane();
        banner.getStyleClass().add("campus-banner");
        banner.setMinHeight(112);
        banner.setPrefHeight(126);
        banner.setMaxHeight(138);
        banner.setMinWidth(0);
        banner.setStyle("-fx-background-color: #082c70; -fx-background-radius: 16; "
                + "-fx-border-radius: 16; -fx-border-color: rgba(14,80,169,0.20);");
        roundClip(banner, 16);

        // Crop the original photograph to fill wide desktop banners without stretching it.
        // Keep the amphitheater and the NORSU buildings within the horizontal strip.
        Image image = new Image(main.class.getResource("norsu-courtyard-photo.png").toExternalForm());
        ImageView courtyard = new ImageView(image);
        courtyard.setSmooth(true);
        courtyard.setPreserveRatio(false);
        courtyard.setMouseTransparent(true);
        courtyard.fitWidthProperty().bind(banner.widthProperty());
        courtyard.fitHeightProperty().bind(banner.heightProperty());
        Runnable frameImage = () -> {
            double w = banner.getWidth(), h = banner.getHeight();
            if (w <= 0 || h <= 0 || image.getWidth() <= 0 || image.getHeight() <= 0) return;
            double photoW = image.getWidth(), photoH = image.getHeight();
            double bannerRatio = w / h, photoRatio = photoW / photoH;
            double cropW = photoW, cropH = photoH;
            if (photoRatio > bannerRatio) cropW = photoH * bannerRatio;
            else cropH = photoW / bannerRatio;
            double cropX = Math.max(0, (photoW - cropW) / 2);
            double cropY = Math.max(0, Math.min(photoH - cropH, photoH * 0.61 - cropH / 2));
            courtyard.setViewport(new Rectangle2D(cropX, cropY, cropW, cropH));
        };
        banner.widthProperty().addListener((obs, old, width) -> frameImage.run());
        banner.heightProperty().addListener((obs, old, height) -> frameImage.run());

        // Dark on the left for readable text; the courtyard remains clear on the right.
        Pane shade = new Pane();
        shade.setStyle("-fx-background-color: linear-gradient(to right, "
                + "rgba(5,30,83,0.99) 0%, rgba(7,47,116,0.96) 24%, "
                + "rgba(7,47,116,0.48) 46%, rgba(7,47,116,0.02) 85%);");
        shade.setMouseTransparent(true);

        // Thin curved golden wave across the bottom matches the approved NORSU design.
        Path yellowWave = new Path();
        yellowWave.setFill(Color.web("#FFCA23"));
        yellowWave.setStroke(null);
        yellowWave.setManaged(false);
        yellowWave.setMouseTransparent(true);
        Runnable frameWave = () -> {
            double w = banner.getWidth(), h = banner.getHeight();
            if (w <= 0 || h <= 0) return;
            yellowWave.getElements().setAll(
                    new MoveTo(0, h - 10),
                    new javafx.scene.shape.CubicCurveTo(w * 0.18, h + 3, w * 0.49, h + 2, w * 0.68, h - 8),
                    new javafx.scene.shape.CubicCurveTo(w * 0.86, h - 16, w * 0.96, h - 25, w, h - 22),
                    new LineTo(w, h), new LineTo(0, h), new ClosePath());
        };
        banner.widthProperty().addListener((obs, old, width) -> frameWave.run());
        banner.heightProperty().addListener((obs, old, height) -> frameWave.run());

        javafx.scene.text.Text welcomePrefix = new javafx.scene.text.Text("Welcome back, ");
        javafx.scene.text.Text welcomeAccent = new javafx.scene.text.Text(
                forAdmin ? "Admin!" : firstWord(CurrentUser.getName()) + "!");
        for (javafx.scene.text.Text part : new javafx.scene.text.Text[]{welcomePrefix, welcomeAccent})
            part.setStyle("-fx-font-size: 29px; -fx-font-family: 'Segoe UI'; -fx-font-weight: bold;");
        welcomePrefix.setFill(Color.WHITE);
        welcomeAccent.setFill(Color.web("#ffca23"));
        javafx.scene.text.TextFlow welcome = new javafx.scene.text.TextFlow(welcomePrefix, welcomeAccent);
        Label desc = new Label(forAdmin
                ? "Manage lost and found items, claims, users, and campus activity."
                : "Report, find, and claim lost items around the NORSU campus.");
        desc.setStyle("-fx-text-fill: #f2f7ff; -fx-font-size: 12px;");
        desc.setWrapText(true);
        Button heroAction = new Button(forAdmin ? "View Reports" : "Report an Item");
        heroAction.setOnAction(e -> { if (forAdmin) showReports(); else showReport("Lost"); });
        heroAction.setStyle("-fx-background-color: #ffca23; -fx-text-fill: #082c70; "
                + "-fx-font-weight: bold; -fx-font-size: 12px; -fx-background-radius: 18; "
                + "-fx-padding: 6 18; -fx-cursor: hand;");
        VBox labels = new VBox(7, welcome, desc, heroAction);
        labels.setAlignment(Pos.CENTER_LEFT);
        labels.setMaxWidth(490);
        labels.setPadding(new Insets(9, 20, 13, 25));
        StackPane.setAlignment(labels, Pos.CENTER_LEFT);
        // University plaque makes the shared campus banner match the approved design.
        ImageView seal = officialSeal(34);
        Label plaqueTitle = new Label("NEGROS ORIENTAL\nSTATE UNIVERSITY");
        plaqueTitle.setStyle("-fx-font-size: 11px; -fx-font-weight: bold; -fx-text-fill: #082e72;");
        HBox plaque = new HBox(8, seal, plaqueTitle);
        plaque.setAlignment(Pos.CENTER_LEFT);
        plaque.setPadding(new Insets(6, 10, 6, 9));
        plaque.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
        plaque.setStyle("-fx-background-color: rgba(245,250,255,0.90); -fx-background-radius: 10; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,25,70,0.20), 10, 0, 0, 2);");
        StackPane.setAlignment(plaque, Pos.TOP_RIGHT);
        StackPane.setMargin(plaque, new Insets(11, 14, 0, 0));
        banner.getChildren().addAll(courtyard, shade, yellowWave, labels, plaque);
        return banner;
    }

    // Compact reference dashboard: all primary content fits a standard desktop
    // window; only smaller windows scroll rather than crop or shrink text.
private Node buildAdminDashboard() {
    int recovered = (int) items.stream().filter(it -> it.claimed).count();
    int pending = countClaims("Pending");
    int approved = countClaims("Approved");
    int overdue = (int) items.stream().filter(main::isUnclaimedOverdue).count();
    int activeReports = (int) items.stream().filter(it -> !it.claimed).count();
    Node stats = dashboardGrid(780, new double[]{25, 25, 25, 25},
            premiumStat("Total Users", userCount(), ICON_USERS, "#1559c8"),
            premiumStat("Active Reports", activeReports, ICON_LIST, "#1559c8"),
            premiumStat("Resolved Cases", recovered, ICON_CHECK, "#168246"),
            premiumStat("Pending Claims", pending, ICON_CLAIM, "#efb400"));

    VBox needs = premiumDashboardPanel("Needs Attention");
    needs.setId("cf-admin-attention");
    needs.getChildren().add(premiumAttentionRow("Pending Claim Requests", pending,
            "Require verification and review", () -> {
                selectedClaim = null; claimsSection = "Needs verification"; showAdminClaims();
            }));
    needs.getChildren().add(premiumAttentionRow("Overdue Items", overdue,
            "Unclaimed items need a decision", () -> {
                adminReportsTab = "Unclaimed"; showReports();
            }));
    if (approved > 0) needs.getChildren().add(premiumAttentionRow("Approved Handovers", approved,
            "Awaiting owner pickup", () -> {
                selectedClaim = null; claimsSection = "Awaiting handover"; showAdminClaims();
            }));
    if (pending + approved + overdue == 0) needs.getChildren().add(
            compactEmptyHint("All caught up! New claims and overdue reports will appear here."));
    Button review = dashboardAccentAction("Review claims", ICON_CLAIM, this::showAdminClaims);
    needs.getChildren().add(review);

    VBox activity = premiumDashboardPanel("Recent Activity");
    activity.setId("cf-admin-activity");
    int shown = 0;
    for (int i = auditLog.size() - 1; i >= 0 && shown < 3; i--) {
        LogEntry entry = auditLog.get(i);
        Label action = new Label(entry.action);
        action.setStyle("-fx-text-fill: #112f64; -fx-font-size: 12px; -fx-font-weight: bold;");
        Label details = new Label(entry.detail == null ? "" : entry.detail);
        details.setWrapText(true);
        details.setStyle("-fx-text-fill: #516a8c; -fx-font-size: 11px;");
        VBox info = new VBox(2, action, details);
        info.setMinWidth(0);
        HBox.setHgrow(info, Priority.ALWAYS);
        HBox line = new HBox(9, premiumIcon(ICON_CHECK, "#145dc5", "#e7f0ff"), info);
        line.setAlignment(Pos.CENTER_LEFT);
        line.setPadding(new Insets(7, 4, 7, 4));
        line.setStyle("-fx-border-color: transparent transparent #e5edfa transparent;");
        activity.getChildren().add(line);
        shown++;
    }
    if (shown == 0) activity.getChildren().add(dashboardEmptyAction(
            "Nothing to review yet", "Activities appear here as people report and claim items.",
            "Manage reports", this::showReports));
    activity.getChildren().add(dashboardAccentAction("View activity logs", ICON_HISTORY, this::showAudit));

    VBox hotspot = premiumDashboardPanel("Campus Hotspots");
    hotspot.setId("cf-admin-hotspots");
    Map<String, Integer> locations = new LinkedHashMap<>();
    for (Item it : items) if (it.location != null && !it.location.isBlank())
        locations.merge(it.location.trim(), 1, Integer::sum);
    List<Map.Entry<String, Integer>> frequent = new ArrayList<>(locations.entrySet());
    frequent.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
    StackPane scenePhoto = new StackPane();
    Image campusPhoto = new Image(main.class.getResource("norsu-courtyard-photo.png").toExternalForm());
    ImageView scene = new ImageView(campusPhoto);
    scene.setFitWidth(230); scene.setFitHeight(106); scene.setPreserveRatio(false);
    scenePhoto.getChildren().add(scene);
    scenePhoto.setClip(new Rectangle(230,106));
    scenePhoto.setMaxWidth(230);
    VBox locationRows = new VBox(6);
    if (frequent.isEmpty()) locationRows.getChildren().addAll(
            compactEmptyHint("Hotspots appear from actual report locations."),
            dashboardAccentAction("Browse reports", ICON_SEARCH, this::showReports));
    else {
        int max = frequent.get(0).getValue();
        for (int i = 0; i < Math.min(4, frequent.size()); i++) {
            var l = frequent.get(i);
            locationRows.getChildren().add(hotspotRow(l.getKey(), l.getValue(), max, i == 0, false));
        }
    }
    HBox hotspotBody = new HBox(12, locationRows, scenePhoto);
    HBox.setHgrow(locationRows, Priority.ALWAYS);
    hotspotBody.setAlignment(Pos.CENTER_LEFT);
    scenePhoto.visibleProperty().bind(hotspotBody.widthProperty().greaterThan(535));
    scenePhoto.managedProperty().bind(scenePhoto.visibleProperty());
    hotspot.getChildren().add(hotspotBody);

    VBox assistant = premiumDashboardPanel("KITA AI - Item Matching");
    assistant.setId("cf-admin-kita");
    List<Pair> matches = collectPairs();
    Label hint = new Label(matches.isEmpty()
            ? "KITA is ready to find possible matches when reports arrive."
            : matches.size() + " possible matches are available for review.");
    hint.setWrapText(true);
    hint.setStyle("-fx-text-fill: #365584; -fx-font-size: 12px;");
    Label heading = new Label("Find lost items faster");
    heading.setStyle("-fx-text-fill: #092e74; -fx-font-size: 16px; -fx-font-weight: bold;");
    VBox aiCopy = new VBox(6, heading, hint,
            dashboardAccentAction("Open KITA AI", ICON_SPARK, this::showAssistant));
    aiCopy.setMinWidth(0);
    HBox.setHgrow(aiCopy, Priority.ALWAYS);
    HBox aiBody = new HBox(16, aiIcon(92), aiCopy);
    aiBody.setPadding(new Insets(9));
    aiBody.setAlignment(Pos.CENTER_LEFT);
    assistant.getChildren().add(aiBody);

    VBox insights = premiumDashboardPanel("Reports Overview - Last 7 Days");
    insights.getChildren().add(premiumReportChart());
    VBox latest = premiumDashboardPanel("Recent Reports");
    int recent = 0;
    for (int i = items.size() - 1; i >= 0 && recent < 3; i--, recent++)
        latest.getChildren().add(adminReportRow(items.get(i)));
    if (recent == 0) latest.getChildren().add(compactEmptyHint("No reports yet. New items appear here."));
    latest.getChildren().add(dashboardAccentAction("View all reports", ICON_LIST, this::showReports));

    // Render the entire contents of each card; scroll the dashboard as one page.
    // The old fixed-height ScrollPane wrappers clipped lists and action buttons.
    Node firstRow = dashboardGrid(970, new double[]{34, 33, 33},
            needs, activity, insights);
    Node secondRow = dashboardGrid(970, new double[]{34, 33, 33},
            hotspot, latest, assistant);
    ScrollPane dashboard = scrollingDashboard(campusBanner(true), stats, firstRow, secondRow);
    VBox body = (VBox) ((StackPane) dashboard.getContent()).getChildren().getFirst();
    body.setSpacing(11);
    body.setPadding(new Insets(10, 16, 20, 16));
    dashboard.setId("admin-dashboard");
    return dashboard;
}

private Button dashboardAccentAction(String label, String icon, Runnable action) {
    Button button = new Button(label, new Group(svg(icon, 16, "#082e72")));
    button.setStyle("-fx-background-color: #ffca23; -fx-text-fill: #092e74; "
            + "-fx-font-weight: bold; -fx-background-radius: 19; -fx-padding: 8 15;");
    button.setCursor(Cursor.HAND);
    button.setOnAction(e -> action.run());
    return button;
}

        private VBox dashboardEmptyAction(String title, String message, String buttonTitle, Runnable action) {
        Label heading = new Label(title);
        heading.setStyle("-fx-font-weight: bold; -fx-font-size: 13px; -fx-text-fill: #163d82;");
        Label body = compactEmptyHint(message);
        Button button = new Button(buttonTitle);
        button.setStyle("-fx-background-color: #ffca23; -fx-text-fill: #092e74; "
                + "-fx-font-weight: bold; -fx-background-radius: 12; -fx-padding: 6 12;");
        button.setOnAction(e -> action.run());
        VBox state = new VBox(5, heading, body, button);
        state.setPadding(new Insets(7));
        state.setStyle("-fx-background-color: #f0f6ff; -fx-background-radius: 10;");
        return state;
    }

    private Label compactEmptyHint(String text) {
        Label hint = new Label(text);
        hint.setWrapText(true);
        hint.setStyle("-fx-text-fill: #566e93; -fx-font-size: 12px; -fx-padding: 6 1 6 1;");
        return hint;
    }

    private StackPane premiumIcon(String icon, String foreground, String background) {
        StackPane badge = new StackPane(new Group(svg(icon, 19, foreground)));
        badge.setMinSize(36,36); badge.setPrefSize(36,36); badge.setMaxSize(36,36);
        badge.setStyle("-fx-background-color: " + background + "; -fx-background-radius: 12;");
        return badge;
    }

    private HBox premiumStat(String label, int count, String icon, String color) {
        String fg = color.equals("#efb400") ? "#bd7800" : color;
        Label name = new Label(label);
        name.setStyle("-fx-font-size: 12px; -fx-text-fill: #526789; -fx-font-weight: bold;");
        Label number = new Label(Integer.toString(count));
        number.setStyle("-fx-font-size: 25px; -fx-font-weight: bold; -fx-text-fill: #092e74;");
        VBox values = new VBox(0, name, number);
        values.setMinWidth(0);
        HBox.setHgrow(values, Priority.ALWAYS);
        StackPane emblem = premiumIcon(icon, fg, "#eef4ff");
        emblem.setMinSize(44,44); emblem.setPrefSize(44,44); emblem.setMaxSize(44,44);
        HBox tile = new HBox(13, emblem, values);
        tile.setAlignment(Pos.CENTER_LEFT);
        tile.setPadding(new Insets(11,14,11,14));
        tile.setMinWidth(0);
        tile.setMaxWidth(Double.MAX_VALUE);
        tile.getStyleClass().add("cf-v2-stat");
        tile.setStyle("-fx-background-color: linear-gradient(to bottom, white, #f8fbff); -fx-background-radius: 16; "
                + "-fx-border-color: #cbdcf7 #cbdcf7 " + color + " #cbdcf7; "
                + "-fx-border-width: 1 1 4 1; -fx-border-radius: 16; "
                + "-fx-effect: dropshadow(gaussian, rgba(8,67,159,0.11), 12, 0, 0, 3);");
        return tile;
    }

    private VBox premiumDashboardPanel(String title) {
        Label heading = new Label(title);
        heading.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: white;");
        HBox head = new HBox(9, new Group(svg(ICON_DASH, 17, "#ffca23")), heading);
        head.setAlignment(Pos.CENTER_LEFT);
        head.getStyleClass().add("cf-v2-panel-heading");
        heading.setWrapText(true);
        head.setPadding(new Insets(9, 13, 9, 13));
        head.setStyle("-fx-background-color: linear-gradient(to right, #07286a, #1559c8); "
                + "-fx-background-radius: 13 13 0 0;");
        VBox pane = new VBox(9, head);
        pane.getStyleClass().add("cf-v2-panel");
        pane.setMinWidth(0);
        pane.setMaxWidth(Double.MAX_VALUE);
        pane.setMaxHeight(Double.MAX_VALUE);
        pane.setPadding(new Insets(0, 11, 12, 11));
        // Allow the title band to reach the card edges.
        VBox.setMargin(head, new Insets(0, -11, 3, -11));
        pane.setStyle("-fx-background-color: white; -fx-background-radius: 14; "
                + "-fx-border-color: #c8d9f5; -fx-border-radius: 14; "
                + "-fx-effect: dropshadow(gaussian, rgba(17,74,150,0.10), 10, 0, 0, 3);");
        return pane;
    }

    private Node premiumAttentionRow(String title, int count, String detail, Runnable action) {
        Label number=new Label(Integer.toString(count));
        number.setStyle("-fx-font-weight: bold; -fx-font-size: 17px; -fx-text-fill: "
                +(count>0?"#bb1d32":"#436182")+";");
        Label heading=new Label(title);
        heading.setStyle("-fx-font-weight: bold; -fx-text-fill: #0f2b61; -fx-font-size: 12px;");
        Label sub=new Label(detail);
        sub.setStyle("-fx-font-size: 11px; -fx-text-fill: #617494;");
        sub.setWrapText(true);
        VBox labels=new VBox(1,heading,sub);
        labels.setMinWidth(0);
        HBox.setHgrow(labels,Priority.ALWAYS);
        HBox body=new HBox(9,premiumIcon(ICON_BELL,count>0?"#c83246":"#1e60b6",count>0?"#fee9eb":"#e9f2ff"),labels,number);
        body.setAlignment(Pos.CENTER_LEFT);
        body.setPadding(new Insets(5,7,5,7));
        body.setStyle("-fx-background-color: "+(count>0?"#fff2f3":"#f4f8ff")+"; -fx-background-radius: 11;");
        Button button=new Button();
        button.setGraphic(body);
        button.setMaxWidth(Double.MAX_VALUE);
        button.setMinWidth(0);
        button.setStyle("-fx-background-color: transparent; -fx-padding: 0; -fx-cursor: hand;");
        // A zero-count task stays readable and can still open its relevant section.
        button.setOnAction(e->action.run());
        return button;
    }

    private Node premiumReportChart() {
        javafx.scene.canvas.Canvas chart = new javafx.scene.canvas.Canvas(300,140);
        Runnable render = () -> {
            double width=chart.getWidth(), height=chart.getHeight();
            var g=chart.getGraphicsContext2D();
            g.clearRect(0,0,width,height);
            int[] lost=new int[7], found=new int[7];
            LocalDate today=LocalDate.now();
            for(Item item:items) {
                if(item.date==null)continue;
                long days=ChronoUnit.DAYS.between(item.date,today);
                if(days>=0&&days<7) {
                    int ix=6-(int)days;
                    if("Lost".equals(item.type))lost[ix]++; else if("Found".equals(item.type))found[ix]++;
                }
            }
            int max=1;
            for(int i=0;i<7;i++)max=Math.max(max,Math.max(lost[i],found[i]));
            double left=25,right=width-12,top=25,bottom=height-26;
            g.setStroke(javafx.scene.paint.Color.web("#e6effb"));
            g.setLineWidth(1);
            for(int k=0;k<=3;k++) {
                double y=top+(bottom-top)*k/3.0;
                g.strokeLine(left,y,right,y);
            }
            String[] series={"Lost","Found"};
            int[][] data={lost,found};
            String[] colors={"#125bc9","#ffba0e"};
            for(int s=0;s<2;s++) {
                g.setStroke(javafx.scene.paint.Color.web(colors[s]));
                g.setFill(javafx.scene.paint.Color.web(colors[s]));
                g.setLineWidth(2.3);
                for(int i=0;i<7;i++) {
                    double x=left+(right-left)*i/6.0;
                    double y=bottom-(bottom-top)*data[s][i]/max;
                    if(i>0) {
                        double xp=left+(right-left)*(i-1)/6.0;
                        double yp=bottom-(bottom-top)*data[s][i-1]/max;
                        g.strokeLine(xp,yp,x,y);
                    }
                    g.fillOval(x-3,y-3,6,6);
                }
            }
            g.setFill(javafx.scene.paint.Color.web("#617494"));
            g.setFont(javafx.scene.text.Font.font("Segoe UI",10));
            for(int i=0;i<7;i++){
                LocalDate day=today.minusDays(6-i);
                String text=day.getDayOfWeek().name().substring(0,3);
                g.fillText(text,left+(right-left)*i/6.0-9,height-8);
            }
            g.setFill(javafx.scene.paint.Color.web(colors[0])); g.fillText("Lost reports",left,13);
            g.setFill(javafx.scene.paint.Color.web(colors[1])); g.fillText("Found reports",left+100,13);
        };
        chart.widthProperty().addListener((o,old,v)->render.run());
        chart.setWidth(350);
        render.run();
        StackPane holder=new StackPane(chart);
        holder.setMinWidth(0);
        holder.widthProperty().addListener((o,old,v)->chart.setWidth(Math.max(220,v.doubleValue()-4)));
        return holder;
    }

    private record AdminTask(Item item, String task, String waiting, Runnable action) {}

    private Button queueShortcut(String title, int count, Runnable action) {
        Button button = new Button(title + " (" + count + ")");
        button.setAccessibleText(title);
        button.setStyle(smallBtn());
        button.setOnAction(e -> action.run());
        return button;
    }

    private Node taskRow(AdminTask task) {
        javafx.scene.layout.GridPane row = new javafx.scene.layout.GridPane();
        for (double percent : new double[]{40, 25, 19, 16}) {
            javafx.scene.layout.ColumnConstraints col = new javafx.scene.layout.ColumnConstraints();
            col.setPercentWidth(percent);
            row.getColumnConstraints().add(col);
        }
        row.setHgap(10);
        row.setPadding(new Insets(9, 0, 9, 0));
        row.setStyle("-fx-border-color: transparent transparent -cf-edge transparent;");
        if (task == null) {
            String[] labels = {"Item", "Task", "Waiting", "Action"};
            for (int i = 0; i < 4; i++) row.add(fieldLabel(labels[i]), i, 0);
        } else {
            Label name = fieldLabel(task.item.title);
            name.setMinWidth(0);
            HBox.setHgrow(name, Priority.ALWAYS);
            HBox item = new HBox(10, itemPicture(task.item, 38, 38), name);
            item.setAlignment(Pos.CENTER_LEFT);
            item.setMinWidth(0);
            Label kind = wrapLabel(task.task);
            if (task.task.equals("Overdue")) kind.setStyle("-fx-text-fill: -cf-danger;");
            Label waiting = wrapLabel(task.waiting);
            waiting.setMinWidth(0);
            Button action = new Button(task.task.equals("Ready for pickup") ? "Open" : "Review");
            action.setAccessibleText(task.task + ": " + task.item.title);
            action.setStyle(smallSolidBtn());
            action.setOnAction(e -> task.action.run());
            row.add(item, 0, 0);
            row.add(kind, 1, 0);
            row.add(waiting, 2, 0);
            row.add(action, 3, 0);
        }
        return row;
    }

    private Node buildNeedsAttention() {
        VBox panel = new VBox(8, sectionTitle("Needs attention"));
        panel.setId("needs-attention");
        panel.setPadding(new Insets(12));
        panel.setStyle(CARD);
        int pending = countClaims("Pending");
        int handover = countClaims("Approved");
        long overdue = items.stream().filter(main::isUnclaimedOverdue).count();
        panel.getChildren().add(attentionAction(pending + " claims awaiting review", "Review claims", pending, () -> {
            claimsSection = "Needs verification";
            showAdminClaims();
        }));
        panel.getChildren().add(attentionAction(handover + " approved claims awaiting pickup", "Open handovers", handover, () -> {
            claimsSection = "Awaiting handover";
            showAdminClaims();
        }));
        panel.getChildren().add(attentionAction(overdue + " overdue found items", "Review overdue", overdue, () -> {
            adminReportsTab = "Unclaimed";
            showReports();
        }));
        if (pending + handover + overdue == 0) panel.getChildren().add(smallGrey("All caught up. New tasks will appear here."));
        return panel;
    }

    private Node attentionAction(String text, String actionText, long count, Runnable action) {
        Label label = wrapLabel(text);
        label.setMinWidth(0);
        label.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(label, Priority.ALWAYS);
        Button button = new Button(actionText);
        button.setStyle(smallBtn());
        button.setMinWidth(Region.USE_PREF_SIZE);
        button.setDisable(count == 0);
        button.setOnAction(e -> action.run());
        HBox row = new HBox(8, label, button);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    // banner on top: tells the admin what needs attention right now
    private Node adminWelcomeBanner(int pending, int approved, int overdue) {
        Label campus = new Label("Negros Oriental State University");
        campus.getStyleClass().add("campus-kicker");
        Label hi = new Label("Welcome back, " + firstWord(CurrentUser.getName()) + "!");
        hi.setWrapText(true);
        hi.getStyleClass().add("hero-heading");
        boolean allClear = pending == 0 && approved == 0 && overdue == 0;
        Label sub = new Label(allClear
                ? "Everything is up to date. New reports and claims will show up here."
                : "Here is what needs your attention today:");
        sub.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: 12px;");

        sub.setWrapText(true);
        VBox summary = new VBox(7, campus, hi, sub);

        summary.setPadding(new Insets(12, 22, 12, 22));
        summary.getStyleClass().add("hero-intro");
        summary.setAlignment(Pos.CENTER_LEFT);
        summary.setMinWidth(0);
        summary.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(summary, Priority.ALWAYS);
        CampusPhoto campusView = new CampusPhoto(PhotoChoice.NORSU);
        HBox banner = new HBox(summary, campusView);
        campusView.prefWidthProperty().bind(banner.widthProperty().multiply(.33));
        banner.setMinHeight(116);
        banner.setPrefHeight(116);
        banner.setMaxHeight(116);
        banner.getStyleClass().add("welcome-card");
        roundClip(banner, 14);
        return banner;
    }

    // one line in "Recent Reports": photo, name, kind, place, time and a status chip
    private HBox adminReportRow(Item it) {
        Label title = new Label(it.title);
        title.setMinWidth(0);
        title.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");

        Label kind = new Label(it.type);
        kind.setStyle("-fx-text-fill: " + kindColor(it) + "; -fx-font-weight: bold; -fx-font-size: 12px;");
        Label meta = new Label("•  " + it.location + "  •  " + ago(it.created));
        meta.setMinWidth(0);
        meta.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        HBox sub = new HBox(5, kind, meta);
        sub.setAlignment(Pos.CENTER_LEFT);

        VBox info = new VBox(3, title, sub);
        info.setMinWidth(0);
        HBox.setHgrow(info, Priority.ALWAYS);

        HBox row = new HBox(12, itemPicture(it, 40, 40), info, statusChip(it));
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(6, 10, 6, 10));
        row.setCursor(Cursor.HAND);
        row.setStyle(CARD);
        row.setOnMouseClicked(e -> showItemDetail(it));
        return row;
    }

    // matching report with the top matches and their percentage
    private Node buildMatchingCard(List<Pair> ps, int overdue, int soon) {
        VBox card = new VBox(8, sectionTitle("Matching Report"));
        if (ps.isEmpty()) {
            card.getChildren().add(emptyLine("No possible matches yet. KITA AI compares every new lost "
                    + "report with the found items."));
        } else {
            card.getChildren().add(wrapLabel(ps.size() + " possible match" + (ps.size() == 1 ? "" : "es")
                    + " between lost and found reports (suggestions only)."));
            for (int i = 0; i < Math.min(1, ps.size()); i++) card.getChildren().add(matchRow(ps.get(i)));
        }

        Label od = wrapLabel(overdue + " overdue item(s), " + soon + " reaching the " + unclaimedMonths
                + "-month limit within 30 days.");
        Button openAi = new Button("Open KITA AI");
        openAi.setStyle(smallBtn());
        openAi.setOnAction(e -> showAssistant());
        Button openUnc = new Button("Review unclaimed");
        openUnc.setStyle(smallBtn());
        openUnc.setOnAction(e -> {
            adminReportsTab = "Unclaimed";
            showReports();
        });
        card.getChildren().addAll(od, new FlowPane(8, 6, openAi, openUnc));
        card.setPadding(new Insets(10, 12, 10, 12));
        card.setStyle(CARD);
        return card;
    }

    private HBox matchRow(Pair p) {
        Label l = new Label("Lost: " + p.lost.title + "  ↔  Found: " + p.found.title);
        l.setWrapText(true);
        l.setMinWidth(0);
        l.setStyle("-fx-text-fill: " + DARK + "; -fx-font-size: 12.5px;");
        HBox.setHgrow(l, Priority.ALWAYS);

        String bg = p.pct >= 70 ? "#dcfce7" : (p.pct >= 50 ? "#f3e8ff" : "#fef3c7");
        String fg = p.pct >= 70 ? "#15803d" : (p.pct >= 50 ? "#581c87" : "#b45309");
        Label pct = pillLabel(p.pct + "%", bg, fg);
        pct.setMinWidth(Region.USE_PREF_SIZE);

        Button view = new Button("View");
        view.setStyle(smallBtn());
        view.setMinWidth(Region.USE_PREF_SIZE);
        view.setOnAction(e -> showItemDetail(p.found));

        HBox row = new HBox(8, l, pct, view);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(6, 8, 6, 8));
        row.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 10;");
        return row;
    }

    // ---------- campus hotspots (shows a faded sample chart while there is no data) ----------
    private HBox hotspotRow(String name, int count, int max, boolean top, boolean ghost) {
        Label nm = new Label(name);
        nm.setPrefWidth(110);
        nm.setMinWidth(110);
        nm.setStyle("-fx-text-fill: " + DARK + "; -fx-font-size: 12px;");
        Rectangle bar = new Rectangle(12, 12);
        bar.setArcWidth(8);
        bar.setArcHeight(8);
        bar.setFill(Color.web(top ? Theme.BLUE : Theme.mix(Theme.BLUE, "#ffffff", 0.45)));
        Label n = new Label(String.valueOf(count));
        n.setStyle("-fx-font-weight: bold; -fx-font-size: 12px; -fx-text-fill: " + DARK + ";");
        HBox row = new HBox(8, nm, bar, n);
        bar.widthProperty().bind(Bindings.createDoubleBinding(
                () -> Math.max(8, Math.min(170, row.getWidth() - 150)) * count / max, row.widthProperty()));
        row.setAlignment(Pos.CENTER_LEFT);
        if (ghost) row.setOpacity(0.85);
        return row;
    }

    private Node buildHotspotCard() {
        Map<String, Integer> counts = new LinkedHashMap<>();
        Map<String, String> names = new HashMap<>();
        for (Item it : items) {
            String loc = it.location == null ? "" : it.location.trim();
            if (loc.isEmpty()) continue;
            String key = loc.toLowerCase();
            counts.merge(key, 1, Integer::sum);
            names.putIfAbsent(key, loc);
        }
        List<Map.Entry<String, Integer>> top = new ArrayList<>(counts.entrySet());
        top.sort((x, y) -> y.getValue() - x.getValue());

        VBox box = new VBox(6, sectionTitle("Campus hotspots"));
        if (top.isEmpty()) {
            Label hint = new Label("No location data yet. Reported locations will appear here.");
            hint.setWrapText(true);
            hint.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 11.5px; -fx-font-style: italic;");
            box.getChildren().add(hint);
        } else {
            int max = top.get(0).getValue();
            for (int i = 0; i < Math.min(4, top.size()); i++) {
                Map.Entry<String, Integer> en = top.get(i);
                box.getChildren().add(hotspotRow(names.get(en.getKey()), en.getValue(), max, i == 0, false));
            }
        }
        box.setPadding(new Insets(10, 12, 10, 12));
        box.setStyle(CARD);
        return box;
    }

    // =====================================================
    // MANAGE USERS (upgraded)
    // =====================================================
    private String userSearchText = "";
    private String userRoleFilter = "All";
    private ScrollPane usersRowsScroll;

    private void showUsers() {
        adminRefresh = this::showUsers;
        Label sub = new Label("Search, review and manage enrolled student and staff accounts. "
                + "Main administrators can invite or remove assistant administrators.");
        sub.setWrapText(true);
        sub.setStyle("-fx-text-fill: #5b7297; -fx-font-size: 12px;");
        Node userContent = buildUsersTab();
        ScrollPane page = pageOf(campusFeatureBanner("Manage Users", "Review student and staff accounts"),
                sub, userContent);
        if (usersRowsScroll != null) {
            ScrollPane accountScroller = usersRowsScroll;
            Runnable fit = () -> accountScroller.setPrefHeight(Math.max(150,
                    Math.min(450, page.getViewportBounds().getHeight() - 310)));
            page.viewportBoundsProperty().addListener((o, old, value) -> fit.run());
            fit.run();
        }
        openScreen(page, usersNav, false, false);
    }

    private Node campusFeatureBanner(String title, String subtitle) {
        StackPane banner = new StackPane();
        banner.setMinHeight(105); banner.setPrefHeight(118); banner.setMaxHeight(128);
        banner.setMinWidth(0);
        banner.setStyle("-fx-background-color: #082d74; -fx-background-radius: 16;");
        roundClip(banner, 16);
        Image image = new Image(main.class.getResource("norsu-courtyard-photo.png").toExternalForm());
        ImageView photo = new ImageView(image);
        photo.setPreserveRatio(false);
        photo.fitWidthProperty().bind(banner.widthProperty());
        photo.fitHeightProperty().bind(banner.heightProperty());
        Runnable crop = () -> {
            double w = banner.getWidth(), h = banner.getHeight();
            if (w <= 0 || h <= 0) return;
            double cropW = image.getWidth(), cropH = image.getHeight();
            if (cropW / cropH > w / h) cropW = cropH * w / h;
            else cropH = cropW * h / w;
            photo.setViewport(new Rectangle2D((image.getWidth()-cropW)/2,
                    Math.max(0, (image.getHeight()-cropH)*0.45), cropW, cropH));
        };
        banner.widthProperty().addListener((o,a,b)->crop.run());
        banner.heightProperty().addListener((o,a,b)->crop.run());
        Pane tint = new Pane();
        tint.setStyle("-fx-background-color: linear-gradient(to right, rgba(5,29,82,0.98), "
                + "rgba(8,46,111,0.88) 38%, rgba(5,32,76,0.06) 92%);");
        tint.setMouseTransparent(true);
        Label head = new Label(title);
        head.setStyle("-fx-font-size: 29px; -fx-font-weight: bold; -fx-text-fill: white;");
        Label desc = new Label(subtitle);
        desc.setStyle("-fx-font-size: 13px; -fx-text-fill: #eaf2ff;");
        VBox text = new VBox(4, head, desc);
        text.setPadding(new Insets(14, 24, 14, 24));
        text.setAlignment(Pos.CENTER_LEFT);
        StackPane.setAlignment(text, Pos.CENTER_LEFT);
        banner.getChildren().addAll(photo, tint, text);
        return banner;
    }

    private boolean matchesUserFilter(UserService.Account acc) {
        switch (userRoleFilter) {
            case "Students": return acc.role.equals("Student");
            case "Admins": return acc.role.equals("Admin");
            case "Ready to delete": return acc.canBeDeleted();
            default: return true;
        }
    }

    private Node buildUsersTab() {
        List<UserService.Account> accs = UserService.accounts();

        int students = 0;
        int admins = 0;
        int deletable = 0;
        Set<String> accountNames = new HashSet<>();
        for (UserService.Account x : accs) {
            accountNames.add(x.name.toLowerCase());
            if (x.role.equals("Admin")) {
                admins++;
            } else {
                students++;
                if (x.canBeDeleted()) deletable++;
            }
        }
        List<String> guests = new ArrayList<>();
        for (String g : users.values()) {
            if (!accountNames.contains(g.toLowerCase())) guests.add(g);
        }

        Node stats = dashboardGrid(800, new double[]{25,25,25,25},
                premiumStat("Total Users", userCount(), ICON_USERS, "#1559c8"),
                premiumStat("Student Accounts", students, ICON_PERSON, "#1559c8"),
                premiumStat("Admin Accounts", admins, ICON_CHECK, "#efb400"),
                premiumStat("Ready to Delete", deletable, ICON_HISTORY, "#d7354c"));

        // search + filter chips
        TextField find = new TextField(userSearchText);
        find.setPromptText("Search name, ID or email...");
        find.setStyle("-fx-background-color: transparent; -fx-padding: 9 4 9 4;");
        HBox.setHgrow(find, Priority.ALWAYS);
        HBox findBox = new HBox(8, new Group(svg(ICON_SEARCH, 20, "#98a2b3")), find);
        findBox.setAlignment(Pos.CENTER_LEFT);
        findBox.setPadding(new Insets(0, 14, 0, 14));
        findBox.setPrefWidth(300);
        findBox.setMinWidth(190);
        findBox.getStyleClass().add("browse-search");
        findBox.setMaxWidth(320);
        findBox.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 12; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 6, 0, 0, 1);");

        FlowPane chips = new FlowPane(8, 8);
        chips.setAlignment(Pos.CENTER_LEFT);
        for (String t : new String[]{"All", "Students", "Admins", "Ready to delete"}) {
            Button b = new Button(t);
            styleChip(b, t.equals(userRoleFilter));
            b.setOnAction(e -> {
                userRoleFilter = t;
                showUsers();
            });
            chips.getChildren().add(b);
        }
        HBox.setHgrow(chips, Priority.ALWAYS);
        Region searchSpace = new Region();
        HBox.setHgrow(searchSpace, Priority.ALWAYS);
        HBox toolbar = new HBox(10, findBox, searchSpace);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        if (amMainAdmin()) {
            Button addAssistant = new Button("+ Add Assistant Admin");
            addAssistant.setStyle("-fx-background-color: #1559c8; -fx-text-fill: white; "
                    + "-fx-font-weight: bold; -fx-background-radius: 11; -fx-padding: 11 17;");
            addAssistant.setOnAction(e -> openAddAssistantDialog());
            toolbar.getChildren().add(addAssistant);
        }
        chips.setPrefWrapLength(620);
        chips.setMinWidth(0);

        // table
        HBox header = new HBox(10,
                col(new Region(), 34),
                headerCell("USER", -1),
                headerCell("ROLE", 80),
                headerCell("STATUS", 128),
                headerCell("ACTIVITY", 100),
                headerCell("ACTION", 165));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(0, 12, 0, 12));

        VBox rows = new VBox(7);
        final boolean[] compactAccounts = {false};
        Label count = new Label();
        count.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");

        Runnable fill = () -> {
            rows.getChildren().clear();
            String query = userSearchText.trim().toLowerCase();
            int shownCount = 0;
            for (UserService.Account x : accs) {
                if (!matchesUserFilter(x)) continue;
                String hay = (x.name + " " + x.studentId + " " + x.email).toLowerCase();
                if (!query.isEmpty() && !hay.contains(query)) continue;
                rows.getChildren().add(compactAccounts[0] ? userCompactRowFor(x) : userRowFor(x));
                shownCount++;
            }
            if (userRoleFilter.equals("All") || userRoleFilter.equals("Students")) {
                for (String g : guests) {
                    if (!query.isEmpty() && !g.toLowerCase().contains(query)) continue;
                    rows.getChildren().add(compactAccounts[0] ? compactGuestRow(g) : userRow(g, "Student", "Guest (no account)",
                            pillLabel("Guest", "#e2e8f0", "#475569"), null, false));
                    shownCount++;
                }
            }
            if (shownCount == 0) {
                rows.getChildren().add(emptyState(ICON_USERS, "#7c3aed", "No users found",
                        "Try a different search or filter.", null, null));
            }
            count.setText(shownCount + " user" + (shownCount == 1 ? "" : "s"));
        };
        find.textProperty().addListener((obs, oldV, newV) -> {
            userSearchText = newV == null ? "" : newV;
            fill.run();
        });
        fill.run();

        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox titleRow = new HBox(sectionTitle("Accounts"), gap, count);
        titleRow.setAlignment(Pos.CENTER_LEFT);

        ScrollPane accountRows = new ScrollPane(rows);
        accountRows.setFitToWidth(true);
        accountRows.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        accountRows.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        accountRows.setMinHeight(75);
        accountRows.setPrefHeight(168);
        accountRows.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        usersRowsScroll = accountRows;
        header.visibleProperty().bind(accountRows.widthProperty().greaterThan(810));
        header.managedProperty().bind(header.visibleProperty());
        accountRows.viewportBoundsProperty().addListener((o,old,bounds) -> {
            boolean narrow = bounds.getWidth() > 0 && bounds.getWidth() < 810;
            if (narrow != compactAccounts[0]) {
                compactAccounts[0] = narrow;
                fill.run();
            }
        });
        VBox card = new VBox(10, titleRow, header, accountRows);
        VBox.setVgrow(accountRows, Priority.ALWAYS);
        card.setMinHeight(0);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-background-color: white; -fx-background-radius: 15; "
                + "-fx-border-color: #c8d9f5; -fx-border-radius: 15;");
        VBox screen = new VBox(11, stats, toolbar, chips, card);
        screen.setMinWidth(0);
        return screen;
    }

    // column title; width -1 = takes the free space
    private Node headerCell(String text, double width) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: 10.5px; -fx-font-weight: bold;");
        if (width < 0) {
            l.setMinWidth(0);
            HBox box = new HBox(l);
            HBox.setHgrow(box, Priority.ALWAYS);
            return box;
        }
        return col(new HBox(l), width);
    }

    // status of a student for the 3-year rule
private Node userStatus(UserService.Account acc) {
    VBox box = new VBox(3);
    if (acc.role.equals("Admin")) {
        box.getChildren().addAll(pillLabel("Active", "#dcfce7", "#15803d"),
                smallGrey(acc.assistant ? "Assistant admin" : "Main admin"));
        return box;
    }
    boolean ready = acc.canBeDeleted();
    box.getChildren().add(pillLabel(ready ? "Ready to delete" : "Enrolled",
            ready ? "#fee2e2" : "#dcfce7", ready ? "#b91c1c" : "#15803d"));
    String course = acc.program == null || acc.program.isBlank() ? "Student" : acc.program;
    if (acc.yearLevel > 0) course += " · Year " + acc.yearLevel;
    box.getChildren().add(smallGrey(course));
    return box;
}

        private Label smallGrey(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 11px;");
        return l;
    }

    private HBox userRowFor(UserService.Account acc) {
        Button act = null;
        if (acc.role.equals("Student")) {
            act = new Button("Delete");
            act.setStyle("-fx-background-color: -cf-error-bg; -fx-text-fill: -cf-danger; -fx-font-weight: bold; "
                    + "-fx-font-size: 12px; -fx-background-radius: 8; -fx-padding: 4 12 4 12; -fx-cursor: hand;");
            act.setDisable(!acc.canBeDeleted());
            act.setOnAction(e -> confirmDeleteAccount(acc));
        } else if (acc.assistant && amMainAdmin()) {
            act = new Button("Remove");
            act.setStyle("-fx-background-color: -cf-error-bg; -fx-text-fill: -cf-danger; -fx-font-weight: bold; "
                    + "-fx-font-size: 12px; -fx-background-radius: 8; -fx-padding: 4 12 4 12; -fx-cursor: hand;");
            act.setOnAction(e -> confirmRemoveAssistant(acc));
        }
        if (acc.role.equals("Student")) {
            Button view = new Button("View Profile");
            view.setStyle(smallBtn());
            view.setOnAction(e -> showAdminStudentProfile(acc));
            HBox actions = new HBox(5, view);
            if (act != null) actions.getChildren().add(act);
            act = null;
            HBox row = userRow(acc.name, acc.assistant ? "Assistant" : acc.role,
                    acc.studentId + "  |  " + acc.email, userStatus(acc), actions, acc.canBeDeleted());
            row.getChildren().set(0, userAvatar(acc, 34));
            return row;
        }
        return userRow(acc.name, acc.assistant ? "Assistant" : acc.role,
                acc.studentId + "  |  " + acc.email, userStatus(acc), act, acc.canBeDeleted());
    }

    /** Card layout used instead of clipping fixed table columns on laptop widths. */
    private VBox userCompactRowFor(UserService.Account acc) {
        Label title = new Label(acc.name);
        title.setWrapText(true);
        title.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #0b3379;");
        Label contact = new Label(acc.studentId + "  ·  " + acc.email);
        contact.setWrapText(true);
        contact.setStyle("-fx-text-fill: #5a7091; -fx-font-size: 12px;");
        VBox identity = new VBox(3, title, contact);
        identity.setMinWidth(0);
        HBox.setHgrow(identity, Priority.ALWAYS);
        Label roleChip = pillLabel(acc.assistant ? "Assistant Admin" : acc.role,
                acc.role.equals("Admin") ? "#eee6ff" : "#e5efff",
                acc.role.equals("Admin") ? "#632c9a" : "#1559c8");
        HBox header = new HBox(10, userAvatar(acc, 36), identity, roleChip);
        header.setAlignment(Pos.CENTER_LEFT);
        int reports = 0, claimCount = 0;
        for (Item item : items) if (item.reporter.equalsIgnoreCase(acc.name)) reports++;
        for (Claim claim : claims) if (claim.claimant.equalsIgnoreCase(acc.name)) claimCount++;
        Label count = smallGrey(reports + " reports  ·  " + claimCount + " claims");
        HBox footer = new HBox(10, userStatus(acc), count);
        footer.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(count, Priority.ALWAYS);
        if (acc.role.equals("Student")) {
            Button view = new Button("View Profile");
            view.setStyle(smallBtn());
            view.setOnAction(e -> showAdminStudentProfile(acc));
            footer.getChildren().add(view);
            Button remove = new Button("Delete");
            remove.setDisable(!acc.canBeDeleted());
            remove.setStyle("-fx-background-color: #fce8ec; -fx-text-fill: #ab2336; "
                    + "-fx-background-radius: 9; -fx-font-weight: bold; -fx-padding: 6 11;");
            remove.setOnAction(e -> confirmDeleteAccount(acc));
            footer.getChildren().add(remove);
        } else if (acc.assistant && amMainAdmin()) {
            Button remove = new Button("Remove");
            remove.setStyle("-fx-background-color: #fce8ec; -fx-text-fill: #ab2336; "
                    + "-fx-background-radius: 9; -fx-font-weight: bold; -fx-padding: 6 11;");
            remove.setOnAction(e -> confirmRemoveAssistant(acc));
            footer.getChildren().add(remove);
        }
        VBox card = new VBox(9, header, footer);
        card.setPadding(new Insets(13));
        card.getStyleClass().add("cf-v2-user-card");
        return card;
    }

    private VBox compactGuestRow(String name) {
        Label guest = new Label(name);
        guest.setStyle("-fx-text-fill: #0c3477; -fx-font-weight: bold;");
        VBox card = new VBox(6, new HBox(9, smallAvatar(name, 32), guest),
                smallGrey("Guest (no registered account)"));
        card.setPadding(new Insets(12));
        card.getStyleClass().add("cf-v2-user-card");
        return card;
    }

    // only the main admin can add or remove assistant admins
    private boolean amMainAdmin() {
        return admin && UserService.isMainAdmin(CurrentUser.getStudentId());
    }

    private void confirmRemoveAssistant(UserService.Account a) {
        VBox body = new VBox(8, wrapLabel("Remove the assistant admin " + a.name + "? They will not be able "
                + "to log in as an admin anymore."));
        confirmBox("Remove assistant admin", body, "Remove", () -> {
            UserService.accounts().remove(a);
        UserService.saveAccounts();
            audit(CurrentUser.getName(), "User account removed (assistant admin)", a.name);
            refreshAdmin();
        });
    }

    private void openAddAssistantDialog() {
        Stage dialog = new Stage();
        dialog.initOwner(root.getScene().getWindow());
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.initStyle(StageStyle.TRANSPARENT);

        String[] created = new String[2];   // id + password of the new assistant

        Label heading = new Label("Add Assistant Admin");
        heading.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #ffffff;");
        HBox modalHeader = new HBox(10, new Group(svg(ICON_USERS, 23, "#ffca23")), heading);
        modalHeader.setAlignment(Pos.CENTER_LEFT);
        modalHeader.setPadding(new Insets(16, 18, 16, 18));
        modalHeader.setStyle("-fx-background-color: linear-gradient(to right, #082b73, #1559c8); "
                + "-fx-background-radius: 17 17 0 0; -fx-border-color: transparent transparent #ffca23 transparent; "
                + "-fx-border-width: 0 0 3 0;");
        Label info = wrapLabel("Assistant admins can manage reports, claims and users. Only you (the main admin) "
                + "can add or remove them.");
        info.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");

        Label err = new Label();
        err.setWrapText(true);
        err.setStyle("-fx-text-fill: -cf-danger; -fx-font-size: 12px;");

        // how many assistant admins you allow
        Label countLabel = new Label();
        countLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: " + Theme.BLUE + ";");
        Runnable paintCount = () -> countLabel.setText("Added: " + UserService.assistantCount() + " of "
                + UserService.getMaxAssistants());
        ComboBox<Integer> limit = new ComboBox<>();
        for (int i = 1; i <= 10; i++) limit.getItems().add(i);
        limit.setValue(UserService.getMaxAssistants());
        limit.setOnAction(e -> {
            Integer v = limit.getValue();
            if (v == null) return;
            if (v < UserService.assistantCount()) {
                err.setText("You already added " + UserService.assistantCount() + " assistant admin(s).");
                limit.setValue(UserService.getMaxAssistants());
                return;
            }
            err.setText("");
            UserService.setMaxAssistants(v);
            paintCount.run();
        });
        paintCount.run();
        Label limitLabel = new Label("Assistant administrator limit");
        limitLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 13px; -fx-text-fill: #0e316e;");
        Region lg = new Region();
        HBox.setHgrow(lg, Priority.ALWAYS);
        HBox limitControls = new HBox(12, limit, lg, countLabel);
        limitControls.setAlignment(Pos.CENTER_LEFT);
        VBox limitRow = new VBox(7, limitLabel, limitControls);
        limitRow.setPadding(new Insets(10));
        limitRow.setStyle("-fx-background-color: #f0f5ff; -fx-background-radius: 12;");

        TextField name = new TextField();
        name.setPromptText("Full name");
        name.setStyle("-fx-padding: 8;");
        TextField id = new TextField();
        id.setPromptText("Admin ID (used to log in)");
        id.setStyle("-fx-padding: 8;");
        TextField mail = new TextField();
        mail.setPromptText("Email address");
        mail.setStyle("-fx-padding: 8;");
        javafx.scene.control.PasswordField pass = new javafx.scene.control.PasswordField();
        pass.setPromptText("Temporary password (at least 6 characters)");
        pass.setStyle("-fx-padding: 10;");
        TextField passShown = new TextField();
        passShown.setPromptText("Temporary password (at least 6 characters)");
        passShown.textProperty().bindBidirectional(pass.textProperty());
        passShown.setVisible(false);
        passShown.managedProperty().bind(passShown.visibleProperty());
        pass.managedProperty().bind(pass.visibleProperty());
        javafx.scene.control.CheckBox reveal = new javafx.scene.control.CheckBox("Show password");
        reveal.setStyle("-fx-text-fill: #385c90;");
        reveal.selectedProperty().addListener((o,a,shown) -> {
            pass.setVisible(!shown);
            passShown.setVisible(shown);
        });

        Button cancel = new Button("Cancel");
        cancel.setCancelButton(true);
        cancel.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: " + DARK + "; -fx-font-weight: bold; "
                + "-fx-background-radius: 6; -fx-padding: 8 20 8 20; -fx-cursor: hand;");
        cancel.setOnAction(e -> dialog.close());

        Button add = new Button("Add assistant admin");
        add.setDefaultButton(true);
        add.setStyle("-fx-background-color: " + Theme.BLUE + "; -fx-text-fill: -cf-on-accent; -fx-font-weight: bold; "
                + "-fx-background-radius: 6; -fx-padding: 8 20 8 20; -fx-cursor: hand;");
        add.setOnAction(e -> {
            String msg = UserService.addAssistant(name.getText().trim(), id.getText().trim(),
                    mail.getText().trim(), pass.getText());
            if (msg != null) {
                err.setText(msg);
                return;
            }
            audit(CurrentUser.getName(), "User account added (assistant admin)", name.getText().trim());
            created[0] = id.getText().trim();
            created[1] = pass.getText();
            dialog.close();
        });
        HBox buttons = new HBox(10, cancel, add);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        VBox passwordFields = new VBox(0, pass, passShown);
        VBox fields = new VBox(11, info, limitRow,
                new VBox(4, fieldLabel("Full name"), name),
                new VBox(4, fieldLabel("Admin ID"), id),
                new VBox(4, fieldLabel("Email address"), mail),
                new VBox(4, fieldLabel("Temporary password"), passwordFields, reveal),
                err, buttons);
        fields.setPadding(new Insets(19, 21, 20, 21));
        VBox box = new VBox(0, modalHeader, fields);
        box.setPrefWidth(510);
        box.setMaxWidth(Double.MAX_VALUE);
        box.setStyle("-fx-background-color: white; -fx-background-radius: 17; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.38), 26, 0, 0, 8);");
        ScrollPane modalScroll = new ScrollPane(box);
        modalScroll.setFitToWidth(true);
        modalScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        modalScroll.setMaxWidth(560);
        modalScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        modalScroll.setStyle("-fx-background-color: transparent; -fx-background: transparent;");
        StackPane wrapper = new StackPane(modalScroll);
        wrapper.setPadding(new Insets(12));
        wrapper.setStyle("-fx-background-color: transparent;");
        CampusStyle.install(wrapper);
        Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        double modalWidth = Math.min(560, bounds.getWidth() - 32);
        double modalHeight = Math.min(625, bounds.getHeight() - 40);
        Scene scene = new Scene(wrapper, modalWidth, modalHeight);
        scene.setFill(Color.TRANSPARENT);
        dialog.setScene(scene);
        dialog.setWidth(modalWidth);
        dialog.setHeight(modalHeight);
        dialog.centerOnScreen();
        dialog.showAndWait();

        if (created[0] != null) {
            refreshAdmin();
            popup("Assistant admin added", wrapLabel("Give these login details to your assistant:\n"
                    + "ID: " + created[0] + "\nTemporary password: " + created[1]));
        }
    }

    private HBox userRow(String name, String role, String detail, Node status, Node action,
                         boolean highlight) {
        int reports = 0;
        int myClaims = 0;
        for (Item it : items) {
            if (it.reporter.equalsIgnoreCase(name)) reports++;
        }
        for (Claim c : claims) {
            if (c.claimant.equalsIgnoreCase(name)) myClaims++;
        }

        Label n = new Label(name);
        n.setMinWidth(0);
        n.setStyle("-fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label d = new Label(detail);
        d.setMinWidth(0);
        d.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        VBox info = new VBox(2, n, d);
        info.setMinWidth(0);
        HBox.setHgrow(info, Priority.ALWAYS);

        boolean isAdmin = role.equals("Admin") || role.equals("Assistant");
        Label chip = pillLabel(role, isAdmin ? "#ede9fe" : Theme.TINT, isAdmin ? "#6d28d9" : Theme.BLUE);
        HBox roleBox = col(new HBox(chip), 80);
        roleBox.setAlignment(Pos.CENTER_LEFT);

        HBox statusBox = col(new HBox(status), 128);
        statusBox.setAlignment(Pos.CENTER_LEFT);

        VBox counts = col(new VBox(1,
                smallGrey(reports + " report" + (reports == 1 ? "" : "s")),
                smallGrey(myClaims + " claim" + (myClaims == 1 ? "" : "s"))), 100);

        HBox actionBox = col(new HBox(), 165);
        actionBox.setAlignment(Pos.CENTER_LEFT);
        if (action != null) actionBox.getChildren().add(action);

        HBox row = new HBox(10, smallAvatar(name, 34), info, roleBox, statusBox, counts, actionBox);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(8, 12, 8, 12));
        row.setStyle("-fx-background-color: " + (highlight ? "-cf-error-bg" : Theme.panel) + "; "
                + "-fx-background-radius: 12; -fx-border-color: " + (highlight ? "#fecaca" : "#e8edf3")
                + "; -fx-border-radius: 12;");
        return row;
    }


    // =====================================================
    // STUDENT DASHBOARD
    // =====================================================
// Student panels use screen-specific icons instead of the generic grid icon.
private VBox studentDashboardPanel(String title, String icon) {
    VBox panel = premiumDashboardPanel(title);
    HBox header = (HBox) panel.getChildren().get(0);
    header.getChildren().set(0, new Group(svg(icon, 18, "#ffca23")));
    return panel;
}

// A small header shortcut keeps View All out of the main content area.
private void studentPanelHeaderAction(VBox panel, String label, Runnable onClick) {
    HBox header = (HBox) panel.getChildren().get(0);
    Region spacer = new Region();
    HBox.setHgrow(spacer, Priority.ALWAYS);
    Button view = new Button(label);
    view.setStyle("-fx-background-color: #ffffff; -fx-text-fill: #0b397e; "
            + "-fx-font-size: 11px; -fx-font-weight: bold; -fx-padding: 4 11; "
            + "-fx-background-radius: 13; -fx-cursor: hand;");
    view.setOnAction(e -> onClick.run());
    header.getChildren().addAll(spacer, view);
}

private Node buildStudentDashboard() {
    String me = CurrentUser.getName();
    int myReports = 0, active = 0, resolved = 0;
    for (Item it : items) {
        if (it.reporter.equalsIgnoreCase(me)) myReports++;
        if (it.reporter.equalsIgnoreCase(me) && it.claimed) resolved++;
    }
    for (Claim c : claims) {
        if (!c.accountId.equalsIgnoreCase(CurrentUser.getStudentId()) || !items.contains(c.item)) continue;
        if (c.status.equals("Pending") || c.status.equals("Approved")) active++;
        if (c.status.equals("Released")) resolved++;
    }
    Node stats = dashboardGrid(790, new double[]{25, 25, 25, 25},
            premiumStat("My Reports", myReports, ICON_LIST, "#1559c8"),
            premiumStat("Active Claims", active, ICON_CLAIM, "#d99600"),
            premiumStat("Resolved Items", resolved, ICON_CHECK, "#15803d"),
            premiumStat("Messages", unreadCount(me), ICON_CHAT, "#7545ca"));

    VBox findPanel = studentDashboardPanel("Search Found Items", ICON_SEARCH);
    findPanel.setId("cf-student-search");
    TextField query = new TextField();
    query.setPromptText("Search campus items (wallet, ID, phone, backpack...)");
    query.setStyle("-fx-background-color: #f9fcff; -fx-border-color: #c6dafa; "
            + "-fx-background-radius: 12; -fx-border-radius: 12; -fx-padding: 10 12;");
    HBox.setHgrow(query, Priority.ALWAYS);
    Button searchButton = new Button("Search");
    searchButton.setStyle("-fx-background-color: #1151ba; -fx-text-fill: white; "
            + "-fx-font-weight: bold; -fx-background-radius: 12; -fx-padding: 10 17;");
    Runnable doSearch = () -> {
        selectBrowseSection(BrowseSection.UNCLAIMED);
        clearFilters();
        search.setText(query.getText().trim());
        showBrowse();
    };
    query.setOnAction(e -> doSearch.run());
    searchButton.setOnAction(e -> doSearch.run());
    HBox searchBar = new HBox(9, query, searchButton);
    searchBar.setAlignment(Pos.CENTER_LEFT);
    searchBar.setMinHeight(44);
    searchBar.setMaxHeight(44);
    query.setMinHeight(44); query.setPrefHeight(44); query.setMaxHeight(44);
    searchButton.setMinHeight(44); searchButton.setPrefHeight(44); searchButton.setMaxHeight(44);
    findPanel.getChildren().add(searchBar);
    findPanel.getChildren().add(compactEmptyHint("Search by name, category, location, or description."));

    VBox actions = studentDashboardPanel("Quick Actions", ICON_SPARK);
    actions.setId("cf-student-actions");
    // A single row of four uniform tiles. A FlowPane used to give these
    // graphic-only buttons unpredictable row/column heights at desktop sizes.
    // Let them share the width equally; the dashboard page owns vertical scroll.
    HBox quick = new HBox(9,
            dashboardQuickTile("Report Lost Item", ICON_ADD, "#fff0b9", () -> showReport("Lost")),
            dashboardQuickTile("Browse Found Items", ICON_SEARCH, "#dcecff", this::showBrowse),
            dashboardQuickTile("My Claims", ICON_CLAIM, "#eee3ff", this::showClaims),
            dashboardQuickTile("Messages", ICON_CHAT, "#def7e9", this::showMessages));
    quick.setId("cf-student-quick-row");
    quick.setMinHeight(0);
    quick.setMaxWidth(Double.MAX_VALUE);
    quick.setAlignment(Pos.CENTER);
    for (Node tile : quick.getChildren()) HBox.setHgrow(tile, Priority.ALWAYS);
    actions.getChildren().add(quick);
    VBox recent = studentDashboardPanel("Recent Reports", ICON_LIST);
    recent.setId("cf-student-recent");
    studentPanelHeaderAction(recent, "View All", this::showBrowse);
    int added = 0;
    for (int i = items.size() - 1; i >= 0 && added < 3; i--) {
        Item item = items.get(i);
        recent.getChildren().add(studentPreview(item));
        added++;
    }
    if (added == 0) recent.getChildren().add(dashboardEmptyAction(
            "No reports yet", "Your campus community's reports will appear here.",
            "Browse Items", this::showBrowse));

    VBox claim = studentDashboardPanel("My Claim Tracking", ICON_CLAIM);
    claim.setId("cf-student-claims");
    studentPanelHeaderAction(claim, "View Claims", this::showClaims);
    claim.getChildren().add(buildDashboardClaim());

    VBox ai = studentDashboardPanel("KITA AI Assistant", ICON_SPARK);
    ai.setId("cf-student-kita");
    Label summary = new Label("Find possible matches, check a claim, and ask about campus items.");
    summary.setWrapText(true);
    summary.setStyle("-fx-text-fill: #365584; -fx-font-size: 12px;");
    HBox aiIntro = new HBox(8, aiIcon(68), summary);
    aiIntro.setAlignment(Pos.CENTER_LEFT);
    HBox.setHgrow(summary, Priority.ALWAYS);
    ai.getChildren().addAll(aiIntro,
            dashboardAccentAction("Ask KITA AI", ICON_CHAT, this::showAssistant));
    FlowPane aiActions = new FlowPane(7, 7,
            studentShortcut("Find my item", ICON_SEARCH, () -> { showAssistant(); sendChat("Find my item"); }),
            studentShortcut("Check claim status", ICON_CLAIM, this::showClaims),
            studentShortcut("Browse reports", ICON_LIST, this::showBrowse));
    ai.getChildren().add(aiActions);

    // No panel in the Student dashboard is stretched vertically to match an
    // oversized neighbor. Both tool cards are compact and the bottom row uses
    // each panel's actual content height; only the page scrolls when required.
    findPanel.setMinHeight(146);
    actions.setMinHeight(146);
    findPanel.setMaxHeight(Region.USE_PREF_SIZE);
    actions.setMaxHeight(Region.USE_PREF_SIZE);
    // A balanced bottom row also works when the user has no reports or claims.
    recent.setMinHeight(238);
    claim.setMinHeight(238);
    ai.setMinHeight(238);
    recent.setMaxHeight(Region.USE_PREF_SIZE);
    claim.setMaxHeight(Region.USE_PREF_SIZE);
    ai.setMaxHeight(Region.USE_PREF_SIZE);
    Node compactTools = studentDashboardGrid(760, new double[]{44, 56}, findPanel, actions);
    Node details = studentDashboardGrid(970, new double[]{34, 35, 31}, recent, claim, ai);
    ScrollPane dashboard = scrollingDashboard(campusBanner(false), stats, compactTools, details);
    VBox body = (VBox) ((StackPane) dashboard.getContent()).getChildren().getFirst();
    body.setSpacing(11);
    body.setPadding(new Insets(10, 16, 20, 16));
    dashboard.setId("student-dashboard");
    return dashboard;
}

private Button dashboardQuickTile(String title, String icon, String tint, Runnable action) {
    Label text = new Label(title);
    text.setWrapText(true);
    text.setAlignment(Pos.CENTER);
    text.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
    text.setMaxWidth(Double.MAX_VALUE);
    text.setStyle("-fx-text-fill: #0d3477; -fx-font-size: 12px; -fx-font-weight: bold;");
    StackPane iconHolder = new StackPane(new Group(svg(icon, 23, "#0848aa")));
    iconHolder.setMinSize(38, 38);
    iconHolder.setPrefSize(38, 38);
    iconHolder.setMaxSize(38, 38);
    iconHolder.setStyle("-fx-background-color: rgba(255,255,255,0.78); -fx-background-radius: 13;");
    VBox face = new VBox(7, iconHolder, text);
    face.setAlignment(Pos.CENTER);
    face.setFillWidth(true);
    face.setMaxWidth(Double.MAX_VALUE);
    face.setMinHeight(0);
    Button btn = new Button();
    btn.setGraphic(face);
    btn.setContentDisplay(javafx.scene.control.ContentDisplay.GRAPHIC_ONLY);
    btn.getStyleClass().add("cf-v2-quick-action");
    btn.setAccessibleText(title);
    btn.setMinWidth(0);
    btn.setPrefWidth(100);
    btn.setMaxWidth(Double.MAX_VALUE);
    btn.setMinHeight(96);
    btn.setPrefHeight(96);
    btn.setMaxHeight(96);
    btn.setAlignment(Pos.CENTER);
    btn.setStyle("-fx-background-color: " + tint + "; -fx-border-color: #c9daf7; "
            + "-fx-border-width: 1; -fx-border-radius: 14; -fx-background-radius: 14; "
            + "-fx-padding: 9 7; -fx-cursor: hand;");
    btn.setOnAction(e -> action.run());
    return btn;
}

        private Button homeReportAction(String title, String subtitle, String icon, String kind) {
        Label text = sectionTitle(title);
        Label detail = smallGrey(subtitle);
        HBox face = new HBox(14, new Group(svg(icon, 26, "#a76b00")), new VBox(3, text, detail));
        face.setAlignment(Pos.CENTER_LEFT);
        Button action = new Button();
        action.setGraphic(face);
        action.setAccessibleText(title);
        action.setId("home-report-" + kind.toLowerCase());
        action.setMaxWidth(Double.MAX_VALUE);
        action.setPrefWidth(0);
        action.getStyleClass().add("home-report-action");
        action.setOnAction(e -> showReport(kind));
        return action;
    }

    private static void roundClip(Region region, double radius) {
        Rectangle clip = new Rectangle();
        clip.widthProperty().bind(region.widthProperty());
        clip.heightProperty().bind(region.heightProperty());
        clip.setArcWidth(radius * 2);
        clip.setArcHeight(radius * 2);
        region.setClip(clip);
    }

private Node buildDashboardClaim() {
    Claim latest = null;
    for (Claim claim : claims) {
        if (!claim.accountId.equalsIgnoreCase(CurrentUser.getStudentId())
                || !items.contains(claim.item)) continue;
        if (latest == null || claim.time.isAfter(latest.time)) latest = claim;
    }
    VBox panel = new VBox(12);
    panel.setId("home-claim");
    panel.setPadding(new Insets(6));
    panel.setStyle("-fx-background-color: transparent;");
    if (latest == null) {
        panel.getChildren().add(dashboardEmptyAction("No claims submitted yet",
                "When you claim a found item, your review and pickup status will appear here.",
                "Find my item", this::showBrowse));
        return panel;
    }
    HBox item = new HBox(9, itemPicture(latest.item, 48,48));
    Label itemTitle = new Label(latest.item.title);
    itemTitle.setWrapText(true);
    itemTitle.setStyle("-fx-text-fill: #092e74; -fx-font-weight: bold; -fx-font-size: 13px;");
    Label ref = new Label("Claim for " + latest.item.category);
    ref.setStyle("-fx-text-fill: #5c759a; -fx-font-size: 11px;");
    VBox meta = new VBox(4,itemTitle,ref);
    meta.setMinWidth(0);
    HBox.setHgrow(meta,Priority.ALWAYS);
    item.getChildren().addAll(meta,claimChip(latest.status));
    item.setAlignment(Pos.CENTER_LEFT);

    boolean review = !latest.status.equals("Pending");
    boolean pickup = latest.status.equals("Approved") || latest.status.equals("Released");
    boolean released = latest.status.equals("Released");
    String[] titles = {"Submitted","Under Review","For Pickup","Claimed"};
    boolean[] finished = {true,review,pickup,released};
    HBox timeline = new HBox(4);
    timeline.setAlignment(Pos.CENTER);
    for (int i=0; i<4; i++) {
        boolean done = finished[i];
        Label symbol = new Label(done ? "✓" : Integer.toString(i+1));
        symbol.setStyle("-fx-text-fill: " + (done ? "white" : "#899db8")
                + "; -fx-font-size: 13px; -fx-font-weight: bold;");
        StackPane dot = new StackPane(symbol);
        dot.setPrefSize(30,30); dot.setMinSize(30,30); dot.setMaxSize(30,30);
        dot.setStyle("-fx-background-color: " + (done ? "#1559c8" : "#e5ecf6")
                + "; -fx-background-radius: 16; -fx-border-color: "
                + ((i==1 && !review) || (i==2 && review && !pickup) ? "#ffca23" : "#ccd8e9")
                + "; -fx-border-width: 2; -fx-border-radius: 16;");
        Label name = new Label(titles[i]);
        name.setWrapText(true); name.setAlignment(Pos.CENTER);
        name.setStyle("-fx-font-weight: bold; -fx-font-size: 10px; -fx-text-fill: #173d78;");
        VBox step = new VBox(6,dot,name);
        step.setAlignment(Pos.CENTER);
        HBox.setHgrow(step,Priority.ALWAYS);
        step.setMinWidth(0);
        timeline.getChildren().add(step);
    }
    Label next = new Label("Next Step: " + claimNextAction(latest));
    next.setWrapText(true);
    next.setStyle("-fx-background-color: #e8f2ff; -fx-text-fill: #164488; "
            + "-fx-font-size: 11px; -fx-font-weight: bold; -fx-background-radius: 10; -fx-padding: 10 12;");
    Button details = dashboardAccentAction("View claim details", ICON_CLAIM, this::showClaims);
    panel.getChildren().addAll(item,timeline,next,details);
    return panel;
}

        private Button studentShortcut(String text, String icon, Runnable action) {
        Button button = new Button(text, new Group(svg(icon, 16, Theme.BLUE)));
        button.setStyle(smallBtn());
        button.setOnAction(e -> action.run());
        return button;
    }

    private Button studentPreview(Item item) {
        Label title = new Label(item.title);
        title.setStyle("-fx-text-fill: -cf-ink; -fx-font-size: 13px; -fx-font-weight: bold;");
        title.setMinWidth(0);
        title.setMaxWidth(Double.MAX_VALUE);
        Label details = new Label(item.location + " · " + item.date);
        details.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: 12px;");
        details.setMinWidth(0);
        details.setMaxWidth(Double.MAX_VALUE);
        VBox text = new VBox(3, title, details);
        text.setMinWidth(0);
        HBox.setHgrow(text, Priority.ALWAYS);
        Label status = statusChip(item);
        status.setMinWidth(Region.USE_PREF_SIZE);
        HBox row = new HBox(10, itemPicture(item, 40, 40), text, status);
        row.setAlignment(Pos.CENTER_LEFT);
        Button button = new Button();
        button.setGraphic(row);
        button.setMaxWidth(Double.MAX_VALUE);
        button.setMinWidth(0);
        button.setPrefHeight(52);
        button.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 8; -fx-padding: 6 8; -fx-cursor: hand;");
        row.prefWidthProperty().bind(button.widthProperty().subtract(16));
        button.setAccessibleText("Open " + item.title + ", " + statusOf(item));
        button.setOnAction(e -> showItemDetail(item));
        return button;
    }

    private HBox stepRow(int n, String title, String text) {
        Label num = new Label(String.valueOf(n));
        num.setStyle("-fx-text-fill: -cf-on-accent; -fx-font-weight: bold; -fx-font-size: 12px;");
        StackPane dot = new StackPane(num);
        dot.setMinSize(26, 26);
        dot.setPrefSize(26, 26);
        dot.setMaxSize(26, 26);
        dot.setStyle("-fx-background-color: " + Theme.BLUE + "; -fx-background-radius: 13;");

        Label t = new Label(title);
        t.setStyle("-fx-font-weight: bold; -fx-font-size: 13px; -fx-text-fill: " + DARK + ";");
        Label d = new Label(text);
        d.setWrapText(true);
        d.setMinWidth(0);
        d.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        VBox texts = new VBox(1, t, d);
        HBox.setHgrow(texts, Priority.ALWAYS);

        HBox row = new HBox(10, dot, texts);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    private Node buildStudentMatchCard() {
        List<Pair> ps = collectPairs();
        VBox card = new VBox(8, sectionTitle("AI matches for you"));
        if (ps.isEmpty()) {
            card.getChildren().add(emptyLine("No matches yet. Describe your lost item in KITA AI and it will "
                    + "look for a found item."));
        } else {
            card.getChildren().add(wrapLabel(ps.size() + " possible match" + (ps.size() == 1 ? "" : "es")
                    + " for your reports."));
            card.getChildren().add(matchRow(ps.get(0)));
        }
        Button open = new Button("Open KITA AI");
        open.setStyle(smallSolidBtn());
        open.setOnAction(e -> showAssistant());
        card.getChildren().add(open);
        card.setPadding(new Insets(10, 12, 10, 12));
        card.setStyle(CARD);
        return card;
    }

    private static String soft(String hex) {
        Color c = Color.web(hex);
        return "rgba(" + (int) Math.round(c.getRed() * 255) + ","
                + (int) Math.round(c.getGreen() * 255) + ","
                + (int) Math.round(c.getBlue() * 255) + ",0.16)";
    }

    // =====================================================
    // ITEM DETAIL
    // =====================================================
    private Node buildDetailScreen(Item it) {
        return buildDetailScreen(it, admin ? this::showReports : this::showBrowse, "Back to Items");
    }

    private Node buildDetailScreen(Item it, Runnable backAction, String backText) {
        HBox back = new HBox(8, new Group(svg(ICON_BACK, 18, Theme.BLUE)), linkLabel(backText, backAction));
        back.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label(it.title);
        title.setWrapText(true);
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        HBox.setHgrow(title, Priority.ALWAYS);
        Label tag = new Label(it.type);
        tag.setStyle("-fx-background-color: " + kindColor(it) + "; -fx-text-fill: " + Theme.foreground(kindColor(it)) + "; "
                + "-fx-font-weight: bold; -fx-background-radius: 12; -fx-padding: 3 14 3 14;");
        HBox titleRow = new HBox(12, title, tag);
        titleRow.setAlignment(Pos.CENTER_LEFT);

        VBox info = new VBox(10,
                infoRow(it.type.equals("Lost") ? "Lost on" : "Found on", new Label(it.date.format(DATE_FMT))),
                infoRow("Location", new Label(it.location)),
                infoRow("Category", new Label(it.category)),
                infoRow("Reported by", new Label(it.reporter)),
                infoRow("Status", statusChip(it)));
        if (it.type.equals("Found") && !it.whereNow.isEmpty()) info.getChildren().add(infoRow("Now at", new Label(it.whereNow)));
        if (it.type.equals("Found") && !it.claimed) info.getChildren().add(infoRow("Countdown", countdownChip(it)));

        Label desc = new Label(it.description.isEmpty() ? "No extra details were added." : it.description);
        desc.setWrapText(true);
        desc.setStyle("-fx-text-fill: -cf-ink;");

        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox simHead = new HBox(sectionTitle("Similar Items"), gap, linkLabel("View All", () -> {
            catFilter.setValue(it.category);
            showBrowse();
        }));
        simHead.setAlignment(Pos.CENTER_LEFT);
        HBox simRow = new HBox(10);
        for (Item other : similarTo(it)) {
            Node thumb = itemPicture(other, 84, 84);
            thumb.setCursor(Cursor.HAND);
            Tooltip.install(thumb, new Tooltip(other.title));
            thumb.setOnMouseClicked(e -> showItemDetail(other));
            simRow.getChildren().add(thumb);
        }
        if (simRow.getChildren().isEmpty()) simRow.getChildren().add(emptyLine("No similar items yet."));

        VBox right = new VBox(14, titleRow, info, desc, simHead, simRow, buildItemActions(it));

        if (aiSuggestOn && !it.claimed) {
            List<Match> ms = matchesFor(it, 2);
            if (!ms.isEmpty()) {
                Label head = new Label("KITA AI: possible " + (it.type.equals("Lost") ? "found" : "lost")
                        + " item" + (ms.size() > 1 ? "s" : "") + " (suggestion only)");
                head.setStyle("-fx-text-fill: -cf-accent; -fx-font-weight: bold; -fx-font-size: 12px;");
                head.setGraphic(aiIcon(18));
                head.setGraphicTextGap(6);
                VBox aiBox = new VBox(4, head);
                for (Match m : ms) aiBox.getChildren().add(matchLine(m));
                right.getChildren().add(aiBox);
            }
        }
        HBox.setHgrow(right, Priority.ALWAYS);

        HBox card = new HBox(26, itemPicture(it, 380, 300), right);
        card.setPadding(new Insets(22));
        card.setStyle(CARD);
        card.setAlignment(Pos.TOP_LEFT);
        return pageOf(back, card);
    }

    private HBox infoRow(String label, Node value) {
        Label l = new Label(label);
        l.setPrefWidth(96);
        l.setStyle("-fx-text-fill: " + GREY_TEXT + ";");
        if (value instanceof Label && ((Label) value).getStyle().isEmpty()) {
            value.setStyle("-fx-text-fill: " + DARK + "; -fx-font-weight: bold;");
        }
        HBox h = new HBox(10, l, value);
        h.setAlignment(Pos.CENTER_LEFT);
        return h;
    }

    private List<Item> similarTo(Item it) {
        List<Item> out = new ArrayList<>();
        for (Match m : matchesFor(it, 3)) out.add(m.other);
        for (Item o : items) {
            if (out.size() >= 3) break;
            if (o != it && !o.claimed && o.category.equals(it.category) && !out.contains(o)) out.add(o);
        }
        return out;
    }

    private FlowPane buildItemActions(Item it) {
        FlowPane actions = new FlowPane(10, 10);
        boolean isLost = it.type.equals("Lost");
        String me = CurrentUser.getName();

        if (!admin && canClaim(it, me)) {
            Button claimBtn = new Button("Report a Claim");
            claimBtn.setStyle(primaryBtn());
            claimBtn.setOnAction(e -> {
                openClaimDialog(it);
                refresh();
            });
            actions.getChildren().add(claimBtn);
        } else if (!admin && myActiveClaim(it) != null) {
            Label yours = new Label("Your claim: " + claimLabel(myActiveClaim(it).status));
            yours.setStyle("-fx-text-fill: -cf-accent; -fx-font-weight: bold; -fx-padding: 10 0 10 0;");
            actions.getChildren().add(yours);
        }

        if (!admin && !it.claimed && !it.reporter.equalsIgnoreCase(me)) {
            Button chat = new Button(isLost ? "Message owner" : "Message finder");
            chat.setStyle(outlineBtn());
            chat.setOnAction(e -> {
                openChat(it, me);
            });
            actions.getChildren().add(chat);
        }

        if (!admin && isLost && !it.claimed && it.reporter.equalsIgnoreCase(me)) {
            Button back = new Button("Mark as recovered");
            back.setStyle(primaryBtn());
            back.setOnAction(e -> {
                markRecovered(it);
                refresh();
            });
            actions.getChildren().add(back);
        }

        if (admin) {
            // Administrators may contact the reporter directly from an item record.
            if (!it.reporter.equalsIgnoreCase(me)) {
                Button contact = new Button("Message Student");
                contact.setStyle(outlineBtn());
                contact.setOnAction(e -> openChat(it, me));
                actions.getChildren().add(contact);
            }
            if (!it.claimed) {
                Button done = new Button("Mark recovered");
                done.setStyle(primaryBtn());
                done.setOnAction(e -> {
                    markRecovered(it);
                    refresh();
                });
                actions.getChildren().add(done);
            }
            Button delete = new Button("Delete");
            delete.setStyle("-fx-background-color: -cf-error-bg; -fx-text-fill: -cf-danger; -fx-font-weight: bold; "
                    + "-fx-font-size: 14px; -fx-background-radius: 10; -fx-padding: 10 22 10 22; "
                    + "-fx-cursor: hand;");
            delete.setOnAction(e -> {
                deleteItem(it);
                refresh();
            });
            actions.getChildren().add(delete);
        }
        return actions;
    }

    // =====================================================
    // REPORT ITEM
    // =====================================================
    private VBox reportCategoryPicker(javafx.beans.property.ObjectProperty<ReportCategory> selection, BooleanProperty chosenByUser) {
        javafx.scene.control.ToggleButton choose = new javafx.scene.control.ToggleButton();
        choose.setId("choose-category");
        choose.setStyle(outlineBtn());
        choose.textProperty().bind(Bindings.createStringBinding(() ->
                selection.get() == null ? "Choose category ▾" : selection.get().label + " ▾", selection));
        TextField searchCategory = new TextField();
        searchCategory.setPromptText("Search categories, e.g. glasses");
        searchCategory.setMaxWidth(320);
        FlowPane choices = new FlowPane(6, 6);
        for (ReportCategory option : ReportCategory.values()) {
            Button chip = new Button(option.label);
            chip.setStyle(smallBtn());
            chip.visibleProperty().bind(Bindings.createBooleanBinding(() -> option.matches(searchCategory.getText()),
                    searchCategory.textProperty()));
            chip.managedProperty().bind(chip.visibleProperty());
            chip.setOnAction(e -> {
                chosenByUser.set(true);
                selection.set(option);
                choose.setSelected(false);
                choose.requestFocus();
            });
            choices.getChildren().add(chip);
        }
        Label empty = smallGrey("No matching categories. Clear the search to see all choices.");
        empty.visibleProperty().bind(Bindings.createBooleanBinding(() ->
                java.util.Arrays.stream(ReportCategory.values()).noneMatch(option -> option.matches(searchCategory.getText())), searchCategory.textProperty()));
        empty.managedProperty().bind(empty.visibleProperty());
        VBox options = new VBox(6, searchCategory, choices, empty);
        options.visibleProperty().bind(choose.selectedProperty());
        options.managedProperty().bind(options.visibleProperty());
        choose.selectedProperty().addListener((obs, previous, open) -> {
            searchCategory.clear();
            if (open) searchCategory.requestFocus();
        });
        options.setOnKeyPressed(e -> {
            if (e.getCode() == javafx.scene.input.KeyCode.ESCAPE) {
                choose.setSelected(false);
                choose.requestFocus();
                e.consume();
            }
        });
        return new VBox(5, fieldLabel("Category *"), choose, options);
    }

    private Node buildReportForm(String initialKind) {
        String[] kind = {initialKind};
        int[] step = {0};
        Runnable[] renderStep = {() -> {}};
        boolean[] submitted = {false};

        Label sub = new Label("Fill in the details below to report a lost or found item.");
        sub.setWrapText(true);
        sub.setStyle("-fx-text-fill: " + GREY_TEXT + ";");

        Button lostB = new Button("I lost something");
        Button foundB = new Button("I found something");
        HBox kindRow = new HBox(8, lostB, foundB);

        // extra details, only for FOUND items
        ComboBox<String> whereNow = new ComboBox<>();
        whereNow.getItems().addAll("With me", "Security office", "Library desk", "Lost & found office", "Other");
        whereNow.setValue("With me");
        whereNow.setMaxWidth(Double.MAX_VALUE);
        javafx.beans.property.ObjectProperty<ReportCategory> category = new javafx.beans.property.SimpleObjectProperty<>();
        TextField itemName = new TextField();
        itemName.setId("report-name");
        itemName.setPromptText("e.g., Black Backpack");
        itemName.setStyle(inputStyle());

        BooleanProperty chosenByUser = new SimpleBooleanProperty();
        VBox categoryPicker = reportCategoryPicker(category, chosenByUser);
        TextField secretQ = new TextField();
        secretQ.setId("verification-question");
        secretQ.setPromptText("Write a question about a detail only the owner would know");
        secretQ.setStyle(inputStyle());
        javafx.scene.control.PasswordField secretA = new javafx.scene.control.PasswordField();
        secretA.setId("verification-answer");
        secretA.setPromptText("Enter a short answer");
        secretA.setStyle(inputStyle());
        javafx.scene.control.CheckBox useVerification = new javafx.scene.control.CheckBox("Use an ownership question");
        useVerification.setSelected(true);
        javafx.scene.control.CheckBox privateDetail = new javafx.scene.control.CheckBox("I checked: the answer is not visible in the photo or public report.");
        privateDetail.setId("verification-private-confirmation");
        privateDetail.setWrapText(true);
        secretQ.textProperty().addListener((obs, old, value) -> privateDetail.setSelected(false));
        secretA.textProperty().addListener((obs, old, value) -> privateDetail.setSelected(false));
        String[] lastAutomatic = {""};
        Runnable updateQuestion = () -> {
            String next = ReportCategory.questionFor(itemName.getText(), category.get());
            boolean automatic = secretQ.getText().isBlank() || secretQ.getText().equals(lastAutomatic[0]);
            if (automatic && !next.equals(secretQ.getText())) {
                secretQ.setText(next);
                secretA.clear();
            }
            lastAutomatic[0] = next;
        };
        itemName.textProperty().addListener((obs, old, text) -> {
            if (!chosenByUser.get()) category.set(ReportCategory.infer(text));
            updateQuestion.run();
        });
        category.addListener((obs, old, selected) -> updateQuestion.run());
        VBox fields = new VBox(6, wrapLabel("CampusFind suggests a question about a hidden detail. Edit it if needed; avoid visible colors, logos or brands. Do not request passwords or PINs. If no private detail can be checked, turn off this question and let staff review ownership evidence."),
                fieldLabel("Question for the claimant"), secretQ,
                fieldLabel("Secret answer · staff only"), secretA, privateDetail);
        fields.visibleProperty().bind(useVerification.selectedProperty());
        fields.managedProperty().bind(fields.visibleProperty());
        VBox verification = new VBox(6, sectionTitle("Ownership verification"), useVerification, fields);
        verification.setPadding(new Insets(12));
        verification.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 10;");
        VBox whereBox = new VBox(6, fieldLabel("Where is it now?"), whereNow);
        VBox foundRow = new VBox(10, verification);
        whereBox.visibleProperty().bind(foundRow.visibleProperty());
        whereBox.managedProperty().bind(whereBox.visibleProperty());

        Label locLabel = fieldLabel("Last Seen Location *");
        Label dateLabel = fieldLabel("Date Lost *");
        Runnable paintKind = () -> {
            styleChip(lostB, kind[0].equals("Lost"));
            styleChip(foundB, kind[0].equals("Found"));
            locLabel.setText(kind[0].equals("Lost") ? "Last Seen Location *" : "Where did you find it? *");
            dateLabel.setText(kind[0].equals("Lost") ? "Date Lost *" : "Date Found *");
            foundRow.setVisible(kind[0].equals("Found"));
            foundRow.setManaged(kind[0].equals("Found"));
        };
        lostB.setOnAction(e -> {
            kind[0] = "Lost";
            paintKind.run();
        });
        foundB.setOnAction(e -> {
            kind[0] = "Found";
            paintKind.run();
        });
        paintKind.run();

        TextArea details = new TextArea();
        details.setPromptText("Describe the item (color, brand, unique features, etc.)");
        details.setPrefRowCount(3);
        details.setId("report-description");
        details.textProperty().addListener((obs, old, value) -> privateDetail.setSelected(false));
        itemName.textProperty().addListener((obs, old, value) -> privateDetail.setSelected(false));
        details.setWrapText(true);

        TextField location = new TextField();
        location.setId("report-location");
        location.setPromptText("e.g., Library, Cafeteria, etc.");
        location.setStyle(inputStyle());

        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.setId("report-date");
        datePicker.setEditable(false);
        datePicker.setDayCellFactory(picker -> new javafx.scene.control.DateCell() {
            @Override public void updateItem(LocalDate day, boolean empty) {
                super.updateItem(day, empty);
                setDisable(empty || day.isAfter(LocalDate.now()));
            }
        });
        datePicker.setMaxWidth(Double.MAX_VALUE);

        VBox nameBox = new VBox(6, fieldLabel("Item Name *"), itemName);

        VBox locBox = new VBox(6, locLabel, location);
        VBox dateBox = new VBox(6, dateLabel, datePicker);

        Image[] photoPick = new Image[1];
        StackPane cameraBox = new StackPane(new Group(svg(ICON_CAMERA, 28, Theme.BLUE)));
        cameraBox.setMinSize(64, 48);
        cameraBox.setPrefSize(64, 48);
        cameraBox.setStyle("-fx-background-color: " + Theme.TINT + "; -fx-background-radius: 12;");

        Label upTitle = new Label("Upload Photo (optional)");
        upTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label upHint = new Label("Click to upload an image (png, jpg, gif)");
        upHint.setWrapText(true);
        upHint.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        VBox upText = new VBox(4, upTitle, upHint);
        upText.setAlignment(Pos.CENTER_LEFT);

        Label removePhoto = linkLabel("Remove photo", () -> { });
        removePhoto.setVisible(false);
        removePhoto.setManaged(false);

        StackPane previewHolder = new StackPane(cameraBox);
        HBox uploadBox = new HBox(16, previewHolder, new VBox(6, upText, removePhoto));
        uploadBox.setAlignment(Pos.CENTER_LEFT);
        uploadBox.setPadding(new Insets(6));
        uploadBox.setCursor(Cursor.HAND);
        uploadBox.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 12; "
                + "-fx-border-color: " + Theme.TINT_LINE + "; -fx-border-style: dashed; -fx-border-radius: 12;");
        uploadBox.setOnMouseClicked(e -> {
            FileChooser fc = new FileChooser();
            fc.setTitle("Choose a photo of the item");
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter(
                    "Images", "*.png", "*.jpg", "*.jpeg", "*.gif"));
            File file = fc.showOpenDialog(root.getScene().getWindow());
            if (file != null) {
                Image img;
                try {
                    img = new Image(CampusLocalStore.keepPhoto(file), 800, 800, true, true);
                } catch (java.io.IOException ex) {
                    popup("Photo", wrapLabel("Could not save the photo: " + ex.getMessage()));
                    return;
                }
                if (!img.isError()) {
                    photoPick[0] = img;
                    privateDetail.setSelected(false);
                    previewHolder.getChildren().setAll(photoView(img, 64, 48));
                    upTitle.setText("Photo added");
                    upHint.setText("Click to change the photo");
                    removePhoto.setVisible(true);
                    removePhoto.setManaged(true);
                }
            }
        });
        removePhoto.setOnMouseClicked(e -> {
            photoPick[0] = null;
            privateDetail.setSelected(false);
            previewHolder.getChildren().setAll(cameraBox);
            upTitle.setText("Upload Photo (optional)");
            upHint.setText("Click to upload an image (png, jpg, gif)");
            removePhoto.setVisible(false);
            removePhoto.setManaged(false);
            e.consume();
        });

        Label error = new Label();
        error.setId("report-error");
        error.setWrapText(true);
        error.setStyle("-fx-text-fill: -cf-danger;");

        Button cancel = new Button("Cancel");
        cancel.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: " + DARK + "; -fx-font-weight: bold; "
                + "-fx-background-radius: 10; -fx-padding: 10 24 10 24; -fx-cursor: hand;");
        cancel.setOnAction(e -> {
            if (itemName.getText().isBlank() && details.getText().isBlank() && location.getText().isBlank() && photoPick[0] == null) showDashboard();
            else confirmBox("Discard this report?", wrapLabel("Your unsaved entries will be discarded."), "Discard report", this::showDashboard);
        });

        Button submit = new Button("Submit Report");
        submit.setStyle(primaryBtn());
        submit.setOnAction(e -> {
            if (step[0] != 2 || submitted[0]) return;
            String n = itemName.getText().trim();
            String l = location.getText().trim();
            String d = details.getText().trim();
            if (n.isEmpty() || l.isEmpty() || d.isEmpty()) {
                step[0] = n.isEmpty() || d.isEmpty() ? 0 : 1;
                renderStep[0].run();
                error.setText("Please fill in the item name, the description and the location.");
                return;
            }
            if (category.get() == null) {
                step[0] = 0; renderStep[0].run();
                error.setText("Choose an item category.");
                categoryPicker.lookup("#choose-category").requestFocus();
                return;
            }
            if (kind[0].equals("Found") && useVerification.isSelected()
                    && (secretQ.getText().isBlank() || secretA.getText().isBlank())) {
                boolean missingQuestion = secretQ.getText().isBlank();
                error.setText(missingQuestion ? "Add a verification question for your secret answer."
                        : "Enter a secret answer for your verification question.");
                (missingQuestion ? secretQ : secretA).requestFocus();
                return;
            }
            if (kind[0].equals("Found") && useVerification.isSelected()) {
                if (ReportCategory.answerAppearsPublic(secretA.getText(), n + " " + d + " " + l + " " + secretQ.getText())) {
                    error.setText("The secret answer appears in the public text or question. Choose a different hidden detail.");
                    return;
                }
                if (!privateDetail.isSelected()) {
                    error.setText("Check the photo and public report, then confirm that the answer is hidden.");
                    privateDetail.requestFocus();
                    return;
                }
            }
            if (datePicker.getValue() == null || datePicker.getValue().isAfter(LocalDate.now())) {
                step[0] = 1; renderStep[0].run();
                error.setText("Choose a date on or before today."); return;
            }
            Item posted = new Item(kind[0], n, l, d, CurrentUser.getName());
            if (kind[0].equals("Found")) {
                posted.whereNow = whereNow.getValue();
                if (useVerification.isSelected()) {
                    posted.secretQuestion = secretQ.getText().trim();
                    posted.secretAnswer = secretA.getText().trim();
                }
            }
            posted.photo = photoPick[0];
            posted.category = category.get().label;
            posted.date = datePicker.getValue() != null ? datePicker.getValue() : LocalDate.now();
            submitted[0] = true;
            submit.setDisable(true);
            items.add(posted);
            audit(CurrentUser.getName(), "New " + kind[0].toLowerCase() + " item reported", n);

            refresh();
            if (admin) {
                adminReportsTab = "All";
                showReports();
            } else {
                myReportsTab = "Posts";
                showMyReports();
            }
            if (notifOn && CampusPreferences.current().matchAlerts) showMatchPopup(posted);
        });

        VBox itemStep = new VBox(12, kindRow, nameBox, categoryPicker,
                new VBox(6, fieldLabel("Description *"), details,
                        smallGrey("Describe visible features. Keep private ownership clues out of the description.")));
        VBox locationStep = new VBox(12, locBox, dateBox, whereBox);
        VBox photoStep = new VBox(12, new VBox(6, fieldLabel("Item photo (optional)"), uploadBox), foundRow);
        VBox[] pages = {itemStep, locationStep, photoStep};
        for (int i = 0; i < pages.length; i++) pages[i].setId("report-step-" + (i + 1));
        StackPane stage = new StackPane(pages);
        stage.setAlignment(Pos.TOP_LEFT);
        FlowPane progress = new FlowPane(12, 8);
        progress.setId("report-progress");
        String[] titles = {"Item details", "Location & date", "Photos & verification"};
        Label guidance = wrapLabel("");
        VBox helper = new VBox(12, sectionTitle("A clear report helps"), guidance);
        helper.setPadding(new Insets(16));
        helper.setStyle(CARD);
        helper.setMaxHeight(Region.USE_PREF_SIZE);
        helper.setMinWidth(0);
        VBox form = new VBox(12, stage);
        form.setMinWidth(0);
        form.setPadding(new Insets(16));
        form.setStyle(CARD);
        Button back = new Button("Back");
        back.setStyle(smallBtn());
        back.setId("report-back");
        Button next = new Button("Continue");
        next.setStyle(primaryBtn());
        next.setId("report-continue");
        submit.setId("report-submit");
        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox buttons = new HBox(10, back, gap, cancel, next, submit);
        buttons.setAlignment(Pos.CENTER_LEFT);
        form.getChildren().addAll(error, buttons);
        String[] tips = {
                "Use a recognizable item name and choose a category. Describe visible details only. Required fields have an asterisk (*).",
                "Use a clear campus location, such as Library, second floor. Choose the date it was lost or found. Future dates are not allowed.",
                "A clear photo helps others recognize the item. For found items, choose a hidden detail for verification. The answer must stay out of the public photo and description."};
        renderStep[0] = () -> {
            for (int i = 0; i < pages.length; i++) {
                pages[i].setVisible(i == step[0]);
                pages[i].setManaged(i == step[0]);
            }
            progress.getChildren().clear();
            for (int i = 0; i < titles.length; i++) {
                Label label = new Label((i < step[0] ? "✓ " : (i + 1) + ". ") + titles[i]);
                label.getStyleClass().add(i == step[0] ? "wizard-current" : "wizard-step");
                progress.getChildren().add(label);
            }
            guidance.setText(tips[step[0]]);
            back.setDisable(step[0] == 0);
            next.setVisible(step[0] < 2);
            next.setManaged(next.isVisible());
            submit.setVisible(step[0] == 2);
            submit.setManaged(submit.isVisible());
            error.setText("");
        };
        back.setOnAction(e -> { if (step[0] > 0) { step[0]--; renderStep[0].run(); } });
        next.setOnAction(e -> {
            if (step[0] == 0) {
                if (itemName.getText().isBlank()) { error.setText("Enter an item name."); itemName.requestFocus(); return; }
                if (category.get() == null) { error.setText("Choose an item category."); return; }
                if (details.getText().isBlank()) { error.setText("Describe the item before continuing."); details.requestFocus(); return; }
            } else if (step[0] == 1) {
                if (location.getText().isBlank()) { error.setText("Enter the lost or found location."); location.requestFocus(); return; }
                if (datePicker.getValue() == null || datePicker.getValue().isAfter(LocalDate.now())) {
                    error.setText("Choose a date on or before today."); datePicker.requestFocus(); return;
                }
            }
            if (step[0] < 2) { step[0]++; renderStep[0].run(); }
        });
        renderStep[0].run();
        javafx.scene.layout.GridPane columns = new javafx.scene.layout.GridPane();
        columns.setHgap(16); columns.setVgap(12);
        columns.add(form, 0, 0); columns.add(helper, 1, 0);
        javafx.scene.layout.GridPane.setValignment(helper, javafx.geometry.VPos.TOP);
        Runnable fit = () -> {
            boolean narrow = columns.getWidth() < 900;
            javafx.scene.layout.ColumnConstraints left = new javafx.scene.layout.ColumnConstraints();
            left.setPercentWidth(narrow ? 100 : 72);
            javafx.scene.layout.ColumnConstraints right = new javafx.scene.layout.ColumnConstraints();
            right.setPercentWidth(28);
            columns.getColumnConstraints().setAll(left);
            if (!narrow) columns.getColumnConstraints().add(right);
            javafx.scene.layout.GridPane.setColumnIndex(helper, narrow ? 0 : 1);
            javafx.scene.layout.GridPane.setRowIndex(helper, narrow ? 1 : 0);
        };
        columns.widthProperty().addListener((o, old, w) -> { if ((old.doubleValue() < 900) != (w.doubleValue() < 900)) fit.run(); });
        fit.run();
        ScrollPane page = pageOf(1160,
                campusFeatureBanner("Report an Item", "Share enough detail to help return an item to its owner"),
                progress, columns);
        page.setId("report-wizard");
        return page;
    }

    private Label fieldLabel(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-font-weight: bold; -fx-font-size: 13px; -fx-text-fill: " + DARK + ";");
        return l;
    }

    private String inputStyle() {
        return "-fx-padding: 10; -fx-background-radius: 10;";
    }

    // =====================================================
    // MY REPORTS
    // =====================================================
    private Node buildMyReports() {
        String me = CurrentUser.getName();

        HBox seg = new HBox(8);
        for (String t : new String[]{"Posts", "Claims"}) {
            Button b = new Button(t.equals("Posts") ? "My Posts" : "My Claims");
            styleChip(b, t.equals(myReportsTab));
            b.setOnAction(e -> {
                myReportsTab = t;
                showMyReports();
            });
            seg.getChildren().add(b);
        }

        VBox list = new VBox(10);
        if (myReportsTab.equals("Posts")) {
            int n = 0;
            for (int i = items.size() - 1; i >= 0; i--) {
                Item it = items.get(i);
                if (!it.reporter.equalsIgnoreCase(me)) continue;
                list.getChildren().add(buildReportRow(it));
                n++;
            }
            if (n == 0) {
                list.getChildren().add(emptyState(ICON_CLAIM, Theme.BLUE, "No reports yet",
                        "Select Report Item to post a lost or found item.", null, null));
            }
        } else {
            List<Claim> mine = new ArrayList<>();
            for (Claim c : claims) {
                if (c.accountId.equalsIgnoreCase(CurrentUser.getStudentId()) && items.contains(c.item)) mine.add(c);
            }
            mine.sort((a, b) -> b.time.compareTo(a.time));
            for (Claim c : mine) list.getChildren().add(buildMyClaimCard(c));
            if (mine.isEmpty()) {
                list.getChildren().add(emptyState(ICON_CLAIM, Theme.BLUE, "No claim requests yet",
                        "Find your item in Browse Items or KITA AI, then submit a claim.", null, null));
            }
        }

        ScrollPane page = pageOf(campusFeatureBanner("My Reports & Claims",
                "Track your lost items, found reports and claim progress"), seg, list);
        page.setId("cf-my-reports");
        return page;
    }

    private VBox buildReportRow(Item it) {
        Label title = new Label(it.title);
        title.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label meta = new Label(it.category + "  |  " + it.location);
        meta.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        VBox info = new VBox(3, title, kindAndDate(it, 12), meta);
        info.setMinWidth(0);
        HBox.setHgrow(info, Priority.ALWAYS);

        HBox top = new HBox(14, itemPicture(it, 64, 64), info, statusChip(it));
        top.setAlignment(Pos.CENTER_LEFT);

        FlowPane btns = new FlowPane(8, 8);
        Button view = new Button("View Details");
        view.setStyle(outlineBtn());
        view.setOnAction(e -> showItemDetail(it));
        btns.getChildren().add(view);

        if (!it.claimed && it.type.equals("Lost")) {
            Button done = new Button("Mark as recovered");
            done.setStyle(primaryBtn());
            done.setOnAction(e -> {
                markRecovered(it);
                refresh();
                showMyReports();
            });
            btns.getChildren().add(done);
        }
        Button delete = new Button("Delete");
        delete.setStyle("-fx-background-color: -cf-error-bg; -fx-text-fill: -cf-danger; -fx-font-weight: bold; "
                + "-fx-background-radius: 10; -fx-padding: 9 18 9 18; -fx-cursor: hand;");
        delete.setOnAction(e -> {
            deleteItem(it);
            refresh();
            showMyReports();
        });
        btns.getChildren().add(delete);

        VBox row = new VBox(10, top, btns);
        row.setPadding(new Insets(12));
        row.setStyle(CARD);
        return row;
    }

    private String claimId(Claim c) {
        return "CLM-" + c.time.getYear() + "-" + String.format("%03d", claims.indexOf(c) + 1);
    }

    private void openClaimDetails(Claim c) {
        Item it = c.item;

        Label name = new Label(it.title);
        name.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label cid = new Label("Claim ID: " + claimId(c));
        cid.setStyle("-fx-text-fill: " + GREY_TEXT + ";");
        Label rep = new Label("Reported: " + it.date.format(DATE_FMT));
        rep.setStyle("-fx-text-fill: " + GREY_TEXT + ";");
        Label cat = new Label("Category: " + it.category);
        cat.setStyle("-fx-text-fill: " + GREY_TEXT + ";");
        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox top = new HBox(14, itemPicture(it, 90, 90), new VBox(3, name, cid, rep, cat), gap,
                claimChip(c.status));
        top.setAlignment(Pos.CENTER_LEFT);

        Label infoTitle = sectionTitle("Claim Information");
        Label n1 = wrapLabel("Name: " + c.claimant);
        Label n2 = wrapLabel("Submitted: " + c.time.toLocalDate().format(DATE_FMT));
        Label n3 = wrapLabel("Proof: " + c.proof);

        Label nextAction = wrapLabel("Next action: " + claimNextAction(c));
        nextAction.setStyle("-fx-text-fill: #103b87; -fx-font-weight: bold; -fx-font-size: 12px;");
        HBox nextBox = new HBox(9, new Group(svg(ICON_CLAIM, 18, "#125bc7")), nextAction);
        nextBox.setAlignment(Pos.CENTER_LEFT);
        nextBox.setPadding(new Insets(12));
        nextBox.setStyle("-fx-background-color: #edf5ff; -fx-background-radius: 12; "
                + "-fx-border-color: #c4d9f8; -fx-border-radius: 12;");
        HBox.setHgrow(nextAction, Priority.ALWAYS);
        VBox body = new VBox(12, top, infoTitle, n1, n2, n3, sectionTitle("Current Status"),
                buildTimeline(c), nextBox);
        body.setPrefWidth(540);
        popup("Claim Details", body);
    }

    private Node buildTimeline(Claim c) {
        boolean rejected = "Rejected".equals(c.status);
        boolean approved = "Approved".equals(c.status) || "Released".equals(c.status);
        boolean released = "Released".equals(c.status);
        String[] titles = {"Submitted", "Under review", rejected ? "Not approved" : "Approved", "Released"};
        String[] notes = {c.time.toLocalDate().format(DATE_FMT),
                "Pending".equals(c.status) ? (c.requests.stream().anyMatch(r -> r.reply.isBlank()) ? "Details requested" : "In review queue") : "Review completed",
                c.decided == null ? (approved || rejected ? "Decision recorded" : "Waiting for review") : c.decided.toLocalDate().format(DATE_FMT),
                rejected ? "Not applicable" : c.released == null ? (approved ? "Awaiting pickup" : "After approval") : c.released.toLocalDate().format(DATE_FMT)};
        FlowPane timeline = new FlowPane(10, 8);
        timeline.setId("claim-timeline");
        for (int i = 0; i < titles.length; i++) {
            boolean completed = i == 0 || (i == 1 && (approved || rejected)) || (i == 2 && approved) || (i == 3 && released);
            boolean current = (i == 1 && "Pending".equals(c.status)) || (i == 3 && "Approved".equals(c.status));
            Label title = fieldLabel((completed ? "✓ " : current ? "● " : (i + 1) + ". ") + titles[i]);
            Label note = smallGrey(notes[i]);
            VBox step = new VBox(4, title, note);
            step.setMinWidth(146);
            step.setPadding(new Insets(9));
            String tone = rejected && i == 2 ? "#fff0f2" : current ? "#fff6d7"
                    : completed ? "#eaf3ff" : "#f6f9ff";
            String edge = rejected && i == 2 ? "#d2344d" : current ? "#f1bc18"
                    : completed ? "#1559c8" : "#d6e3f6";
            step.setStyle("-fx-background-color: " + tone + "; -fx-background-radius: 11; "
                    + "-fx-border-radius: 11; -fx-border-color: " + edge + "; -fx-padding: 10;");
            timeline.getChildren().add(step);
        }
        return timeline;
    }

    private String claimNextAction(Claim c) {
        return switch (c.status) {
            case "Pending" -> c.requests.stream().anyMatch(r -> r.reply.isBlank())
                    ? "Reply to the staff question below so your claim can be reviewed."
                    : "Wait for staff to review your proof. Check notifications for any request for details.";
            case "Approved" -> "Bring your school ID to the lost and found office. Staff must verify your ID before release.";
            case "Released" -> "Completed — the item has been returned to you. No further action is needed.";
            case "Rejected" -> c.item.claimed ? "This claim is closed and the item is no longer available. Contact the office if you need clarification."
                    : "Contact the lost and found office if you want clarification or have additional ownership evidence.";
            default -> "Contact the lost and found office for an update.";
        };
    }

    // =====================================================
    // NOTIFICATIONS
    // =====================================================
    static class Notice {
        String id;
        String kind;
        String title;
        String text;
        LocalDateTime time;
        boolean unread;
        String icon;
        String color;
        Runnable action;
    }

    private static final Set<String> seenNotices = new HashSet<>();
    private static final Map<String, LocalDateTime> noticeTimes = new HashMap<>();
    private static final LocalDateTime APP_START = LocalDateTime.now();

    private Notice notice(String id, String kind, String title, String text, LocalDateTime time,
                          String icon, String color, Runnable action) {
        Notice n = new Notice();
        n.id = id;
        n.kind = kind;
        n.title = title;
        n.text = text;
        n.time = time != null ? time : noticeTimes.computeIfAbsent(id, k -> LocalDateTime.now());
        n.unread = !seenNotices.contains(id);
        n.icon = icon;
        n.color = color;
        n.action = action;
        return n;
    }

    private List<Notice> buildNotices() {
        String me = CurrentUser.getName();
        List<Notice> out = new ArrayList<>();

        if (admin) {
            for (Claim c : claims) {
                if (!items.contains(c.item)) continue;
                String cid = System.identityHashCode(c) + "";
                if (c.status.equals("Pending")) {
                    for (DetailRequest r : c.requests) {
                        if (r.answered != null) out.add(notice("reply-" + cid + "-" + r.asked, "Claims",
                                "Claim details received", c.claimant + " replied about " + c.item.title,
                                r.answered, ICON_CLAIM, Theme.BLUE, () -> {
                                    claimsSection = "Needs verification";
                                    selectedClaim = c;
                                    showAdminClaims();
                                }));
                    }
                    out.add(notice("claim-new-" + cid, "Claims", "New claim request",
                            c.claimant + " sent a claim for " + c.item.title
                                    + ". Verify the proof of ownership.",
                            c.time, ICON_CLAIM, "#f59e0b", this::showAdminClaims));
                }
                if (c.status.equals("Approved")) {
                    out.add(notice("claim-wait-" + cid, "Claims", "Waiting for handover",
                            c.item.title + " is approved for " + c.claimant
                                    + ". Check the student's school ID before releasing it.",
                            c.decided, ICON_CHECK, "#3b82f6", this::showAdminClaims));
                }
            }
            int m = collectPairs().size();
            if (m > 0) {
                out.add(notice("admin-matches-" + m, "Updates", "AI found possible matches",
                        m + " possible match" + (m == 1 ? "" : "es")
                                + " between lost and found reports.",
                        null, ICON_MATCH, Theme.BLUE, this::showMatches));
            }
        } else {
            for (Pair p : collectPairs()) {
                boolean mineLost = p.lost.reporter.equalsIgnoreCase(me);
                String id = "match-" + System.identityHashCode(p.lost) + "-"
                        + System.identityHashCode(p.found);
                out.add(notice(id, "Updates",
                        mineLost ? "Your lost item has a possible match!"
                                : "Your found item may belong to someone",
                        "We found a potential match for " + (mineLost ? p.lost.title : p.found.title)
                                + " (" + p.pct + "% match).",
                        null, ICON_MATCH, "#ef4444", this::showMatches));
            }

            for (Claim c : claims) {
                if (!c.accountId.equalsIgnoreCase(CurrentUser.getStudentId()) || !items.contains(c.item)) continue;
                String id = "claim-" + System.identityHashCode(c) + "-" + c.status;
                Runnable open = this::showClaims;
                if (c.status.equals("Pending")) {
                    for (DetailRequest r : c.requests) {
                        if (r.reply.isEmpty()) out.add(notice("question-" + id + "-" + r.asked, "Claims",
                                "Staff requested more details", "Open your claim for " + c.item.title + " to reply.",
                                r.asked, ICON_CLAIM, Theme.BLUE, open));
                    }
                    out.add(notice(id, "Claims", "Claim status updated",
                            "Your claim for the " + c.item.title + " is now under review.",
                            c.time, ICON_CLAIM, "#f59e0b", open));
                } else if (c.status.equals("Approved")) {
                    out.add(notice(id, "Claims", "Claim approved",
                            "Bring your school ID (Student ID " + c.studentId + ") to the staff to "
                                    + "receive the item.",
                            c.decided != null ? c.decided : c.time, ICON_CHECK, "#22a06b", open));
                } else if (c.status.equals("Rejected")) {
                    out.add(notice(id, "Claims", "Claim not approved",
                            "The admin could not verify your claim for " + c.item.title + ".",
                            c.decided != null ? c.decided : c.time, ICON_CLAIM, "#ef4444", open));
                } else if (c.status.equals("Released")) {
                    out.add(notice(id, "Updates", "Item returned",
                            "Your " + c.item.title + " has been returned. Thank you for using "
                                    + "Campus Lost & Found!",
                            c.released != null ? c.released : c.time, ICON_CHECK, "#22a06b", open));
                }
            }

            for (Convo cv : collectConvos(me)) {
                if (cv.unread == 0) continue;
                boolean iAmPoster = cv.item.reporter.equalsIgnoreCase(me);
                String other = iAmPoster ? cv.inquirer : cv.item.reporter;
                String id = "msg-" + System.identityHashCode(cv.item) + "-" + cv.inquirer.toLowerCase()
                        + "-" + cv.last.time;
                out.add(notice(id, "Updates", "New message from " + other, cv.last.text,
                        cv.last.time, ICON_CHAT, "#3b82f6", this::showMessages));
            }

            for (String term : myWatch(me)) {
                for (Item w : items) {
                    if (!w.type.equals("Found") || w.claimed || w.reporter.equalsIgnoreCase(me)) continue;
                    if (!watchMatches(term, w)) continue;
                    out.add(notice("watch-" + term.hashCode() + "-" + System.identityHashCode(w), "Updates",
                            "Watchlist alert: " + term,
                            w.title + " was found at " + w.location + ". Tap to view.",
                            null, ICON_BELL, "#f59e0b", () -> showItemDetail(w)));
                }
            }

            int count = 0;
            for (int i = items.size() - 1; i >= 0 && count < 2; i--) {
                Item it = items.get(i);
                if (!it.type.equals("Found") || it.claimed || it.reporter.equalsIgnoreCase(me)) continue;
                out.add(notice("found-" + System.identityHashCode(it), "Updates", "New found item",
                        it.reporter + " found " + it.title + " at " + it.location + ". View details.",
                        null, ICON_PIN, Theme.BLUE, () -> showItemDetail(it)));
                count++;
            }
        }

        out.add(notice("welcome", "System", "Welcome to Campus Lost & Found",
                "Report lost items, post found items and let KITA AI help you recover them.",
                APP_START, ICON_PIN, "#7c3aed", this::showAssistant));

        CampusPreferences prefs = CampusPreferences.current();
        out.removeIf(n -> {
            if (!prefs.notifications) return !"System".equals(n.kind);
            if (!prefs.claimAlerts && "Claims".equals(n.kind)) return true;
            if (!prefs.messageAlerts && n.id.startsWith("msg-")) return true;
            if (!prefs.matchAlerts && (n.id.startsWith("match-") || n.id.startsWith("admin-matches-")
                    || n.id.startsWith("watch-"))) return true;
            return false;
        });
        out.sort((a, b) -> b.time.compareTo(a.time));
        return out;
    }

    private int unreadNoticeCount() {
        int n = 0;
        for (Notice x : buildNotices()) {
            if (x.unread) n++;
        }
        return n;
    }

    private static String ago(LocalDateTime t) {
        long min = java.time.Duration.between(t, LocalDateTime.now()).toMinutes();
        if (min < 1) return "Just now";
        if (min < 60) return min + (min == 1 ? " minute ago" : " minutes ago");
        long h = min / 60;
        if (h < 24) return h + (h == 1 ? " hour ago" : " hours ago");
        long d = h / 24;
        return d + (d == 1 ? " day ago" : " days ago");
    }

    private Node buildNoticesView() {
        int unreadCount = noticeUnread.size();
        String[] tabs = {"All", "Unread (" + unreadCount + ")", "System", "Claims", "Updates"};
        String[] keys = {"All", "Unread", "System", "Claims", "Updates"};

        FlowPane seg = new FlowPane(8, 8);
        for (int i = 0; i < tabs.length; i++) {
            String key = keys[i];
            Button b = new Button(tabs[i]);
            styleChip(b, key.equals(noticeTab));
            b.setOnAction(e -> {
                noticeTab = key;
                openScreen(buildNoticesView(), notifNav, false, false);
            });
            seg.getChildren().add(b);
        }

        VBox list = new VBox(10);
        int shown = 0;
        for (Notice n : noticeList) {
            boolean unread = noticeUnread.contains(n.id);
            if (noticeTab.equals("Unread") && !unread) continue;
            if ((noticeTab.equals("System") || noticeTab.equals("Claims") || noticeTab.equals("Updates"))
                    && !n.kind.equals(noticeTab)) continue;

            StackPane bubble = new StackPane(new Group(svg(n.icon, 20, n.color)));
            bubble.setMinSize(44, 44);
            bubble.setPrefSize(44, 44);
            bubble.setMaxSize(44, 44);
            bubble.setStyle("-fx-background-color: " + soft(n.color) + "; -fx-background-radius: 22;");

            Label t = new Label(n.title);
            t.setWrapText(true);
            t.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: " + DARK + ";");
            Label d = new Label(n.text);
            d.setWrapText(true);
            d.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12.5px;");
            VBox text = new VBox(3, t, d);
            text.setMinWidth(0);
            HBox.setHgrow(text, Priority.ALWAYS);

            Label when = new Label(ago(n.time));
            when.setMinWidth(Region.USE_PREF_SIZE);
            when.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");

            HBox row = new HBox(14, bubble, text, when);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(14, 18, 14, 18));
            String baseStyle = unread ? "-fx-background-color: " + Theme.TINT_SOFT + ";" : "-fx-background-color: -cf-panel;";
            row.getStyleClass().add("notice-row");
            row.setStyle(baseStyle);
            row.setPickOnBounds(true);
            if (n.action != null) {
                row.setCursor(Cursor.HAND);
                row.setOnMouseEntered(e -> row.setStyle("-fx-background-color: " + Theme.TINT_HOVER + ";"));
                row.setOnMouseExited(e -> row.setStyle(baseStyle));
                row.setOnMouseClicked(e -> n.action.run());
            }
            list.getChildren().add(row);
            shown++;
        }
        if (shown == 0) {
            list.getChildren().add(emptyLine("Nothing here yet."));
            list.setPadding(new Insets(28));
        }

        return pageOf(pageTitle("Notifications"), seg, list);
    }

    // =====================================================
    // SETTINGS V3 — role-specific, stored per account on this computer.
    // =====================================================
    private VBox settingsCard(String title, String detail, Node... contents) {
        Label heading = new Label(title);
        heading.setWrapText(true);
        heading.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #0b3477;");
        Label hint = new Label(detail);
        hint.setWrapText(true);
        hint.setStyle("-fx-font-size: 12px; -fx-text-fill: #587295;");
        VBox box = new VBox(11, heading, hint);
        box.getChildren().addAll(contents);
        box.setPadding(new Insets(19));
        box.setMinWidth(0);
        box.setPrefWidth(425);
        box.setMaxWidth(Double.MAX_VALUE);
        box.getStyleClass().add("settings-v3-card");
        return box;
    }

    private Label settingsLabel(String title) {
        Label label = new Label(title);
        label.setWrapText(true);
        label.setStyle("-fx-font-weight: bold; -fx-text-fill: #123975; -fx-font-size: 12px;");
        return label;
    }

    private VBox settingsField(String caption, Node field) {
        VBox box = new VBox(5, settingsLabel(caption), field);
        box.setMinWidth(0);
        return box;
    }

    private javafx.scene.control.CheckBox settingsCheck(String label, boolean checked) {
        javafx.scene.control.CheckBox cb = new javafx.scene.control.CheckBox(label);
        cb.setSelected(checked);
        cb.setWrapText(true);
        cb.setStyle("-fx-text-fill: #1c4074; -fx-font-size: 12px;");
        return cb;
    }

    private Button settingsSaveButton(String title) {
        Button button = new Button(title);
        button.setStyle("-fx-background-color: #ffca23; -fx-text-fill: #0b3178; "
                + "-fx-font-weight: bold; -fx-background-radius: 10; -fx-padding: 10 20;");
        return button;
    }

    // SETTINGS V4: The landing view uses one short row of panels (Admin), or a
    // profile summary plus a 2x2 menu (Student). No nested scroll panes or tall forms.
    private Node buildSettingsScreen() {
        VBox content = new VBox(13);
        content.getStyleClass().add("cf-settings-home");
        content.getChildren().add(settingsHomeBanner());
        if (admin) content.getChildren().add(buildCompactAdminSettings());
        else content.getChildren().add(buildCompactStudentSettings());
        // A normal parent scrollbar is a fallback only on unusually small windows.
        return pageOf(1450, content);
    }

    private Node settingsHomeBanner() {
        StackPane banner = (StackPane) campusFeatureBanner(admin ? "Admin Settings" : "Student Settings",
                admin ? "Manage system access, notifications, policies and data"
                        : "Manage your profile, messaging, privacy and preferences");
        banner.setMinHeight(88);
        banner.setPrefHeight(100);
        banner.setMaxHeight(105);
        return banner;
    }

    private String settingsCategoryTitle(String category) {
        return switch (category) {
            case "profile" -> "Edit Profile & Academic Information";
            case "alerts" -> "Notifications & KITA AI";
            case "messenger" -> "Messenger Preferences";
            case "access" -> "Accessibility";
            case "security" -> "Privacy & Account Security";
            case "policy" -> "Claim & Item Policies";
            case "admins" -> "Assistant Admins";
            case "backup" -> "Backup & Export";
            case "audit" -> "Audit Logs & Help";
            default -> "Settings";
        };
    }

    private VBox settingsOverviewPanel(String title, String iconPath, String subtitle, Node... controls) {
        SVGPath icon = svg(iconPath, 18, "#ffca23");
        Label caption = new Label(title);
        caption.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");
        HBox header = new HBox(8, icon, caption);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("cf-settings-v4-header");
        Label desc = new Label(subtitle);
        desc.setWrapText(true);
        desc.getStyleClass().add("cf-settings-v4-hint");
        VBox card = new VBox(9, header, desc);
        card.getChildren().addAll(controls);
        card.setMinWidth(0);
        card.setMaxWidth(Double.MAX_VALUE);
        card.getStyleClass().add("cf-settings-v4-card");
        return card;
    }

    private javafx.scene.control.PasswordField settingsCompactPassword(String hint) {
        javafx.scene.control.PasswordField field = new javafx.scene.control.PasswordField();
        field.setPromptText(hint);
        field.getStyleClass().add("cf-settings-v4-input");
        field.setMaxWidth(Double.MAX_VALUE);
        return field;
    }

    private Node buildCompactAdminSettings() {
        CampusPreferences pref = CampusPreferences.current();
        javafx.scene.control.PasswordField current = settingsCompactPassword("Current password");
        javafx.scene.control.PasswordField newPass = settingsCompactPassword("New password (8+ characters)");
        javafx.scene.control.PasswordField confirm = settingsCompactPassword("Confirm new password");
        Label passwordNote = settingsMessage();
        Button updatePassword = settingsSaveButton("Update Password");
        updatePassword.setMaxWidth(Double.MAX_VALUE);
        updatePassword.setOnAction(e -> {
            String result = UserService.changePassword(CurrentUser.getStudentId(),
                    current.getText(), newPass.getText(), confirm.getText());
            passwordNote.setText(result == null ? "Password updated successfully." : result);
            if (result == null) {
                current.clear(); newPass.clear(); confirm.clear();
                audit(CurrentUser.getName(), "Password changed", "Account security");
            }
        });
        VBox security = settingsOverviewPanel("Account & Security", ICON_SETTINGS,
                "Change your administrator password.",
                current, newPass, confirm, passwordNote, updatePassword);

        javafx.scene.control.CheckBox notify = settingsCheck("Enable notifications", pref.notifications);
        javafx.scene.control.CheckBox claim = settingsCheck("Claim verification updates", pref.claimAlerts);
        javafx.scene.control.CheckBox chats = settingsCheck("New messages", pref.messageAlerts);
        javafx.scene.control.CheckBox matches = settingsCheck("KITA matching suggestions", pref.matchAlerts);
        javafx.scene.control.CheckBox helper = settingsCheck("Show KITA helper", pref.mascot);
        Runnable persist = () -> {
            CampusPreferences saved = CampusPreferences.current();
            saved.notifications = notify.isSelected();
            saved.claimAlerts = claim.isSelected();
            saved.messageAlerts = chats.isSelected();
            saved.matchAlerts = matches.isSelected();
            saved.mascot = helper.isSelected();
            saved.save();
            notifOn = saved.notifications;
            mascotOn = saved.mascot;
            if (fab != null) fab.setVisible(mascotOn && !assistantOpen);
        };
        for (javafx.scene.control.CheckBox check : new javafx.scene.control.CheckBox[]{notify,claim,chats,matches,helper}) {
            check.setOnAction(e -> persist.run());
        }
        Button moreAlerts = settingsMiniLink("More notification options", () -> showSettingsCategory("alerts"));
        VBox notifications = settingsOverviewPanel("Notifications & KITA AI", ICON_BELL,
                "Changes save automatically.", notify, claim, chats, matches, helper, moreAlerts);

        ComboBox<Integer> period = new ComboBox<>();
        period.getItems().addAll(1,3,6,12,24);
        period.setValue(unclaimedMonths);
        period.setMaxWidth(Double.MAX_VALUE);
        period.setDisable(!amMainAdmin());
        Label policyHelp = settingsMessage();
        Button savePolicy = settingsSaveButton("Save Policy");
        savePolicy.setMaxWidth(Double.MAX_VALUE);
        savePolicy.setDisable(!amMainAdmin());
        savePolicy.setOnAction(e -> {
            if (!amMainAdmin()) return;
            unclaimedMonths = period.getValue();
            CampusPreferences.setUnclaimedMonths(unclaimedMonths);
            audit(CurrentUser.getName(), "Unclaimed-item policy updated", unclaimedMonths + " months");
            policyHelp.setText("Saved: " + unclaimedMonths + " months.");
        });
        VBox policy = settingsOverviewPanel("Claim & Item Policies", ICON_CLAIM,
                "Unclaimed-item threshold (main admin only).",
                settingsLabel("Unclaimed period (months)"), period,
                smallGrey("Claim reviews and pickups are managed on the Claims page."),
                policyHelp, savePolicy,
                settingsMiniLink("Open Claims", this::showAdminClaims));

        Button assistants = settingsSaveButton("Manage Assistants");
        assistants.setMaxWidth(Double.MAX_VALUE);
        assistants.setDisable(!amMainAdmin());
        assistants.setOnAction(e -> showUsers());
        VBox staff = settingsOverviewPanel("Assistant Admins", ICON_USERS,
                "" + UserService.assistantCount() + " of " + UserService.getMaxAssistants()
                + " assistant accounts. Main admin only.", assistants);
        Button export = settingsMiniLink("Export Reports CSV", this::exportSettingsReports);
        export.setDisable(!amMainAdmin());
        Button backup = settingsSaveButton("Create Local Backup");
        backup.setMaxWidth(Double.MAX_VALUE);
        backup.setDisable(!amMainAdmin());
        backup.setOnAction(e -> backupSettingsData());
        VBox storage = settingsOverviewPanel("Backup & System Data", ICON_LIST,
                "Export records or save a private local backup.", export, backup);
        VBox sidebar = new VBox(12, staff, storage);
        sidebar.setMinWidth(0);
        HBox columns = new HBox(12, security, notifications, policy, sidebar);
        for (Region node : new Region[]{security, notifications, policy, sidebar}) {
            node.setMinWidth(0);
            node.setMaxWidth(Double.MAX_VALUE);
            HBox.setHgrow(node, Priority.ALWAYS);
        }
        // In a narrow window the same controls remain accessible on a 2-column page.
        javafx.scene.layout.TilePane fallback = new javafx.scene.layout.TilePane();
        fallback.setHgap(12);
        fallback.setVgap(12);
        fallback.setPrefColumns(2);
        StackPane switcher = new StackPane();
        switcher.getChildren().add(columns);
        // JavaFX nodes cannot have two parents. Change ownership only when resizing.
        switcher.widthProperty().addListener((obs, oldWidth, newWidth) -> {
            boolean narrow = newWidth.doubleValue() < 925;
            if (narrow && switcher.getChildren().contains(columns)) {
                columns.getChildren().clear();
                fallback.getChildren().setAll(security, notifications, policy, sidebar);
                switcher.getChildren().setAll(fallback);
            } else if (!narrow && switcher.getChildren().contains(fallback)) {
                fallback.getChildren().clear();
                columns.getChildren().setAll(security, notifications, policy, sidebar);
                switcher.getChildren().setAll(columns);
            }
        });
        // The fallback remains empty until ownership is transferred at the breakpoint.
        return switcher;
    }

    private Button settingsMiniLink(String text, Runnable handler) {
        Button button = new Button(text);
        button.getStyleClass().add("cf-settings-v4-secondary");
        button.setMaxWidth(Double.MAX_VALUE);
        button.setOnAction(e -> handler.run());
        return button;
    }

    private VBox settingsLauncher(String title, String detail, String iconPath,
            String accent, Runnable action) {
        SVGPath ico = svg(iconPath, 27, accent);
        StackPane iconBox = new StackPane(ico);
        iconBox.setPrefSize(54,54);
        iconBox.setMaxSize(54,54);
        iconBox.setStyle("-fx-background-color: " + ("#8b5cf6".equals(accent) ? "#f0e9ff"
                : "#19a768".equals(accent) ? "#dcfce7" : "#e9f1ff")
                + "; -fx-background-radius: 13;");
        Label name = new Label(title);
        name.setWrapText(true);
        name.setStyle("-fx-text-fill: #0c3279; -fx-font-weight: bold; -fx-font-size: 16px;");
        Label hint = new Label(detail);
        hint.setWrapText(true);
        hint.setStyle("-fx-text-fill: #4b668a; -fx-font-size: 12px;");
        VBox copy = new VBox(5,name,hint);
        SVGPath chevron = svg(ICON_BACK, 16, "#1559c8");
        chevron.setRotate(180);
        HBox h = new HBox(13,iconBox,copy,chevron);
        h.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(copy, Priority.ALWAYS);
        VBox tile = new VBox(h);
        tile.getStyleClass().add("cf-settings-v4-launcher");
        tile.setMaxWidth(Double.MAX_VALUE);
        tile.setMinWidth(0);
        tile.setCursor(Cursor.HAND);
        tile.setFocusTraversable(true);
        tile.setOnMouseClicked(e -> action.run());
        tile.setOnKeyPressed(e -> {
            if (e.getCode() == javafx.scene.input.KeyCode.ENTER
                    || e.getCode() == javafx.scene.input.KeyCode.SPACE) action.run();
        });
        return tile;
    }

    private Node buildCompactStudentSettings() {
        UserService.Account acc = UserService.findById(CurrentUser.getStudentId());
        String course = acc == null || acc.program == null || acc.program.isBlank()
                ? "Not specified" : acc.program;
        String year = acc == null || acc.yearLevel < 1 ? "Not specified"
                : acc.yearLevel + (acc.yearLevel == 1 ? "st" : acc.yearLevel == 2 ? "nd"
                : acc.yearLevel == 3 ? "rd" : "th") + " Year";
        Node photo = acc == null ? profileui.avatar(90) : userAvatar(acc, 90);
        Label name = new Label(acc == null ? CurrentUser.getName() : acc.name);
        name.setStyle("-fx-font-size: 21px; -fx-font-weight: bold; -fx-text-fill: #103477;");
        name.setWrapText(true);
        Label id = smallGrey("Student ID: " + CurrentUser.getStudentId());
        VBox identity = new VBox(6, name,id);
        HBox face = new HBox(16,photo,identity);
        face.setAlignment(Pos.CENTER_LEFT);
        VBox profile = settingsOverviewPanel("Profile & Academic Information", ICON_PERSON,
                "Updates are visible to Admin on this computer.", face,
                settingsInfoRow("Program/Course",course),
                settingsInfoRow("Year Level",year),
                settingsInfoRow("Section",acc == null ? "" : acc.section),
                settingsMiniLink("Edit Profile & Photo",()->showSettingsCategory("profile")));
        HBox.setHgrow(profile, Priority.ALWAYS);
        profile.setMinWidth(0);
        VBox notifications = settingsLauncher("Notifications & KITA AI", "Choose alerts and matching suggestions.",
                ICON_BELL, "#da9811", () -> showSettingsCategory("alerts"));
        VBox messenger = settingsLauncher("Messenger Preferences", "Popups, message previews and incoming chats.",
                ICON_CHAT, "#8b5cf6", () -> showSettingsCategory("messenger"));
        VBox privacy = settingsLauncher("Privacy & Security", "Update your password and access account help.",
                ICON_SETTINGS, "#1559c8", () -> showSettingsCategory("security"));
        VBox accessibility = settingsLauncher("Accessibility", "Adjust text size; keep the NORSU colors.",
                ICON_PERSON, "#19a768", () -> showSettingsCategory("access"));
        javafx.scene.layout.GridPane grid = new javafx.scene.layout.GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        for (int i=0;i<2;i++) {
            javafx.scene.layout.ColumnConstraints cc = new javafx.scene.layout.ColumnConstraints();
            cc.setPercentWidth(50);
            cc.setHgrow(Priority.ALWAYS);
            grid.getColumnConstraints().add(cc);
        }
        grid.add(notifications,0,0); grid.add(messenger,1,0);
        grid.add(privacy,0,1); grid.add(accessibility,1,1);
        for (Node item : new Node[]{notifications,messenger,privacy,accessibility}) {
            javafx.scene.layout.GridPane.setHgrow(item,Priority.ALWAYS);
            javafx.scene.layout.GridPane.setFillWidth(item,true);
        }
        HBox layout = new HBox(14,profile,grid);
        layout.setMinWidth(0);
        HBox.setHgrow(grid,Priority.ALWAYS);
        profile.prefWidthProperty().bind(layout.widthProperty().multiply(0.42));
        grid.prefWidthProperty().bind(layout.widthProperty().multiply(0.58).subtract(14));
        return layout;
    }

    // Approved student settings redesign: compact side-by-side profile editor,
    // live academic overview and genuine completion tracking. At desktop size
    // both columns fit without scrolling; small windows retain a safe scrollbar.
    private Node buildStudentProfileSettingsScreen() {
        UserService.Account account = UserService.findById(CurrentUser.getStudentId());
        if (account == null) {
            return pageOf(campusFeatureBanner("Student Settings", "Edit your CampusFind profile"),
                    smallGrey("Your student account could not be found. Please sign in again."));
        }

        TextField fullName = settingsCompactField(account.name, "Full name");
        TextField mail = settingsCompactField(account.email, "Email address");
        TextField phone = settingsCompactField(account.phone == null ? "" : account.phone, "Enter phone number");
        TextField program = settingsCompactField(account.program == null ? "" : account.program, "Your program / course");
        TextField section = settingsCompactField(account.section == null ? "" : account.section, "Enter section");
        ComboBox<Integer> year = new ComboBox<>();
        year.getItems().addAll(1, 2, 3, 4, 5);
        year.setValue(account.yearLevel > 0 ? account.yearLevel : 1);
        year.setMaxWidth(Double.MAX_VALUE);
        year.setPrefHeight(33);
        year.getStyleClass().add("cf-profile-input");
        javafx.scene.control.PasswordField verify = new javafx.scene.control.PasswordField();
        verify.setPromptText("Current password required to change name or email");
        verify.getStyleClass().add("cf-profile-input");
        verify.setMaxWidth(Double.MAX_VALUE);
        verify.setPrefHeight(33);
        VBox passwordRow = new VBox(3, settingsLabel("Confirm identity with your password"), verify);
        passwordRow.setMinWidth(0);
        Runnable watchIdentity = () -> {
            boolean changed = !account.name.equals(fullName.getText().strip())
                    || !account.email.equalsIgnoreCase(mail.getText().strip());
            passwordRow.setManaged(changed);
            passwordRow.setVisible(changed);
            if (!changed) verify.clear();
        };
        fullName.textProperty().addListener((o, a, b) -> watchIdentity.run());
        mail.textProperty().addListener((o, a, b) -> watchIdentity.run());
        watchIdentity.run();

        Label feedback = new Label();
        feedback.getStyleClass().add("cf-profile-feedback");
        feedback.setWrapText(true);
        feedback.setVisible(false);
        feedback.managedProperty().bind(feedback.visibleProperty());
        VBox form = new VBox(7);
        form.setMinWidth(0);
        form.getChildren().addAll(compactProfileField("Full Name", fullName),
                compactProfileField("Email Address", mail),
                compactProfileField("Phone Number (optional)", phone),
                compactProfileField("Program / Course", program));
        VBox yearWrap = compactProfileField("Year Level", year);
        VBox sectionWrap = compactProfileField("Section (optional)", section);
        HBox academicRow = new HBox(10, yearWrap, sectionWrap);
        academicRow.setMinWidth(0);
        HBox.setHgrow(yearWrap, Priority.ALWAYS);
        HBox.setHgrow(sectionWrap, Priority.ALWAYS);
        yearWrap.setMaxWidth(Double.MAX_VALUE);
        sectionWrap.setMaxWidth(Double.MAX_VALUE);
        form.getChildren().addAll(academicRow, passwordRow, feedback);

        StackPane avatar = profileui.avatar(90);
        Label profileName = new Label(account.name);
        profileName.getStyleClass().add("cf-profile-name");
        profileName.setWrapText(true);
        profileName.setMaxWidth(Double.MAX_VALUE);
        Label studentId = new Label("Student ID: " + account.studentId);
        studentId.getStyleClass().add("cf-profile-id");
        Button photoButton = new Button("Change profile photo");
        photoButton.getStyleClass().add("cf-profile-photo-button");
        final Runnable[] refreshAfterPhoto = {() -> { }};
        photoButton.setOnAction(e -> {
            if (selectProfilePhoto(false)) refreshAfterPhoto[0].run();
        });
        VBox identity = new VBox(9, avatar, profileName, studentId, photoButton,
                new Separator(), profileSummaryRow("Program", program.textProperty()),
                profileSummaryRow("Year Level", javafx.beans.binding.Bindings.createStringBinding(
                        () -> ordinalYear(year.getValue()),
                        year.valueProperty())),
                profileSummaryRow("Section", section.textProperty()));
        identity.setAlignment(Pos.TOP_CENTER);
        identity.getStyleClass().add("cf-profile-identity");
        identity.setMinWidth(0);
        profileName.textProperty().bind(fullName.textProperty());

        HBox content = new HBox(16, identity, form);
        content.setMinWidth(0);
        HBox.setHgrow(form, Priority.ALWAYS);
        identity.prefWidthProperty().bind(content.widthProperty().multiply(0.34));
        form.prefWidthProperty().bind(Bindings.createDoubleBinding(
                () -> Math.max(0, content.getWidth() * 0.66 - 16), content.widthProperty()));
        VBox mainCard = new VBox(0, profilePanelHeader("Profile & Academic Information", ICON_PERSON), content);
        content.setPadding(new Insets(14));
        mainCard.getStyleClass().add("cf-profile-panel");
        mainCard.setMinWidth(0);

        Label overviewProgram = new Label();
        overviewProgram.textProperty().bind(Bindings.when(program.textProperty().isEmpty())
                .then("—").otherwise(program.textProperty()));
        Label overviewYear = new Label();
        overviewYear.textProperty().bind(javafx.beans.binding.Bindings.createStringBinding(
                () -> ordinalYear(year.getValue()), year.valueProperty()));
        Label overviewSection = new Label();
        overviewSection.textProperty().bind(Bindings.when(section.textProperty().isEmpty())
                .then("—").otherwise(section.textProperty()));
        HBox overviewTiles = new HBox(9,
                academicTile("Program", overviewProgram, "#deedff", "#1463c8"),
                academicTile("Year Level", overviewYear, "#fff2d2", "#ae7600"),
                academicTile("Section", overviewSection, "#eee9ff", "#7046c1"));
        for (Node tile : overviewTiles.getChildren()) HBox.setHgrow(tile, Priority.ALWAYS);
        VBox academic = new VBox(12, profilePanelHeader("Academic Overview", ICON_DASH), overviewTiles);
        academic.getStyleClass().add("cf-profile-panel");
        academic.setMinWidth(0);
        overviewTiles.setPadding(new Insets(2, 13, 13, 13));

        Label completionPercent = new Label();
        completionPercent.getStyleClass().add("cf-profile-percent");
        javafx.scene.control.ProgressBar completionBar = new javafx.scene.control.ProgressBar();
        completionBar.setMaxWidth(Double.MAX_VALUE);
        completionBar.getStyleClass().add("cf-profile-progress");
        Label nameCheck = new Label(), emailCheck = new Label(), acadCheck = new Label();
        Label phoneCheck = new Label(), photoCheck = new Label();
        for (Label item : new Label[]{nameCheck,emailCheck,acadCheck,phoneCheck,photoCheck}) {
            item.getStyleClass().add("cf-profile-check");
        }
        Runnable updateCompletion = () -> {
            boolean hasName = !fullName.getText().isBlank();
            boolean hasEmail = mail.getText().matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+");
            boolean hasAcademic = !program.getText().isBlank() && year.getValue() != null;
            boolean hasPhone = !phone.getText().isBlank();
            boolean hasPhoto = CurrentUser.getPhoto() != null;
            int done = (hasName ? 1 : 0) + (hasEmail ? 1 : 0)
                    + (hasAcademic ? 1 : 0) + (hasPhone ? 1 : 0) + (hasPhoto ? 1 : 0);
            int pct = done * 20;
            completionPercent.setText(pct + "%");
            completionBar.setProgress(done / 5.0);
            nameCheck.setText((hasName ? "✓ " : "○ ") + "Personal information");
            emailCheck.setText((hasEmail ? "✓ " : "○ ") + "Email address");
            acadCheck.setText((hasAcademic ? "✓ " : "○ ") + "Academic information");
            phoneCheck.setText((hasPhone ? "✓ " : "○ ") + "Phone number (optional)");
            photoCheck.setText((hasPhoto ? "✓ " : "○ ") + "Profile photo (optional)");
        };
        for (TextField field : new TextField[]{fullName,mail,phone,program,section}) {
            field.textProperty().addListener((o,a,b) -> updateCompletion.run());
        }
        year.valueProperty().addListener((o,a,b) -> updateCompletion.run());
        updateCompletion.run();
        refreshAfterPhoto[0] = updateCompletion;
        HBox completionHead = new HBox(8, new Label("Profile Completeness"), new Region(), completionPercent);
        ((Label) completionHead.getChildren().getFirst()).getStyleClass().add("cf-profile-completion-title");
        HBox.setHgrow(completionHead.getChildren().get(1), Priority.ALWAYS);
        Button openPreferences = new Button("Notifications, Privacy & Preferences");
        openPreferences.getStyleClass().add("cf-profile-secondary");
        openPreferences.setMaxWidth(Double.MAX_VALUE);
        openPreferences.setOnAction(e -> openScreen(buildSettingsScreen(), settingsNav, false, false));
        VBox completeness = new VBox(10, completionHead, completionBar,
                nameCheck, emailCheck, acadCheck, phoneCheck, photoCheck, openPreferences);
        completeness.getStyleClass().add("cf-profile-panel");
        completeness.setPadding(new Insets(17));
        VBox right = new VBox(14, academic, completeness);
        right.setMinWidth(0);
        Node cards = dashboardGrid(950, new double[]{60, 40}, mainCard, right);

        Button reset = new Button("↻  Reset");
        reset.getStyleClass().add("cf-profile-reset");
        reset.setOnAction(e -> {
            fullName.setText(account.name);
            mail.setText(account.email);
            phone.setText(account.phone == null ? "" : account.phone);
            program.setText(account.program == null ? "" : account.program);
            section.setText(account.section == null ? "" : account.section);
            year.setValue(account.yearLevel > 0 ? account.yearLevel : 1);
            verify.clear();
            feedback.setVisible(false);
        });
        Button save = new Button("✓  Save Changes");
        save.getStyleClass().add("cf-profile-save");
        save.setOnAction(e -> {
            String oldName = account.name;
            if ((!oldName.equals(fullName.getText().strip())
                    || !account.email.equalsIgnoreCase(mail.getText().strip()))
                    && !UserService.verifyPassword(account.studentId, verify.getText())) {
                feedback.setText("Enter your current password to change your name or email.");
                feedback.setVisible(true);
                return;
            }
            String result = UserService.updateStudent(account.studentId, fullName.getText(), mail.getText(),
                    phone.getText(), program.getText(), year.getValue(), section.getText());
            if (result != null) { feedback.setText(result); feedback.setVisible(true); return; }
            if (!oldName.equals(account.name)) renameStudentReferences(oldName, account.name);
            CurrentUser.updateIdentity(account.name, account.email);
            audit(account.name, "Student profile updated", "Student ID: " + account.studentId);
            popup("Profile saved", wrapLabel("Your changes were saved locally and are visible in Admin > Manage Users."));
            showSettings();
        });
        HBox actions = new HBox(10, reset, save);
        actions.setAlignment(Pos.CENTER_RIGHT);
        actions.setPadding(new Insets(10, 14, 12, 14));
        mainCard.getChildren().add(actions);

        StackPane banner = (StackPane) campusFeatureBanner("Edit Profile & Academic Information",
                "Update your personal details, academic information and preferences.");
        banner.setMinHeight(98); banner.setPrefHeight(108); banner.setMaxHeight(116);
        VBox contentPage = new VBox(12, banner, cards);
        contentPage.getStyleClass().add("cf-profile-editor");
        return pageOf(1500, contentPage);
    }

    private TextField settingsCompactField(String value, String hint) {
        TextField field = new TextField(value);
        field.setPromptText(hint);
        field.getStyleClass().add("cf-profile-input");
        field.setMaxWidth(Double.MAX_VALUE);
        field.setPrefHeight(33);
        return field;
    }

    private VBox compactProfileField(String label, Node control) {
        VBox result = new VBox(3, settingsLabel(label), control);
        result.setMinWidth(0);
        return result;
    }

    private HBox profilePanelHeader(String title, String iconName) {
        Label label = new Label(title);
        label.getStyleClass().add("cf-profile-panel-title");
        HBox header = new HBox(9, new Group(svg(iconName, 19, "#ffca23")), label);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("cf-profile-panel-heading");
        return header;
    }

    private HBox profileSummaryRow(String title, javafx.beans.value.ObservableValue<String> value) {
        Label key = new Label(title);
        key.getStyleClass().add("cf-profile-summary-key");
        Label display = new Label();
        display.getStyleClass().add("cf-profile-summary-value");
        display.textProperty().bind(value);
        display.setWrapText(true);
        HBox row = new HBox(7, key, display);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    private VBox academicTile(String title, Label value, String background, String textColor) {
        Label label = new Label(title);
        label.setStyle("-fx-text-fill: #31517c; -fx-font-size: 11px;");
        value.setStyle("-fx-text-fill: " + textColor + "; -fx-font-size: 16px; -fx-font-weight: bold;");
        value.setWrapText(true);
        VBox tile = new VBox(6, value, label);
        tile.setAlignment(Pos.CENTER);
        tile.setMinWidth(0);
        tile.setPrefHeight(95);
        tile.setMaxWidth(Double.MAX_VALUE);
        tile.setStyle("-fx-background-color: " + background + "; -fx-background-radius: 13; -fx-padding: 12 6;");
        return tile;
    }

    private static String ordinalYear(Integer year) {
        if (year == null) return "—";
        return year + switch (year) {
            case 1 -> "st Year";
            case 2 -> "nd Year";
            case 3 -> "rd Year";
            default -> "th Year";
        };
    }

    private Node buildSettingsEditorScreen(String category) {
        if (!admin && "profile".equals(category)) return buildStudentProfileSettingsScreen();
        CampusPreferences initial = CampusPreferences.current();
        VBox intro = new VBox(3, pageTitle(admin ? "Admin Settings" : "Student Settings"),
                smallGrey(admin ? "Manage campus policies, access, notifications and data." :
                        "Manage your personal information, notifications, privacy and messages."));
        intro.setPadding(new Insets(3, 0, 3, 0));
        FlowPane cards = new FlowPane(12, 12);
        cards.setPrefWrapLength(1050);
        cards.setMinWidth(0);
        javafx.scene.control.CheckBox allAlerts = settingsCheck("Enable notifications", initial.notifications);
        javafx.scene.control.CheckBox claimAlerts = settingsCheck("Claim status and verification updates", initial.claimAlerts);
        javafx.scene.control.CheckBox messageAlerts = settingsCheck("New messages and unread chats", initial.messageAlerts);
        javafx.scene.control.CheckBox matchAlerts = settingsCheck("KITA matching suggestions", initial.matchAlerts);
        javafx.scene.control.CheckBox mascot = settingsCheck("Show KITA helper in the header", initial.mascot);
        javafx.scene.control.CheckBox suggestions = settingsCheck("Show KITA match suggestions", initial.aiSuggestions);
        VBox notifications = settingsCard("Notifications & KITA AI", "Choose the alerts and assistant elements you want to see.",
                allAlerts, claimAlerts, messageAlerts, matchAlerts, mascot, suggestions);
        if ("alerts".equals(category)) cards.getChildren().add(notifications);

        javafx.scene.control.CheckBox popups = settingsCheck("Show a popup for unread messages on login", initial.showMessagePopup);
        javafx.scene.control.CheckBox previews = settingsCheck("Include a message preview in popups", initial.showMessagePreview);
        javafx.scene.control.CheckBox autoOpen = settingsCheck("Automatically open an unread conversation on login", initial.openUnreadOnLogin);
        javafx.scene.control.CheckBox largerText = settingsCheck("Larger interface text", initial.largeText);
        if (!admin && "messenger".equals(category)) {
            cards.getChildren().add(settingsCard("Messenger Preferences", "Incoming messages from other computers require a shared backend.",
                    popups, previews, autoOpen));
        }
        if ("access".equals(category)) cards.getChildren().add(settingsCard("Accessibility", "The campus color scheme stays blue, white and yellow.", largerText,
                smallGrey("Use Windows display scaling for additional enlargement.")));

        final javafx.scene.control.PasswordField old = new javafx.scene.control.PasswordField();
        final javafx.scene.control.PasswordField next = new javafx.scene.control.PasswordField();
        final javafx.scene.control.PasswordField confirm = new javafx.scene.control.PasswordField();
        old.setPromptText("Current password");
        next.setPromptText("At least 8 characters");
        confirm.setPromptText("Repeat new password");
        Label passFeedback = settingsMessage();
        Button changePass = new Button("Change Password");
        changePass.setStyle(smallSolidBtn());
        changePass.setOnAction(e -> {
            String result = UserService.changePassword(CurrentUser.getStudentId(), old.getText(),
                    next.getText(), confirm.getText());
            passFeedback.setText(result == null ? "Password changed successfully." : result);
            if (result == null) {
                old.clear(); next.clear(); confirm.clear();
                audit(CurrentUser.getName(), "Password changed", "Account security");
            }
        });
        if ("security".equals(category)) cards.getChildren().add(settingsCard("Account & Security", "Your current password is required before changing it.",
                settingsField("Current Password", old), settingsField("New Password", next),
                settingsField("Confirm New Password", confirm), passFeedback, changePass));

        if (admin) {
            ComboBox<Integer> unclaimed = new ComboBox<>();
            unclaimed.getItems().addAll(1, 3, 6, 12, 24);
            unclaimed.setValue(unclaimedMonths);
            unclaimed.setMaxWidth(Double.MAX_VALUE);
            unclaimed.setDisable(!amMainAdmin());
            Label adminMessage = settingsMessage();
            Button policySave = settingsSaveButton("Save Unclaimed-Item Policy");
            policySave.setDisable(!amMainAdmin());
            policySave.setOnAction(e -> {
                if (!amMainAdmin()) return;
                unclaimedMonths = unclaimed.getValue();
                CampusPreferences.setUnclaimedMonths(unclaimedMonths);
                audit(CurrentUser.getName(), "Unclaimed-item policy updated", unclaimedMonths + " months");
                adminMessage.setText("Policy saved: " + unclaimedMonths + " months.");
            });
            if ("policy".equals(category)) cards.getChildren().add(settingsCard("Claim & Item Policies", "Main admin only; this changes the existing overdue-item rule.",
                    settingsField("Unclaimed item period (months)", unclaimed), adminMessage, policySave));

            Button manageAssistants = new Button("Manage Assistant Admins");
            manageAssistants.setStyle(smallSolidBtn());
            manageAssistants.setDisable(!amMainAdmin());
            manageAssistants.setOnAction(e -> showUsers());
            if ("admins".equals(category)) cards.getChildren().add(settingsCard("Assistant Admin Permissions", "Only the main admin can add or remove assistant accounts."
                    + " Separate per-permission roles are not yet available in this local application.",
                    smallGrey("Current assistants: " + UserService.assistantCount() + " / " + UserService.getMaxAssistants()),
                    manageAssistants));

            Button export = new Button("Export Reports CSV");
            export.setStyle(smallBtn());
            export.setDisable(!amMainAdmin());
            export.setOnAction(e -> exportSettingsReports());
            Button backup = new Button("Create Local Backup");
            backup.setStyle(smallSolidBtn());
            backup.setDisable(!amMainAdmin());
            backup.setOnAction(e -> backupSettingsData());
            if ("backup".equals(category)) cards.getChildren().add(settingsCard("Data & Backup", "Backups include private records. Save them in a secure folder."
                    + " No cloud synchronization is enabled.", export, backup));
            Button logs = new Button("Open Audit Logs");
            logs.setStyle(smallBtn());
            logs.setOnAction(e -> showAudit());
            if ("audit".equals(category)) cards.getChildren().add(settingsCard("Help & Audit", "Review administrator actions and system history.", logs,
                    smallGrey("Two-factor login and automatic cloud backups would require additional services.")));
        } else {
            Button myClaims = new Button("View My Claims");
            myClaims.setStyle(smallBtn());
            myClaims.setOnAction(e -> showClaims());
            Button messagesButton = new Button("Open Messenger");
            messagesButton.setStyle(smallBtn());
            messagesButton.setOnAction(e -> showMessages());
            if ("security".equals(category)) cards.getChildren().add(settingsCard("Privacy & Help", "Your email and phone are shown to authorized administrators,"
                    + " not in public item cards.", myClaims, messagesButton));
        }
        Button savePrefs = settingsSaveButton("Save Preferences");
        savePrefs.setOnAction(e -> {
            CampusPreferences pref = CampusPreferences.current();
            pref.notifications = allAlerts.isSelected();
            pref.claimAlerts = claimAlerts.isSelected();
            pref.messageAlerts = messageAlerts.isSelected();
            pref.matchAlerts = matchAlerts.isSelected();
            pref.mascot = mascot.isSelected();
            pref.aiSuggestions = suggestions.isSelected();
            pref.showMessagePopup = popups.isSelected();
            pref.showMessagePreview = previews.isSelected();
            pref.openUnreadOnLogin = autoOpen.isSelected();
            pref.largeText = largerText.isSelected();
            pref.save();
            notifOn = pref.notifications;
            mascotOn = pref.mascot;
            aiSuggestOn = pref.aiSuggestions;
            root.setStyle("-fx-background-color: " + BG + "; -fx-font-size: " + (pref.largeText ? 15 : 13) + "px;");
            if (fab != null) fab.setVisible(mascotOn && !assistantOpen);
            popup("Preferences saved", wrapLabel("Your settings have been saved on this computer."));
        });
        Button cancel = new Button("Cancel");
        cancel.setStyle(outlineBtn());
        // Back returns without saving unsaved preference changes.
        cancel.setText("Back to Settings");
        cancel.setOnAction(e -> showSettings());
        boolean preferencesPage = "alerts".equals(category) || "messenger".equals(category)
                || "access".equals(category);
        HBox buttons = new HBox(10);
        if (preferencesPage) buttons.getChildren().add(savePrefs);
        buttons.getChildren().add(cancel);
        buttons.setAlignment(Pos.CENTER_RIGHT);
        String title = settingsCategoryTitle(category);
        Label context = smallGrey("Changes to your account and preferences are saved on this computer.");
        VBox content = new VBox(13, campusFeatureBanner(title,
                admin ? "CampusFind administration settings" : "Your CampusFind account settings"),
                context, cards, buttons);
        return pageOf(930, content);
    }

    private Label settingsMessage() {
        Label message = new Label();
        message.setWrapText(true);
        message.setStyle("-fx-text-fill: #b42340; -fx-font-size: 12px;");
        return message;
    }

    private void selectProfilePhoto() { selectProfilePhoto(true); }

    private boolean selectProfilePhoto(boolean reloadEditor) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Choose Profile Picture");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg"));
        File selected = chooser.showOpenDialog(root.getScene().getWindow());
        if (selected == null) return false;
        if (selected.length() > 5_000_000L) {
            popup("Photo too large", wrapLabel("Choose an image smaller than 5 MB."));
            return false;
        }
        try {
            String saved = CampusLocalStore.keepPhoto(selected);
            CurrentUser.setPhoto(new Image(saved, 512, 512, true, true));
            audit(CurrentUser.getName(), "Profile photo updated", "Account profile");
            if (reloadEditor) showSettingsCategory("profile");
            return true;
        } catch (java.io.IOException exception) {
            popup("Photo not saved", wrapLabel(exception.getMessage()));
            return false;
        }
    }

    /** Existing item/claim/message records identify people by display name. Keep references consistent. */
    private static void renameStudentReferences(String before, String after) {
        if (before.equals(after)) return;
        for (Item item : items) if (item.reporter.equalsIgnoreCase(before)) item.reporter = after;
        for (Claim claim : claims) if (claim.claimant.equalsIgnoreCase(before)) claim.claimant = after;
        for (Message msg : messages) {
            if (msg.from.equalsIgnoreCase(before)) msg.from = after;
            if (msg.to.equalsIgnoreCase(before)) msg.to = after;
            if (msg.inquirer.equalsIgnoreCase(before)) msg.inquirer = after;
        }
        String former = before.toLowerCase();
        String newKey = after.toLowerCase();
        String user = users.remove(former);
        if (user != null) users.put(newKey, after);
        LocalDateTime since = userSince.remove(former);
        if (since != null) userSince.put(newKey, since);
        saveState();
    }

    /** Admin-only account profile; displays the saved identity and profile photo. */
    private void showAdminStudentProfile(UserService.Account acc) {
        if (!admin || acc == null) return;
        Stage dialog = new Stage();
        dialog.initOwner(root.getScene().getWindow());
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.setTitle("Student Profile — " + acc.name);
        Node picture = userAvatar(acc, 96);
        Label name = new Label(acc.name);
        name.setStyle("-fx-text-fill: #0c347a; -fx-font-size: 23px; -fx-font-weight: bold;");
        Label id = smallGrey("Student ID: " + acc.studentId);
        VBox title = new VBox(6, name, id);
        title.setAlignment(Pos.CENTER_LEFT);
        HBox header = new HBox(16, picture, title);
        header.setAlignment(Pos.CENTER_LEFT);
        VBox fields = new VBox(6,
                settingsInfoRow("Full Name", acc.name),
                settingsInfoRow("Email", acc.email),
                settingsInfoRow("Phone", acc.phone == null ? "" : acc.phone),
                settingsInfoRow("Program / Course", acc.program == null ? "" : acc.program),
                settingsInfoRow("Year Level", acc.yearLevel > 0 ? "Year " + acc.yearLevel : "Not specified"),
                settingsInfoRow("Section", acc.section == null ? "" : acc.section));
        int reports = 0, claimCount = 0;
        for (Item item : items) if (item.reporter.equalsIgnoreCase(acc.name)) reports++;
        for (Claim claim : claims) if (claim.accountId.equalsIgnoreCase(acc.studentId)) claimCount++;
        Label activity = settingsLabel("Reports: " + reports + "     Claims: " + claimCount);
        Label updated = smallGrey("Updated: " + (acc.updated == null ? "Not recorded"
                : acc.updated.format(DateTimeFormatter.ofPattern("MMM d, yyyy h:mm a"))));
        Button close = settingsSaveButton("Close Profile");
        close.setOnAction(e -> dialog.close());
        VBox content = new VBox(13, header, new Separator(), settingsLabel("Profile & Academic Details"),
                fields, activity, updated, close);
        content.setPadding(new Insets(22));
        content.setStyle("-fx-background-color: #ffffff; -fx-background-radius: 16;");
        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #f0f5ff;");
        Scene scene = new Scene(scroll, 570, 630);
        CampusStyle.install(scroll);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private HBox settingsInfoRow(String caption, String value) {
        Label key = settingsLabel(caption);
        key.setMinWidth(125);
        Label text = new Label(value == null || value.isBlank() ? "Not provided" : value);
        text.setWrapText(true);
        text.setStyle("-fx-text-fill: #214478; -fx-font-size: 13px;");
        HBox row = new HBox(12, key, text);
        HBox.setHgrow(text, Priority.ALWAYS);
        row.setMinWidth(0);
        row.setPadding(new Insets(10, 12, 10, 12));
        row.setStyle("-fx-background-color: #f0f5ff; -fx-background-radius: 9;");
        return row;
    }

    private Node userAvatar(UserService.Account acc, double size) {
        if (acc.photoUri != null && !acc.photoUri.isBlank()) {
            try {
                Image image = new Image(acc.photoUri, size, size, true, true, false);
                ImageView view = new ImageView(image);
                view.setFitHeight(size); view.setFitWidth(size); view.setPreserveRatio(false);
                view.setClip(new Circle(size / 2, size / 2, size / 2));
                StackPane wrapper = new StackPane(view);
                wrapper.setMinSize(size, size);
                wrapper.setPrefSize(size, size);
                wrapper.setMaxSize(size, size);
                wrapper.setStyle("-fx-background-color: #e5efff; -fx-background-radius: 60;");
                return wrapper;
            } catch (RuntimeException ignored) { }
        }
        return smallAvatar(acc.name, size);
    }

    private void exportSettingsReports() {
        if (!amMainAdmin()) return;
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Export Reports CSV");
        chooser.setInitialFileName("campusfind-reports.csv");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV", "*.csv"));
        File target = chooser.showSaveDialog(root.getScene().getWindow());
        if (target == null) return;
        try (java.io.Writer writer = java.nio.file.Files.newBufferedWriter(target.toPath(),
                java.nio.charset.StandardCharsets.UTF_8)) {
            writer.write("Type,Title,Category,Location,Status,ReportedBy,Date\\n".replace("\\n", "\n"));
            for (Item item : items) {
                String[] values = {item.type, item.title, item.category, item.location,
                        statusOf(item), item.reporter, String.valueOf(item.date)};
                writer.write(java.util.Arrays.stream(values).map(this::csvSafe).collect(java.util.stream.Collectors.joining(",")));
                writer.write("\n");
            }
            popup("Export complete", wrapLabel("Reports CSV created at " + target.getAbsolutePath()));
        } catch (java.io.IOException ex) {
            popup("Export failed", wrapLabel(ex.getMessage()));
        }
    }

    private String csvSafe(String value) {
        String safe = value == null ? "" : value.replaceAll("^[=+@\\-\\t\\r]+", "'");
        return "\"" + safe.replace("\"", "\"\"") + "\"";
    }

    private void backupSettingsData() {
        if (!amMainAdmin()) return;
        javafx.stage.DirectoryChooser chooser = new javafx.stage.DirectoryChooser();
        chooser.setTitle("Choose a private folder for the CampusFind backup");
        File folder = chooser.showDialog(root.getScene().getWindow());
        if (folder == null) return;
        try {
            java.nio.file.Path destination = CampusLocalStore.backupTo(folder.toPath());
            audit(CurrentUser.getName(), "Local backup created", destination.getFileName().toString());
            popup("Local backup saved", wrapLabel("Backup created at " + destination + ". Keep it private; it contains account and report records."));
        } catch (java.io.IOException ex) {
            popup("Backup failed", wrapLabel(ex.getMessage()));
        }
    }

    // =====================================================
    // PROFILE
    // =====================================================
    private Node buildProfileScreen() {
        String me = CurrentUser.getName();

        StackPane avatar = profileui.avatar(60);
        Label name = new Label();
        name.textProperty().bind(CurrentUser.nameProperty());
        name.setWrapText(true);
        name.setStyle("-fx-font-size: 19px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label role = new Label(admin ? "Admin" : "Student");
        role.setStyle("-fx-background-color: " + soft(Theme.BLUE) + "; -fx-text-fill: " + Theme.BLUE + "; "
                + "-fx-font-weight: bold; -fx-background-radius: 14; -fx-padding: 3 14 3 14;");
        if (!admin) {
            for (UserService.Account account : UserService.accounts()) {
                if (account.studentId.equalsIgnoreCase(CurrentUser.getStudentId())) {
                    String course = account.program == null || account.program.isBlank() ? "Student" : account.program;
                    if (account.yearLevel > 0) course += " · " + account.yearLevel
                            + (account.yearLevel == 1 ? "st" : account.yearLevel == 2 ? "nd"
                                    : account.yearLevel == 3 ? "rd" : "th") + " Year";
                    role.setText(course);
                    role.setWrapText(true);
                    break;
                }
            }
        }

        Button editAccount = new Button("Edit Profile");
        editAccount.setStyle("-fx-background-color: #ffca23; -fx-text-fill: #102d70; -fx-font-weight: bold; -fx-background-radius: 10; -fx-padding: 9 15;");
        editAccount.setOnAction(e -> showSettingsCategory("profile"));
        Button change = new Button("Change profile picture");
        change.setStyle(outlineBtn());
        change.setOnAction(e -> profileui.openProfile(root.getScene().getWindow()));

        VBox who = new VBox(6, name, role, change);
        if (!admin) who.getChildren().add(editAccount);
        who.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(who, Priority.ALWAYS);
        HBox head = new HBox(16, avatar, who);
        head.setAlignment(Pos.CENTER_LEFT);
        head.setPadding(new Insets(6));
        head.setStyle("-fx-background-color: transparent;");

        int reports = 0, recovered = 0, myClaims = 0;
        for (Item it : items) {
            if (it.reporter.equalsIgnoreCase(me)) {
                reports++;
                if (it.claimed) recovered++;
            }
        }
        for (Claim c : claims) {
            if (c.accountId.equalsIgnoreCase(CurrentUser.getStudentId())) myClaims++;
        }
        HBox stats = new HBox(14,
                profileStat(admin ? "All reports" : "My reports", admin ? items.size() : reports),
                profileStat(admin ? "Claim requests" : "My claims", admin ? claims.size() : myClaims),
                profileStat("Recovered", admin ? countRecovered() : recovered));

        VBox prefs = new VBox(0,
                prefRow("Notifications", "Show a popup when KITA finds a possible match",
                        toggle(notifOn, v -> { notifOn = v; CampusPreferences cp = CampusPreferences.current(); cp.notifications = v; cp.save(); })),
                new Separator(),
                prefRow("Show KITA mascot", "Show the KITA helper in the header",
                        toggle(mascotOn, v -> {
                            mascotOn = v;
                            CampusPreferences cp = CampusPreferences.current(); cp.mascot = v; cp.save();
                            if (fab != null) fab.setVisible(mascotOn && !assistantOpen);
                        })),
                new Separator(),
                prefRow("AI match suggestions", "Show possible matches inside items",
                        toggle(aiSuggestOn, v -> { aiSuggestOn = v; CampusPreferences cp = CampusPreferences.current(); cp.aiSuggestions = v; cp.save(); })));
        prefs.setStyle(CARD);

        VBox identity = new VBox(10, head, new Separator(), stats);
        identity.setPadding(new Insets(16)); identity.setStyle(CARD);
        identity.getStyleClass().add("cf-v2-profile-identity");
        if (!admin) {
            for (UserService.Account account : UserService.accounts()) {
                if (!account.studentId.equalsIgnoreCase(CurrentUser.getStudentId())) continue;
                String program = account.program == null || account.program.isBlank()
                        ? "Not specified" : account.program;
                String level = account.yearLevel > 0 ? "Year " + account.yearLevel : "Not specified";
                Label infoHeading = new Label("Academic Information");
                infoHeading.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #0d367a;");
                FlowPane metadata = new FlowPane(12, 12,
                        profileAcademicInfo("Student ID", account.studentId),
                        profileAcademicInfo("Program / Course", program),
                        profileAcademicInfo("Year Level", level));
                metadata.setPrefWrapLength(760);
                metadata.setMinWidth(0);
                identity.getChildren().addAll(new Separator(), infoHeading, metadata);
                break;
            }
        }
        for (Node stat : stats.getChildren()) ((Region) stat).setStyle("-fx-background-color: transparent;");
        VBox preferences = new VBox(8, sectionTitle("Preferences"), prefs);
        preferences.setPadding(new Insets(12)); preferences.setStyle(CARD);
        prefs.setStyle("-fx-background-color: transparent;");
        VBox leftCol = new VBox(12, identity, preferences);
        return pageOf(pageTitle(admin ? "Settings" : "Profile"), leftCol);
    }

    private VBox profileAcademicInfo(String caption, String value) {
        Label key = new Label(caption);
        key.setStyle("-fx-text-fill: #62799b; -fx-font-size: 11px;");
        Label text = new Label(value == null || value.isBlank() ? "Not specified" : value);
        text.setWrapText(true);
        text.setStyle("-fx-text-fill: #0d3479; -fx-font-weight: bold; -fx-font-size: 12px;");
        VBox column = new VBox(4, key, text);
        column.setMinWidth(155);
        column.setPrefWidth(210);
        column.setMaxWidth(265);
        column.setPadding(new Insets(11));
        column.getStyleClass().add("cf-v2-profile-detail");
        HBox.setHgrow(column, Priority.ALWAYS);
        return column;
    }

    private int countRecovered() {
        int n = 0;
        for (Item it : items) {
            if (it.claimed) n++;
        }
        return n;
    }

    private VBox profileStat(String caption, int value) {
        Label v = new Label(String.valueOf(value));
        v.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label c = new Label(caption);
        c.setStyle("-fx-text-fill: " + GREY_TEXT + ";");
        VBox box = new VBox(2, v, c);
        box.setPadding(new Insets(8, 12, 8, 12));
        box.setStyle(CARD);
        box.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(box, Priority.ALWAYS);
        return box;
    }

    private HBox prefRow(String title, String subtitle, Node control) {
        Label t = new Label(title);
        t.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: " + DARK + ";");
        Label s = new Label(subtitle);
        s.setWrapText(true);
        s.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        VBox text = new VBox(2, t, s);
        HBox.setHgrow(text, Priority.ALWAYS);
        HBox row = new HBox(12, text, control);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(6, 14, 6, 14));
        return row;
    }

    // =====================================================
    // ROUND AI ICON
    // =====================================================
    private StackPane aiIcon(double size) {
        LinearGradient grad = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE,
                new Stop(0.0, Color.web("#062a72")),
                new Stop(0.5, Color.web("#1559c8")),
                new Stop(1.0, Color.web("#a76b00")));

        Circle c = new Circle(size / 2);
        c.setFill(grad);

        Pane art = new Pane();
        art.setMinSize(size, size);
        art.setPrefSize(size, size);
        art.setMaxSize(size, size);
        addKitaLogo(art, size / 100.0);

        StackPane p = new StackPane(c, art);
        p.setMinSize(size, size);
        p.setPrefSize(size, size);
        p.setMaxSize(size, size);
        return p;
    }

    private void addKitaLogo(Pane art, double s) {
        Color cyan = Color.web("#dac67f");
        Color visorColor = Color.web("#062a72");

        double tipX = 50 * s;
        double tipY = 14 * s;
        for (double radius : new double[]{8, 14}) {
            Arc right = new Arc(tipX, tipY, radius * s, radius * s, -40, 80);
            Arc left = new Arc(tipX, tipY, radius * s, radius * s, 140, 80);
            for (Arc wave : new Arc[]{right, left}) {
                wave.setType(ArcType.OPEN);
                wave.setFill(null);
                wave.setStroke(Color.WHITE);
                wave.setStrokeWidth(2.2 * s);
                wave.setStrokeLineCap(StrokeLineCap.ROUND);
                art.getChildren().add(wave);
            }
        }

        Line stem = new Line(50 * s, 18 * s, 50 * s, 26 * s);
        stem.setStroke(Color.WHITE);
        stem.setStrokeWidth(3 * s);
        Circle tip = new Circle(tipX, tipY, 3.8 * s, Color.web("#fde047"));

        Rectangle earL = new Rectangle(17 * s, 39 * s, 7 * s, 14 * s);
        Rectangle earR = new Rectangle(76 * s, 39 * s, 7 * s, 14 * s);
        for (Rectangle ear : new Rectangle[]{earL, earR}) {
            ear.setArcWidth(5 * s);
            ear.setArcHeight(5 * s);
            ear.setFill(cyan);
        }

        Polygon pointer = new Polygon(
                41 * s, 62 * s,
                59 * s, 62 * s,
                50 * s, 79 * s);
        pointer.setFill(Color.WHITE);

        Rectangle head = new Rectangle(24 * s, 25 * s, 52 * s, 40 * s);
        head.setArcWidth(20 * s);
        head.setArcHeight(20 * s);
        head.setFill(Color.WHITE);

        Rectangle visor = new Rectangle(31 * s, 34 * s, 38 * s, 22 * s);
        visor.setArcWidth(13 * s);
        visor.setArcHeight(13 * s);
        visor.setFill(visorColor);

        Circle eyeL = new Circle(42 * s, 45 * s, 5 * s, cyan);
        Circle eyeR = new Circle(58 * s, 45 * s, 5 * s, cyan);
        Circle shineL = new Circle(43.6 * s, 43.4 * s, 1.5 * s, Color.WHITE);
        Circle shineR = new Circle(59.6 * s, 43.4 * s, 1.5 * s, Color.WHITE);

        Path star = sparkle(85 * s, 27 * s, 6.5 * s);
        star.setFill(Color.web("#fde047"));

        art.getChildren().addAll(stem, tip, earL, earR, pointer, head, visor,
                eyeL, eyeR, shineL, shineR, star);
    }

    private Path sparkle(double cx, double cy, double r) {
        Path p = new Path();
        p.getElements().addAll(
                new MoveTo(cx, cy - r),
                new QuadCurveTo(cx, cy, cx + r, cy),
                new QuadCurveTo(cx, cy, cx, cy + r),
                new QuadCurveTo(cx, cy, cx - r, cy),
                new QuadCurveTo(cx, cy, cx, cy - r),
                new ClosePath());
        p.setFill(Color.WHITE);
        p.setStroke(null);
        return p;
    }

    // floating round AI button (above the bottom navigation)
    private StackPane buildFab() {
        int size = 36;
        StackPane f = new StackPane(aiIcon(size - 8));
        f.setMinSize(size, size);
        f.setPrefSize(size, size);
        f.setMaxSize(size, size);
        f.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 30;");
        f.setEffect(new DropShadow(14, Color.rgb(0, 0, 0, 0.30)));
        f.setCursor(Cursor.HAND);
        f.setOnMouseEntered(e -> {
            f.setScaleX(1.08);
            f.setScaleY(1.08);
        });
        f.setOnMouseExited(e -> {
            f.setScaleX(1.0);
            f.setScaleY(1.0);
        });
        f.setOnMouseClicked(e -> showAssistant());
        Tooltip.install(f, new Tooltip("Ask KITA AI"));

        StackPane.setAlignment(f, Pos.BOTTOM_RIGHT);
        
        return f;
    }

    // =====================================================
    // SHARED ADMIN HELPERS
    // =====================================================
    private Label sectionTitle(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("section-heading");
        return l;
    }

    private Label emptyLine(String text) {
        Label l = new Label(text);
        l.setWrapText(true);
        l.setStyle("-fx-text-fill: " + GREY_TEXT + ";");
        return l;
    }

    private Label wrapLabel(String text) {
        Label l = new Label(text);
        l.setWrapText(true);
        l.setStyle("-fx-text-fill: -cf-ink;");
        return l;
    }

    private Node buildReportsTab(String type) {
        VBox list = new VBox(8);
        int n = 0;
        for (int i = items.size() - 1; i >= 0; i--) {
            Item it = items.get(i);
            if (!it.type.equals(type)) continue;
            list.getChildren().add(buildAdminRow(it));
            n++;
        }
        if (n == 0) {
            list.getChildren().add(emptyLine(type.equals("Lost")
                    ? "No lost reports yet." : "No found items yet."));
        }

        VBox card = new VBox(10,
                sectionTitle((type.equals("Lost") ? "Lost reports" : "Found items") + " (" + n + ")"),
                list);
        card.setPadding(new Insets(14));
        card.setStyle(CARD);
        return card;
    }

    private VBox buildAdminRow(Item it) {
        Label name = new Label(it.title);
        name.setStyle("-fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label meta = new Label(it.category + "  |  " + it.location + "  |  " + it.date);
        meta.setWrapText(true);
        meta.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        Label by = new Label("by " + it.reporter);
        by.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: 12px;");
        VBox info = new VBox(2, name, meta, by);
        info.setMinWidth(0);
        HBox.setHgrow(info, Priority.ALWAYS);

        HBox top = new HBox(12, info, statusChip(it));
        top.setAlignment(Pos.CENTER_LEFT);
        if (it.photo != null) top.getChildren().add(0, photoView(it.photo, 44, 44));

        FlowPane btns = new FlowPane(8, 8);
        if (!it.claimed) {
            Button done = new Button("Mark recovered");
            done.setStyle("-fx-background-color: " + Theme.BLUE + "; -fx-text-fill: -cf-on-accent; "
                    + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-cursor: hand;");
            done.setOnAction(e -> {
                markRecovered(it);
                refresh();
                refreshAdmin();
            });
            btns.getChildren().add(done);
        }

        Button delete = new Button("Delete");
        delete.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-danger; "
                + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-cursor: hand;");
        delete.setOnAction(e -> {
            deleteItem(it);
            refresh();
            updateMessagesBadge();
            refreshAdmin();
        });
        btns.getChildren().add(delete);

        VBox row = new VBox(8, top, btns);
        row.setPadding(new Insets(10));
        row.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 10;");
        return row;
    }

    // ---------- Claims (admin) ----------
    private String claimsSection = "Needs verification";
    private Claim selectedClaim;

    private Node buildClaimsTab() {
        List<Claim> pending = new ArrayList<>();
        List<Claim> approved = new ArrayList<>();
        List<Claim> history = new ArrayList<>();
        for (int i = claims.size() - 1; i >= 0; i--) {
            Claim c = claims.get(i);
            if (!items.contains(c.item)) continue;
            if (c.status.equals("Pending")) pending.add(c);
            else if (c.status.equals("Approved")) approved.add(c);
            else history.add(c);
        }

        Map<String, List<Claim>> sections = new LinkedHashMap<>();
        sections.put("Needs verification", pending);
        sections.put("Awaiting handover", approved);
        sections.put("History", history);
        FlowPane tabs = new FlowPane(7, 7);
        sections.forEach((name, entries) -> {
            Button tab = new Button(name + " (" + entries.size() + ")");
            styleChip(tab, name.equals(claimsSection));
            tab.setOnAction(e -> {
                claimsSection = name;
                selectedClaim = null;
                showAdminClaims();
            });
            tabs.getChildren().add(tab);
        });
        List<Claim> entries = sections.get(claimsSection);
        VBox box = new VBox(14, tabs);
        if (entries.isEmpty()) {
            String empty = claimsSection.equals("History") ? "Released and rejected claims will appear here."
                    : claimsSection.equals("Awaiting handover") ? "Approved claims move here for pickup."
                    : "New claim requests will appear here for review.";
            boolean firstVisit = claimsSection.equals("Needs verification") && pending.isEmpty()
                    && approved.isEmpty() && history.isEmpty();
            if (firstVisit && claimPreview) {
                box.getChildren().addAll(sectionTitle("Sample claim · preview only"),
                        buildClaimAdminCard(ReferenceItems.claim(), true));
            } else {
                box.getChildren().add(emptyState(ICON_CLAIM, Theme.BLUE, "No claims here", empty,
                        firstVisit ? "Preview sample claim" : null,
                        () -> { claimPreview = true; showAdminClaims(); }));
            }
            return box;
        }
        if (!entries.contains(selectedClaim)) selectedClaim = entries.get(0);
        VBox queue = new VBox(8);
        queue.setPrefWidth(218);
        queue.setMinWidth(218);
        queue.setMaxWidth(218);
        for (Claim claim : entries) {
            Button entry = new Button();
            Label title = new Label(claim.item.title);
            title.setMinWidth(0);
            Tooltip.install(title, new Tooltip(claim.item.title));
            Label person = new Label(claim.claimant);
            person.setStyle("-fx-text-fill: -cf-muted;");
            VBox summary = new VBox(4, title, person);
            summary.setMinWidth(0);
            person.setMinWidth(0);
            HBox.setHgrow(summary, Priority.ALWAYS);
            HBox row = new HBox(8, itemPicture(claim.item, 38, 38), summary);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setMinWidth(0);
            row.prefWidthProperty().bind(entry.widthProperty().subtract(24));
            entry.setGraphic(row);
            entry.setContentDisplay(javafx.scene.control.ContentDisplay.GRAPHIC_ONLY);
            entry.setMinHeight(60);
            entry.setPrefHeight(60);
            entry.setMaxHeight(60);
            entry.setAccessibleText(claim.item.title + ", " + claim.claimant);
            entry.setAlignment(Pos.CENTER_LEFT);
            entry.setMaxWidth(Double.MAX_VALUE);
            entry.setStyle("-fx-padding: 10; -fx-background-radius: 8; -fx-background-color: " +
                    (claim == selectedClaim ? Theme.TINT : Theme.panel) + "; -fx-border-radius: 8; -fx-border-color: " +
                    (claim == selectedClaim ? Theme.BLUE : Theme.edge) + ";");
            entry.setOnAction(e -> { selectedClaim = claim; showAdminClaims(); });
            queue.getChildren().add(entry);
        }
        VBox detail = buildClaimAdminCard(selectedClaim, false);
        if (entries.size() == 1) {
            box.getChildren().add(detail);
            return box;
        }
        HBox.setHgrow(detail, Priority.ALWAYS);
        detail.setMinWidth(0);
        detail.setMaxWidth(Double.MAX_VALUE);
        HBox split = new HBox(14, queue, detail);
        split.setAlignment(Pos.TOP_LEFT);
        box.getChildren().add(split);
        return box;
    }

    private HBox reviewRow(String label, String value) {
        Label key = wrapLabel(label);
        key.setMinWidth(145);
        key.setPrefWidth(145);
        key.getStyleClass().add("review-key");
        Label text = wrapLabel(value);
        text.setMinWidth(0);
        HBox.setHgrow(text, Priority.ALWAYS);
        HBox row = new HBox(12, key, text);
        row.getStyleClass().add("review-row");
        return row;
    }

    private VBox buildClaimAdminCard(Claim c, boolean sample) {
        Item it = c.item;
        Label title = wrapLabel(it.title);
        title.getStyleClass().add("item-heading");
        String id = sample ? "Claim #1042" : claimId(c);
        Label state = claimChip(c.status);
        if ("Pending".equals(c.status)) state.setText("Needs verification");
        VBox itemSummary = new VBox(6, title, wrapLabel("Found at " + it.location));
        itemSummary.setMinWidth(0); HBox.setHgrow(itemSummary, Priority.ALWAYS);
        HBox itemHeader = new HBox(12, itemPicture(it, 132, 88), itemSummary);
        itemHeader.setAlignment(Pos.CENTER_LEFT);
        VBox found = new VBox(8, sectionTitle("Found item"), itemHeader, wrapLabel(it.description));
        found.setId("review-found-item");
        if (c.hadQuestion) found.getChildren().addAll(fieldLabel("Finder’s private detail"),
                wrapLabel(it.secretQuestion), wrapLabel(it.secretAnswer));
        VBox evidence = new VBox(8, sectionTitle("Student’s evidence"));
        evidence.setId("review-student-evidence");
        if (c.evidencePhoto != null) evidence.getChildren().add(evidencePicture(c.evidencePhoto));
        else evidence.getChildren().add(smallGrey("No evidence photo submitted"));
        evidence.getChildren().addAll(fieldLabel(c.claimant), wrapLabel(c.proof));
        if (c.hadQuestion) evidence.getChildren().addAll(fieldLabel("Student’s answer"),
                wrapLabel(c.submittedAnswer.isEmpty() ? (c.verified ? "Verified at submission" : "No answer recorded") : c.submittedAnswer));
        for (DetailRequest r : c.requests) evidence.getChildren().addAll(fieldLabel("Staff question"),
                wrapLabel(r.question), fieldLabel("Student reply"), wrapLabel(r.reply.isEmpty() ? "Awaiting reply" : r.reply));
        for (VBox panel : new VBox[]{found, evidence}) {
            panel.setMinWidth(0); panel.setPadding(new Insets(14)); panel.setStyle(CARD);
        }
        javafx.scene.layout.GridPane comparison = new javafx.scene.layout.GridPane();
        comparison.setId("claim-comparison"); comparison.setHgap(14); comparison.setVgap(14);
        Runnable arrangeComparison = () -> {
            boolean wide = comparison.getWidth() >= 690;
            comparison.getColumnConstraints().clear();
            javafx.scene.layout.ColumnConstraints first = new javafx.scene.layout.ColumnConstraints();
            first.setPercentWidth(wide ? 50 : 100); comparison.getColumnConstraints().add(first);
            if (wide) { javafx.scene.layout.ColumnConstraints second = new javafx.scene.layout.ColumnConstraints();
                second.setPercentWidth(50); comparison.getColumnConstraints().add(second); }
            javafx.scene.layout.GridPane.setConstraints(found, 0, 0);
            javafx.scene.layout.GridPane.setConstraints(evidence, wide ? 1 : 0, wide ? 0 : 1);
        };
        comparison.getChildren().addAll(found, evidence);
        comparison.widthProperty().addListener((o, old, width) -> arrangeComparison.run()); arrangeComparison.run();
        HBox hero = new HBox(10, state, smallGrey(id), smallGrey("Staff-only review"));
        hero.setAlignment(Pos.CENTER_LEFT);
        VBox record = new VBox(4, reviewRow("Claimant", c.claimant), reviewRow("Student ID", c.studentId),
                reviewRow("Email", c.email), reviewRow("Submitted", c.time.format(LOG_FMT)),
                reviewRow("Finder", it.reporter), reviewRow("Item details", it.description),
                reviewRow("Category / date", it.category + " · " + it.date.format(DATE_FMT)));
        TitledPane details = new TitledPane("Claimant and report details", record);
        details.setExpanded(false);
        String location = it.storageLocation.isBlank() ? it.whereNow : it.storageLocation;
        HBox storage = reviewRow("Storage location", location.isBlank() ? "Unrecorded" : location);
        VBox storageSection = new VBox(6, storage);
        storageSection.getStyleClass().add("review-section");
        if (!sample) {
            Button edit = new Button("Edit storage location");
            edit.setStyle(smallBtn());
            edit.setOnAction(e -> enterClaimText("Staff-only storage location", "Desk, shelf or cabinet", location, value -> {
                it.storageLocation = value;
                audit(CurrentUser.getName(), "Storage location updated", it.title);
                refreshAdmin();
            }));
            storageSection.getChildren().add(edit);
        }
        record.getChildren().addFirst(storageSection);
        VBox card = new VBox(10, hero, comparison);
        if (c.status.equals("Pending")) {
            Button request = new Button("Request details");
            request.setStyle(outlineBtn());
            boolean waiting = c.requests.stream().anyMatch(r -> r.reply.isEmpty());
            request.setDisable(sample || waiting);
            request.setOnAction(e -> enterClaimText("Request details", "What should the student clarify?", "", value -> {
                c.requests.add(new DetailRequest(value));
                c.privateDetailReviewed = false; c.evidenceReviewed = false;
                audit(CurrentUser.getName(), "Claim details requested", it.title);
                updateMessagesBadge();
                refreshAdmin();
            }));
            Button approve = new Button("Approve for pickup");
            approve.setStyle(primaryBtn());
            javafx.scene.control.CheckBox privateCheck = new javafx.scene.control.CheckBox("I compared the identifying details");
            privateCheck.setId("review-private-check"); privateCheck.setWrapText(true);
            privateCheck.setSelected(c.privateDetailReviewed);
            javafx.scene.control.CheckBox evidenceCheck = new javafx.scene.control.CheckBox("I reviewed the ownership evidence and replies");
            evidenceCheck.setId("review-evidence-check"); evidenceCheck.setWrapText(true);
            evidenceCheck.setSelected(c.evidenceReviewed);
            privateCheck.setDisable(sample); evidenceCheck.setDisable(sample);
            privateCheck.selectedProperty().addListener((o, old, value) -> c.privateDetailReviewed = value);
            evidenceCheck.selectedProperty().addListener((o, old, value) -> c.evidenceReviewed = value);
            approve.disableProperty().bind(Bindings.createBooleanBinding(
                    () -> sample || waiting || !privateCheck.isSelected() || !evidenceCheck.isSelected(),
                    privateCheck.selectedProperty(), evidenceCheck.selectedProperty()));
            VBox checklist = new VBox(8, sectionTitle("Review checklist"), privateCheck, evidenceCheck,
                    smallGrey(waiting ? "Waiting for the student’s reply before approval." : "Confirm both checks before approving pickup."));
            checklist.setPadding(new Insets(12)); checklist.setStyle(CARD);
            card.getChildren().add(checklist);
            approve.setOnAction(e -> {
                if (!c.privateDetailReviewed || !c.evidenceReviewed || c.requests.stream().anyMatch(r -> r.reply.isEmpty())) return;
                if (it.claimed) {
                    popup("Cannot approve", wrapLabel("This item has already been recovered."));
                    return;
                }
                for (Claim o : claims) {
                    if (o != c && o.item == c.item && o.status.equals("Approved")) {
                        popup("Cannot approve", wrapLabel("Another claim for this item is already "
                                + "approved. Release it or cancel that approval first."));
                        return;
                    }
                }
                c.status = "Approved";
                c.decided = LocalDateTime.now();
                audit(CurrentUser.getName(), "Claim approved", c.item.title);
                updateMessagesBadge();
                refresh();
                refreshAdmin();
            });

            Button reject = new Button("Reject claim");
            reject.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-danger; "
                    + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-cursor: hand;");
            reject.setOnAction(e -> {
                c.status = "Rejected";
                c.decided = LocalDateTime.now();
                audit(CurrentUser.getName(), "Claim rejected", c.item.title);
                updateMessagesBadge();
                refresh();
                refreshAdmin();
            });
            reject.setDisable(sample);
            card.getChildren().add(new FlowPane(8, 8, request, approve, reject));

        } else if (c.status.equals("Approved")) {
            card.getChildren().add(wrapLabel("Approved for " + c.claimant + ". When the student comes "
                    + "for the item, check their school ID, then type the student ID below to release it."));

            TextField codeField = new TextField();
            codeField.setPromptText("Type the student ID shown on the school ID card");
            codeField.setStyle("-fx-padding: 8;");
            HBox.setHgrow(codeField, Priority.ALWAYS);

            Label err = new Label();
            err.setWrapText(true);
            err.setStyle("-fx-text-fill: -cf-danger;");

            Button release = new Button("Release item");
            release.setStyle("-fx-background-color: #15803d; -fx-text-fill: white; "
                    + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-cursor: hand;");
            release.setOnAction(e -> {
                if (!c.studentId.equalsIgnoreCase(codeField.getText().trim())) {
                    err.setText("The student ID does not match. Do not release the item.");
                    return;
                }
                c.status = "Released";
                c.released = LocalDateTime.now();
                audit(CurrentUser.getName(), "Item returned", c.item.title);
                c.item.claimed = true;
                for (Claim o : claims) {
                    if (o != c && o.item == c.item
                            && (o.status.equals("Pending") || o.status.equals("Approved"))) {
                        o.status = "Rejected";
                    }
                }
                saveState();
                updateMessagesBadge();
                refresh();
                refreshAdmin();
            });

            Button cancelApproval = new Button("Cancel approval");
            cancelApproval.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-danger; "
                    + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-cursor: hand;");
            cancelApproval.setOnAction(e -> {
                c.status = "Pending";
                c.decided = null;
                audit(CurrentUser.getName(), "Claim approval cancelled", c.item.title);
                updateMessagesBadge();
                refresh();
                refreshAdmin();
            });

            card.getChildren().addAll(codeField, new HBox(8, release, cancelApproval), err);

        } else if (c.status.equals("Released")) {
            card.getChildren().add(wrapLabel("Released to " + c.claimant + " on "
                    + (c.released == null ? "" : c.released.toLocalDate()) + "."));
        } else {
            card.getChildren().add(wrapLabel("This claim was rejected."));
        }

        card.getChildren().add(details);
        return card;
    }

    private Node evidencePicture(Image photo) {
        ImageView image = new ImageView(photo);
        image.setFitWidth(180); image.setFitHeight(88); image.setPreserveRatio(true);
        image.setSmooth(true); image.setAccessibleText("Private ownership evidence photo");
        return image;
    }

    private void enterClaimText(String title, String prompt, String initial, Consumer<String> save) {
        javafx.scene.control.TextInputDialog dialog = new javafx.scene.control.TextInputDialog(initial);
        dialog.initOwner(root.getScene().getWindow());
        dialog.setTitle(title);
        dialog.setHeaderText(title);
        dialog.getEditor().setPromptText(prompt);
        CampusStyle.install(dialog.getDialogPane());
        dialog.getDialogPane().lookupButton(javafx.scene.control.ButtonType.OK).disableProperty().bind(
                Bindings.createBooleanBinding(() -> dialog.getEditor().getText().isBlank(),
                        dialog.getEditor().textProperty()));
        dialog.showAndWait().map(String::strip).filter(value -> !value.isEmpty()).ifPresent(save);
    }

    private Label claimChip(String status) {
        String bg;
        String fg;
        if (status.equals("Approved")) {
            bg = "#dbeafe";
            fg = "#1d4ed8";
        } else if (status.equals("Released")) {
            bg = "#dcfce7";
            fg = "#15803d";
        } else if (status.equals("Rejected")) {
            bg = "#fee2e2";
            fg = "#b91c1c";
        } else {
            bg = "#fef3c7";
            fg = "#b45309";
        }
        Label l = new Label(claimLabel(status));
        l.setStyle("-fx-background-color: " + bg + "; -fx-text-fill: " + fg + "; "
                + "-fx-font-weight: bold; -fx-font-size: 12px; "
                + "-fx-background-radius: 10; -fx-padding: 2 10 2 10;");
        return l;
    }

    // ---------- unclaimed items (the limit still has to be confirmed with SAS) ----------
    private static int unclaimedMonths = CampusPreferences.unclaimedMonths();

    private static boolean isUnclaimedOverdue(Item it) {
        return "Found".equals(it.type) && !it.claimed && !it.date.isAfter(LocalDate.now().minusMonths(unclaimedMonths));
    }

    private HBox unclaimedRow(Item it) {
        Label name = new Label(it.type + ": " + it.title);
        name.setStyle("-fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        String now = it.whereNow.isEmpty() ? "" : "  |  now at " + it.whereNow;
        Label meta = new Label(it.category + "  |  " + it.location + "  |  " + it.date
                + "  |  by " + it.reporter + now);
        meta.setWrapText(true);
        meta.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
        VBox info = new VBox(2, name, meta);
        HBox.setHgrow(info, Priority.ALWAYS);

        Button turn = new Button("Turn over to SAS");
        turn.setStyle(smallSolidBtn());
        turn.setOnAction(e -> {
            it.claimed = true;
            audit(CurrentUser.getName(), "Unclaimed item turned over to SAS", it.title);
            refresh();
            refreshAdmin();
        });
        Button delete = new Button("Delete");
        delete.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-danger; -fx-font-weight: bold; "
                + "-fx-font-size: 12px; -fx-background-radius: 8; -fx-padding: 5 12 5 12; -fx-cursor: hand;");
        delete.setOnAction(e -> {
            deleteItem(it);
            refresh();
            refreshAdmin();
        });

        HBox row = new HBox(10, info, countdownChip(it), turn, delete);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(8, 10, 8, 10));
        row.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 10;");
        return row;
    }

    private Node buildUnclaimedTab() {
        ComboBox<String> limit = new ComboBox<>();
        limit.getItems().addAll("1 month", "3 months", "6 months", "12 months", "24 months");
        limit.setValue(unclaimedMonths + (unclaimedMonths == 1 ? " month" : " months"));
        limit.setOnAction(e -> {
            unclaimedMonths = Integer.parseInt(limit.getValue().split(" ")[0]);
            CampusPreferences.setUnclaimedMonths(unclaimedMonths);
            showReports();
        });
        Label limitLabel = new Label("Turn-over limit:");
        limitLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        HBox limitRow = new HBox(10, limitLabel, limit);
        limitRow.setAlignment(Pos.CENTER_LEFT);

        Label note = wrapLabel("Unrecovered found items have a countdown. The exact limit and what happens to the "
                + "item afterwards is decided with SAS. Until then, the admin can turn the item over to SAS "
                + "or delete the report.");
        note.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");

        VBox overdueList = new VBox(6);
        VBox soonList = new VBox(6);
        int od = 0;
        int soon = 0;
        for (int i = items.size() - 1; i >= 0; i--) {
            Item it = items.get(i);
            if (it.claimed || !"Found".equals(it.type)) continue;
            if (isUnclaimedOverdue(it)) {
                od++;
                overdueList.getChildren().add(unclaimedRow(it));
            } else if (daysLeft(it) <= 30) {
                soon++;
                soonList.getChildren().add(unclaimedRow(it));
            }
        }
        if (od == 0) overdueList.getChildren().add(emptyLine("Nothing is overdue."));
        if (soon == 0) soonList.getChildren().add(emptyLine("Nothing reaches the limit in the next 30 days."));

        VBox card = new VBox(8, sectionTitle("Unclaimed items"), limitRow, note,
                sectionTitle("Overdue (" + od + ")"), overdueList,
                sectionTitle("Reaching the limit in 30 days (" + soon + ")"), soonList);
        card.setPadding(new Insets(14));
        card.setStyle(CARD);
        return card;
    }

    // ---------- campus hotspots: where items get lost / found the most ----------
    private static long daysLeft(Item it) {
        return ChronoUnit.DAYS.between(LocalDate.now(), it.date.plusMonths(unclaimedMonths));
    }

    private static Label countdownChip(Item it) {
        long d = daysLeft(it);
        String text;
        String bg;
        String fg;
        if (d < 0) {
            text = "Overdue by " + (-d) + " day" + (-d == 1 ? "" : "s");
            bg = "#fee2e2";
            fg = "#b91c1c";
        } else if (d <= 14) {
            text = "Turn-over to SAS in " + d + " day" + (d == 1 ? "" : "s");
            bg = "#fef3c7";
            fg = "#b45309";
        } else {
            text = "Turn-over to SAS in " + d + " days";
            bg = "#e2e8f0";
            fg = "#475569";
        }
        Label l = new Label(text);
        l.setStyle("-fx-background-color: " + bg + "; -fx-text-fill: " + fg + "; -fx-font-weight: bold; "
                + "-fx-font-size: 11.5px; -fx-background-radius: 10; -fx-padding: 2 10 2 10;");
        return l;
    }

    private static String norm(String s) {
        return s == null ? "" : s.trim().toLowerCase().replaceAll("\\s+", " ");
    }

    private static String csv(String s) {
        return "\"" + (s == null ? "" : s.replace("\"", "\"\"")) + "\"";
    }

    private void exportCsv() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Save the report as CSV");
        fc.setInitialFileName("lost-and-found-report.csv");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV file", "*.csv"));
        File f = fc.showSaveDialog(root.getScene().getWindow());
        if (f == null) return;
        try (java.io.PrintWriter w = new java.io.PrintWriter(f, "UTF-8")) {
            w.println("Type,Item,Category,Location,Date,Reported by,Status,Description");
            for (Item it : items) {
                w.println(String.join(",", csv(it.type), csv(it.title), csv(it.category), csv(it.location),
                        csv(it.date.toString()), csv(it.reporter), csv(statusOf(it)), csv(it.description)));
            }
            audit(CurrentUser.getName(), "Report exported", f.getName());
            popup("Export", wrapLabel("Saved " + items.size() + " report(s) to " + f.getName()));
        } catch (Exception ex) {
            popup("Export failed", wrapLabel("The file could not be saved: " + ex.getMessage()));
        }
    }

    private Node buildRecoveredTab() {
        VBox list = new VBox(8);
        int n = 0;
        for (int i = items.size() - 1; i >= 0; i--) {
            Item it = items.get(i);
            if (!it.claimed) continue;
            n++;

            Claim rc = releasedClaim(it);
            Label name = new Label(it.title);
            name.setStyle("-fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
            Label meta = new Label(it.type + "  |  " + it.category + "  |  " + it.location
                    + "  |  reported by " + it.reporter);
            meta.setWrapText(true);
            meta.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");
            Label who = new Label(rc != null
                    ? "Released to " + rc.claimant + " on "
                    + (rc.released == null ? "" : rc.released.toLocalDate())
                    : "Marked as recovered");
            who.setStyle("-fx-text-fill: -cf-success; -fx-font-size: 12px; -fx-font-weight: bold;");

            HBox row = new HBox(12, new VBox(2, name, meta, who));
            row.setAlignment(Pos.CENTER_LEFT);
            if (it.photo != null) row.getChildren().add(0, photoView(it.photo, 44, 44));
            row.setPadding(new Insets(10));
            row.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 10;");
            list.getChildren().add(row);
        }
        if (n == 0) list.getChildren().add(emptyLine("No recovered items yet."));

        VBox card = new VBox(10, sectionTitle("Recovered items (" + n + ")"), list);
        card.setPadding(new Insets(14));
        card.setStyle(CARD);
        return card;
    }

    // =====================================================
    // CLAIM REQUEST (student side)
    // =====================================================
    private void openClaimDialog(Item it) {
        String me = CurrentUser.getName();
        if (!canClaim(it, me)) return;

        Stage dialog = new Stage();
        dialog.initOwner(root.getScene().getWindow());
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.initStyle(StageStyle.TRANSPARENT);

        boolean[] sent = new boolean[1];

        Label heading = new Label("Claim request");
        heading.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");

        Label about = new Label("Found item: " + it.title + " at " + it.location);
        about.setWrapText(true);
        about.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-accent; "
                + "-fx-background-radius: 8; -fx-padding: 6 10 6 10; -fx-font-size: 12.5px;");

        Label info = wrapLabel("Describe proof that this item is yours, such as unique marks, what "
                + "is inside it, or a serial number. The admin will verify your proof before the "
                + "item can be released.");

        Label idLabel = fieldLabel("Student ID *");
        TextField studentIdField = new TextField(CurrentUser.getStudentId());
        studentIdField.setPromptText("Your student ID");
        studentIdField.setStyle("-fx-padding: 8;");
        Label idHint = new Label("The staff will check this ID, and your school ID card, before giving you "
                + "the item.");
        idHint.setWrapText(true);
        idHint.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");

        TextArea proof = new TextArea();
        proof.setPromptText("Proof of ownership (e.g. black wallet with a torn corner, has my "
                + "school ID and two receipts inside)");
        proof.setPrefRowCount(3);
        proof.setWrapText(true);

        // verification question set by the finder
        TextField answerField = new TextField();
        VBox verifyBox = new VBox(4);
        if (!it.secretQuestion.isEmpty()) {
            Label q = fieldLabel("Verification question: " + it.secretQuestion);
            q.setWrapText(true);
            answerField.setPromptText("Your answer");
            answerField.setStyle("-fx-padding: 8;");
            verifyBox.getChildren().addAll(q, answerField);
        }

        Label error = new Label();
        error.setWrapText(true);
        error.setStyle("-fx-text-fill: -cf-danger;");

        Image[] evidencePhoto = {null};
        VBox photoPreview = new VBox(6);
        Button addPhoto = new Button("Add evidence photo (optional)");
        addPhoto.setStyle(outlineBtn());
        Button removePhoto = new Button("Remove photo"); removePhoto.setStyle(smallBtn());
        removePhoto.setOnAction(e -> { evidencePhoto[0] = null; photoPreview.getChildren().clear(); });
        addPhoto.setOnAction(e -> {
            FileChooser chooser = new FileChooser(); chooser.setTitle("Ownership evidence photo");
            chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg"));
            File file = chooser.showOpenDialog(dialog);
            if (file == null) return;
            try {
                Image photo = new Image(CampusLocalStore.keepPhoto(file), 1000, 1000, true, true);
                if (photo.isError() || photo.getWidth() <= 0) throw new IllegalArgumentException("Invalid image");
                evidencePhoto[0] = photo;
                ImageView preview = new ImageView(photo); preview.setFitWidth(160); preview.setFitHeight(80); preview.setPreserveRatio(true);
                photoPreview.getChildren().setAll(preview, removePhoto); error.setText("");
            } catch (java.io.IOException | RuntimeException ex) { error.setText("This photo could not be opened. Choose a PNG or JPEG image."); }
        });
        VBox photoSection = new VBox(6, addPhoto, smallGrey("Shared with staff for this claim; not shown in Browse Items."), photoPreview);

        Button cancel = new Button("Cancel");
        cancel.setCancelButton(true);
        cancel.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: " + DARK + "; "
                + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-padding: 8 20 8 20; "
                + "-fx-cursor: hand;");
        cancel.setOnAction(e -> dialog.close());

        Button submit = new Button("Send claim request");
        submit.setDefaultButton(true);
        submit.setStyle("-fx-background-color: " + Theme.BLUE + "; -fx-text-fill: -cf-on-accent; "
                + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-padding: 8 20 8 20; "
                + "-fx-cursor: hand;");
        submit.setOnAction(e -> {
            String text = proof.getText().trim();
            if (text.length() < 10) {
                error.setText("Please describe your proof in a bit more detail.");
                return;
            }
            String sid = studentIdField.getText().trim();
            if (sid.isEmpty()) {
                error.setText("Please enter your student ID.");
                return;
            }
            boolean passed = false;
            if (!it.secretQuestion.isEmpty()) {
                if (!norm(answerField.getText()).equals(norm(it.secretAnswer))) {
                    error.setText("The answer to the verification question does not match.");
                    return;
                }
                passed = true;
            }
            Claim nc = new Claim(it, me, text, sid, CurrentUser.getEmail());
            nc.hadQuestion = !it.secretQuestion.isEmpty();
            nc.verified = passed;
            nc.submittedAnswer = answerField.getText().strip();
            nc.evidencePhoto = evidencePhoto[0];
            claims.add(nc);
            audit(me, "Claim submitted", it.title);
            sent[0] = true;
            dialog.close();
        });

        HBox buttons = new HBox(10, cancel, submit);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        VBox box = new VBox(10, heading, about, info, proof, new VBox(4, idLabel, studentIdField), idHint,
                verifyBox, photoSection, error, buttons);
        box.setPadding(new Insets(22));
        box.setPrefWidth(440);
        box.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 12; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.35), 18, 0, 0, 4);");

        ScrollPane claimScroll = new ScrollPane(box);
        claimScroll.setFitToWidth(true); claimScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        claimScroll.setPrefViewportWidth(460);
        claimScroll.setPrefViewportHeight(Math.max(360, Math.min(620, root.getScene().getHeight() - 80)));
        StackPane wrapper = new StackPane(claimScroll);
        wrapper.setPadding(new Insets(20));
        wrapper.setStyle("-fx-background-color: transparent;");

        CampusStyle.install(wrapper);
        Scene scene = new Scene(wrapper);
        scene.setFill(Color.TRANSPARENT);
        dialog.setScene(scene);
        dialog.showAndWait();

        if (sent[0]) {
            updateMessagesBadge();
            popup("Claim request sent", wrapLabel("The admin will review your proof. Check My "
                    + "Claims for the status. If it is approved, bring your school ID to the "
                    + "staff to get the item."));
        }
    }

    private VBox buildMyClaimCard(Claim c) {
        Item it = c.item;

        Label name = new Label(it.title);
        name.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox top = new HBox(10, name, gap, claimChip(c.status));
        top.setAlignment(Pos.CENTER_LEFT);

        Label meta = new Label(it.category + "  |  " + it.location + "  |  found " + it.date);
        meta.setWrapText(true);
        meta.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");

        Label proofTitle = new Label("Your proof");
        proofTitle.setStyle("-fx-font-weight: bold; -fx-font-size: 12px; -fx-text-fill: "
                + GREY_TEXT + ";");

        Label nextAction = wrapLabel("Next action: " + claimNextAction(c));
        nextAction.setId("claim-next-action");
        nextAction.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-ink; -fx-padding: 10; -fx-background-radius: 8;");
        VBox card = new VBox(10, top, meta, buildTimeline(c), nextAction, proofTitle, wrapLabel(c.proof));
        if (c.evidencePhoto != null) card.getChildren().add(evidencePicture(c.evidencePhoto));

        if (c.status.equals("Approved")) {
            Label codeTitle = new Label("Bring this student ID");
            codeTitle.setStyle("-fx-text-fill: -cf-accent; -fx-font-weight: bold;");
            Label code = new Label(c.studentId);
            code.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: -cf-accent;");
            Label how = wrapLabel("Approved! Bring your school ID to the lost and found office. The staff "
                    + "will check that your student ID matches before giving you the item.");
            VBox codeBox = new VBox(2, codeTitle, code, how);
            if (!it.whereNow.isEmpty()) codeBox.getChildren().add(wrapLabel("Pick up at: " + it.whereNow));
            codeBox.setPadding(new Insets(12));
            codeBox.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 10;");
            card.getChildren().add(codeBox);

        } else if (c.status.equals("Pending")) {
            card.getChildren().add(wrapLabel("Waiting for the admin to review your proof."));
            for (DetailRequest request : c.requests) {
                card.getChildren().addAll(fieldLabel("Staff question"), wrapLabel(request.question));
                if (request.reply.isEmpty()) {
                    Button reply = new Button("Reply to staff");
                    reply.setStyle(smallSolidBtn());
                    reply.setOnAction(e -> enterClaimText("Reply to staff", request.question, "", value -> {
                        request.reply = value;
                        request.answered = LocalDateTime.now();
                        c.privateDetailReviewed = false; c.evidenceReviewed = false;
                        audit(CurrentUser.getName(), "Claim details supplied", it.title);
                        updateMessagesBadge();
                        showClaims();
                    }));
                    card.getChildren().add(reply);
                } else card.getChildren().add(wrapLabel("Your reply: " + request.reply));
            }
            Button cancel = new Button("Cancel request");
            cancel.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-danger; "
                    + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-cursor: hand;");
            cancel.setOnAction(e -> {
                claims.remove(c);
                audit(CurrentUser.getName(), "Claim cancelled", c.item.title);
                updateMessagesBadge();
                refresh();
                showClaims();
            });
            card.getChildren().add(cancel);

        } else if (c.status.equals("Released")) {
            Label done = wrapLabel("The item was released to you"
                    + (c.released == null ? "." : " on " + c.released.toLocalDate() + "."));
            done.setStyle("-fx-text-fill: -cf-success; -fx-font-weight: bold;");
            card.getChildren().add(done);

        } else {
            card.getChildren().add(wrapLabel("The admin could not verify this claim. If you think "
                    + "this is a mistake, visit the lost and found office."));
        }

        Button details = new Button("View claim details");
        details.setStyle(outlineBtn());
        details.setOnAction(e -> openClaimDetails(c));
        card.getChildren().add(details);

        card.setPadding(new Insets(14));
        card.setStyle(CARD);
        return card;
    }

    // =====================================================
    // AI MATCH ENGINE
    // =====================================================
    private static final int MATCH_MIN = 40;

    private static final Set<String> STOP = new HashSet<>(Arrays.asList(
            "a", "an", "the", "my", "i", "is", "it", "at", "in", "on", "of", "and", "or", "to",
            "with", "for", "from", "near", "lost", "found", "please", "have", "has", "was",
            "were", "this", "that", "me", "you", "your", "do", "does", "did", "any", "someone",
            "somebody", "anyone", "anybody", "who", "where", "what", "how", "can", "find",
            "looking", "look", "item", "left", "got", "get", "there", "here", "some", "are",
            "be", "been", "by", "its", "just", "show", "list", "recent", "latest"));

    private static final Map<String, String> SYN = new HashMap<>();

    static {
        syn("phone", "phones", "cellphone", "cellphones", "mobile", "smartphone", "iphone", "android", "cp");
        syn("bag", "bags", "backpack", "backpacks", "handbag", "tote", "sling", "satchel");
        syn("wallet", "wallets", "purse", "billfold");
        syn("card", "cards", "id", "ids", "identification");
        syn("umbrella", "umbrellas", "brolly");
        syn("bottle", "bottles", "tumbler", "flask", "thermos");
        syn("key", "keys", "keychain", "keyring");
        syn("laptop", "laptops", "macbook", "computer");
        syn("earphones", "earphone", "earbuds", "earbud", "headphones", "headphone",
                "airpods", "airpod", "headset");
        syn("glasses", "glass", "eyeglasses", "eyeglass", "spectacles", "spectacle", "shades");
        syn("charger", "chargers", "adapter", "cable", "powerbank");
        syn("watch", "watches", "wristwatch");
        syn("jacket", "jackets", "hoodie", "sweater", "coat");
    }

    private static void syn(String canonical, String... words) {
        SYN.put(canonical, canonical);
        for (String w : words) SYN.put(w, canonical);
    }

    static class Match {
        Item other;
        int pct;

        Match(Item other, int pct) {
            this.other = other;
            this.pct = pct;
        }
    }

    static class Pair {
        Item lost;
        Item found;
        int pct;

        Pair(Item lost, Item found, int pct) {
            this.lost = lost;
            this.found = found;
            this.pct = pct;
        }
    }

    private static Set<String> tokens(String text) {
        Set<String> out = new LinkedHashSet<>();
        if (text == null) return out;
        for (String w : text.toLowerCase().split("[^a-z0-9]+")) {
            if (w.length() < 2 || STOP.contains(w)) continue;
            String c = SYN.get(w);
            if (c == null && w.length() > 3 && w.endsWith("s") && !w.endsWith("ss")) {
                String s = w.substring(0, w.length() - 1);
                c = SYN.getOrDefault(s, s);
            }
            out.add(c == null ? w : c);
        }
        return out;
    }

    private static double overlap(Set<String> a, Set<String> b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        int inter = 0;
        for (String s : a) if (b.contains(s)) inter++;
        return inter / (double) Math.min(a.size(), b.size());
    }

    private static double jaccard(Set<String> a, Set<String> b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        int inter = 0;
        for (String s : a) if (b.contains(s)) inter++;
        return inter / (double) (a.size() + b.size() - inter);
    }

    private static int score(Item a, Item b) {
        double titleSim = overlap(tokens(a.title), tokens(b.title));
        double textSim = jaccard(tokens(a.title + " " + a.description),
                tokens(b.title + " " + b.description));
        double locSim = overlap(tokens(a.location), tokens(b.location));

        double s = 0.55 * titleSim + 0.30 * textSim + 0.15 * locSim;
        if (titleSim == 0) s *= 0.5;
        return (int) Math.round(Math.min(1.0, s) * 100);
    }

    private static List<Match> matchesFor(Item it, int limit) {
        List<Match> out = new ArrayList<>();
        if (it.claimed) return out;
        String wanted = it.type.equals("Lost") ? "Found" : "Lost";
        for (Item o : items) {
            if (o == it || o.claimed || !o.type.equals(wanted)) continue;
            int p = score(it, o);
            if (p >= MATCH_MIN) out.add(new Match(o, p));
        }
        out.sort((x, y) -> y.pct - x.pct);
        return out.size() > limit ? new ArrayList<>(out.subList(0, limit)) : out;
    }

    private List<Pair> collectPairs() {
        String me = CurrentUser.getName();
        List<Pair> pairs = new ArrayList<>();
        for (Item l : items) {
            if (!l.type.equals("Lost") || l.claimed) continue;
            for (Item f : items) {
                if (!f.type.equals("Found") || f.claimed) continue;
                if (!admin && !l.reporter.equalsIgnoreCase(me)
                        && !f.reporter.equalsIgnoreCase(me)) continue;
                int p = score(l, f);
                if (p >= MATCH_MIN) pairs.add(new Pair(l, f, p));
            }
        }
        pairs.sort((a, b) -> b.pct - a.pct);
        return pairs;
    }

    private Label matchLine(Match m) {
        Label l = new Label(m.other.type + ": " + m.other.title + " at " + m.other.location
                + "  (" + m.pct + "% match)");
        l.setWrapText(true);
        l.setMaxWidth(420);
        l.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-accent; "
                + "-fx-background-radius: 8; -fx-padding: 6 10 6 10; -fx-font-size: 12.5px;");
        return l;
    }

    private void showMatchPopup(Item posted) {
        List<Match> ms = matchesFor(posted, 3);
        if (ms.isEmpty()) return;

        String kind = posted.type.equals("Lost") ? "found" : "lost";
        Label intro = new Label("I found " + ms.size() + " possible " + kind + " report"
                + (ms.size() > 1 ? "s" : "") + " that may match \"" + posted.title + "\":");
        intro.setWrapText(true);
        intro.setStyle("-fx-text-fill: -cf-ink;");

        VBox body = new VBox(8, intro);
        for (Match m : ms) body.getChildren().add(matchLine(m));
        popup("AI Match", body);
    }

    private void popup(String heading, Node body) {
        Stage dialog = new Stage();
        dialog.initOwner(root.getScene().getWindow());
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.initStyle(StageStyle.TRANSPARENT);

        Label h = new Label(heading);
        h.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: -cf-accent;");

        Button ok = new Button("OK");
        ok.setDefaultButton(true);
        ok.setCancelButton(true);
        ok.setStyle("-fx-background-color: " + Theme.BLUE + "; -fx-text-fill: -cf-on-accent; "
                + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-padding: 8 24 8 24; "
                + "-fx-cursor: hand;");
        ok.setOnAction(e -> dialog.close());

        HBox buttons = new HBox(ok);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        VBox box = new VBox(12, h, body, buttons);
        box.setPadding(new Insets(22));
        box.setPrefWidth(440);
        box.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 12; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.35), 18, 0, 0, 4);");

        StackPane wrapper = new StackPane(box);
        wrapper.setPadding(new Insets(20));
        wrapper.setStyle("-fx-background-color: transparent;");

        CampusStyle.install(wrapper);
        Scene scene = new Scene(wrapper);
        scene.setFill(Color.TRANSPARENT);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    // =====================================================
    // AI MATCHING SCREEN
    // =====================================================
    private Node buildMatchesView() {
        List<Pair> pairs = collectPairs();

        Label title = pageTitle("KITA AI");
        HBox titleRow = new HBox(10, aiIcon(38), title);
        titleRow.setAlignment(Pos.CENTER_LEFT);
        Label sub = new Label(admin
                ? "Possible matches between all lost and found reports, best match first."
                : "We found possible matches based on the item name, description, category, "
                + "location and date.");
        sub.setWrapText(true);
        sub.setStyle("-fx-text-fill: " + GREY_TEXT + ";");
        Label how = new Label("Matches are suggestions only. The admin verifies ownership before an "
                + "item is released.");
        how.setWrapText(true);
        how.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");

        VBox list = new VBox(16);
        if (pairs.isEmpty()) {
            VBox box = new VBox(emptyLine("No possible matches yet. They will show up here as soon as "
                    + "a lost and a found report look alike."));
            box.setPadding(new Insets(28));
            box.setStyle(CARD);
            list.getChildren().add(box);
        }
        for (Pair p : pairs) list.getChildren().add(buildPairCard(p));

        return pageOf(titleRow, sub, how, list);
    }

    private VBox buildPairCard(Pair p) {
        boolean mineLost = p.lost.reporter.equalsIgnoreCase(CurrentUser.getName());
        String leftTitle = (!admin && mineLost) ? "Your Lost Item" : "Lost Report";
        String rightTitle = admin ? "Found Report" : (mineLost ? "Possible Match" : "Your Found Item");

        VBox left = matchSide(leftTitle, p.lost);
        VBox right = matchSide(rightTitle, p.found);
        HBox sides = new HBox(18, left, percentRing(p.pct, 96), right);
        sides.setAlignment(Pos.CENTER);

        VBox why = new VBox(8, sectionTitle("Why this is a match?"));
        for (String reason : matchReasons(p)) {
            Label l = new Label(reason);
            l.setGraphic(new Group(svg(ICON_CHECK, 18, "#22a06b")));
            l.setGraphicTextGap(10);
            l.setWrapText(true);
            l.setStyle("-fx-text-fill: -cf-ink;");
            why.getChildren().add(l);
        }
        why.setPadding(new Insets(14));
        why.setStyle("-fx-background-color: " + Theme.TINT_SOFT + "; -fx-background-radius: 12;");

        Label note = new Label("Suggestion only. The admin must verify ownership before the item is "
                + "released.");
        note.setWrapText(true);
        note.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 12px;");

        FlowPane btns = new FlowPane(10, 10);
        Button view = new Button("View Item Details");
        view.setStyle(outlineBtn());
        view.setOnAction(e -> showItemDetail(p.found));
        btns.getChildren().add(view);

        if (admin) {
            Button review = new Button("Review claim requests");
            review.setStyle(primaryBtn());
            review.setOnAction(e -> showAdminClaims());
            btns.getChildren().add(review);
        } else {
            if (mineLost && canClaim(p.found, CurrentUser.getName())) {
                Button claimBtn = new Button("Claim This Item");
                claimBtn.setStyle(primaryBtn());
                claimBtn.setOnAction(e -> {
                    openClaimDialog(p.found);
                    showMatches();
                });
                btns.getChildren().add(claimBtn);
            }
            Button chat = new Button(mineLost ? "Message finder" : "Message owner");
            chat.setStyle(outlineBtn());
            chat.setOnAction(e -> {
                openChat(mineLost ? p.found : p.lost, CurrentUser.getName());
            });
            btns.getChildren().add(chat);
        }

        VBox card = new VBox(14, sides, why, note, btns);
        card.setPadding(new Insets(18));
        card.setStyle(CARD);
        return card;
    }

    private VBox matchSide(String heading, Item it) {
        Label h = new Label(heading);
        h.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: " + DARK + ";");

        Label name = new Label(it.title);
        name.setWrapText(true);
        name.setStyle("-fx-font-weight: bold; -fx-font-size: 15px; -fx-text-fill: " + DARK + ";");
        Label by = new Label("by " + it.reporter);
        by.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: 11px;");
        VBox info = new VBox(4, name, kindAndDate(it, 12), pinAndPlace(it.location, 12), by);
        HBox.setHgrow(info, Priority.ALWAYS);

        HBox body = new HBox(12, itemPicture(it, 110, 110), info);
        body.setAlignment(Pos.CENTER_LEFT);

        VBox box = new VBox(10, h, body);
        box.setPadding(new Insets(14));
        box.setPrefWidth(320);
        box.setMaxWidth(Double.MAX_VALUE);
        box.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 14; "
                + "-fx-border-color: #e3ebf2; -fx-border-radius: 14;");
        HBox.setHgrow(box, Priority.ALWAYS);
        return box;
    }

    private Node percentRing(int pct, double size) {
        double r = size / 2 - 6;
        Pane ring = new Pane();
        ring.setMinSize(size, size);
        ring.setPrefSize(size, size);
        ring.setMaxSize(size, size);

        Circle track = new Circle(size / 2, size / 2, r);
        track.setFill(null);
        track.setStroke(Color.web(Theme.TINT_LINE));
        track.setStrokeWidth(9);

        Arc arc = new Arc(size / 2, size / 2, r, r, 90, -360.0 * pct / 100.0);
        arc.setType(ArcType.OPEN);
        arc.setFill(null);
        arc.setStroke(Color.web(Theme.BLUE));
        arc.setStrokeWidth(9);
        arc.setStrokeLineCap(StrokeLineCap.ROUND);
        ring.getChildren().addAll(track, arc);

        Label num = new Label(pct + "%");
        num.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");
        Label cap = new Label("Match");
        cap.setStyle("-fx-text-fill: " + GREY_TEXT + "; -fx-font-size: 11px;");
        VBox label = new VBox(0, num, cap);
        label.setAlignment(Pos.CENTER);

        StackPane p = new StackPane(ring, label);
        p.setMinSize(size, size);
        p.setMaxSize(size, size);
        return p;
    }

    private List<String> matchReasons(Pair p) {
        List<String> r = new ArrayList<>();

        if (p.lost.category.equals(p.found.category)) {
            r.add("Same category (" + p.found.category + ")");
        }

        Set<String> sharedTitle = new LinkedHashSet<>(tokens(p.lost.title));
        sharedTitle.retainAll(tokens(p.found.title));
        if (!sharedTitle.isEmpty()) {
            r.add("Similar item name (" + String.join(", ", sharedTitle) + ")");
        }

        Set<String> sharedText = new LinkedHashSet<>(tokens(p.lost.description));
        sharedText.retainAll(tokens(p.found.description));
        sharedText.removeAll(sharedTitle);
        if (!sharedText.isEmpty()) {
            r.add("Similar description (" + String.join(", ", sharedText) + ")");
        }

        Set<String> sharedPlace = new LinkedHashSet<>(tokens(p.lost.location));
        sharedPlace.retainAll(tokens(p.found.location));
        if (!sharedPlace.isEmpty()) {
            r.add("Found near the place it was lost (" + String.join(", ", sharedPlace) + ")");
        }

        long days = Math.abs(ChronoUnit.DAYS.between(p.lost.date, p.found.date));
        if (days <= 3) {
            r.add("The dates are close (" + (days == 0 ? "same day" : days + " day"
                    + (days == 1 ? "" : "s") + " apart") + ")");
        }

        if (r.isEmpty()) r.add("The reports have similar details");
        return r;
    }

    // =====================================================
    // AI ASSISTANT (chat)
    // =====================================================
    private static final Map<String, List<String>> watchlist = new HashMap<>();
    private FlowPane watchBox;

    private static List<String> myWatch(String me) {
        return watchlist.computeIfAbsent(me == null ? "" : me.toLowerCase(), k -> new ArrayList<>());
    }

    // true when (almost) all the words of the watched text are in the found item
    private static boolean watchMatches(String term, Item it) {
        Set<String> t = tokens(term);
        if (t.isEmpty()) return false;
        Set<String> found = tokens(it.title + " " + it.description + " " + it.location + " " + it.category);
        int inter = 0;
        for (String x : t) {
            if (found.contains(x)) inter++;
        }
        return inter / (double) t.size() >= 0.6;
    }

    private void refreshWatchBox() {
        watchBox.getChildren().clear();
        List<String> w = myWatch(CurrentUser.getName());
        watchBox.setVisible(!admin && !w.isEmpty());
        watchBox.setManaged(watchBox.isVisible());
        if (admin || w.isEmpty()) return;
        watchBox.getChildren().add(smallGrey("Watching:"));
        for (String term : w) {
            Label t = new Label(term);
            t.setStyle("-fx-text-fill: " + Theme.BLUE + "; -fx-font-weight: bold; -fx-font-size: 12px;");
            Button x = new Button("×");
            x.setAccessibleText("Stop watching " + term);
            x.setStyle("-fx-background-color: transparent; -fx-text-fill: -cf-danger; -fx-padding: 0 3;");
            HBox chip = new HBox(2, t, x);
            chip.setAlignment(Pos.CENTER_LEFT);
            chip.setPadding(new Insets(3, 10, 3, 10));
            chip.setStyle("-fx-background-color: " + Theme.TINT + "; -fx-background-radius: 14;");
            x.setOnAction(e -> {
                w.remove(term);
                refreshWatchBox();
                updateMessagesBadge();
            });
            watchBox.getChildren().add(chip);
        }
    }

    private final List<Runnable> aiCardRefreshers = new ArrayList<>();

    private Node buildAssistantView() {
        VBox panel = buildChatPanel();
        VBox.setVgrow(panel, Priority.ALWAYS);
        Label title = new Label("KITA AI Assistant");
        title.setStyle("-fx-text-fill: white; -fx-font-size: 23px; -fx-font-weight: bold;");
        Label subtitle = new Label("Search possible matches, review reports and get campus recovery guidance");
        subtitle.setWrapText(true);
        subtitle.setStyle("-fx-text-fill: #dbe9ff; -fx-font-size: 12px;");
        VBox headerText = new VBox(4, title, subtitle);
        headerText.setMinWidth(0);
        HBox.setHgrow(headerText, Priority.ALWAYS);
        Button infoButton = new Button("Matching help");
        infoButton.setAccessibleText("Open KITA AI matching help and shortcuts");
        infoButton.getStyleClass().add("cf-v2-kita-help");
        infoButton.setOnAction(e -> {
            Label guidance = new Label("Describe an item by type, color, brand and location. "
                    + "KITA compares local lost and found reports and shows potential matches; "
                    + "ownership is verified by campus staff.");
            guidance.setWrapText(true);
            Label total = new Label(collectPairs().size() + " possible matches currently found");
            total.setStyle("-fx-text-fill: #0c3c88; -fx-font-weight: bold;");
            Button browseReports = new Button(admin ? "Manage reports" : "Browse reports");
            browseReports.setStyle(smallSolidBtn());
            browseReports.setOnAction(a -> {
                if (browseReports.getScene() != null && browseReports.getScene().getWindow() instanceof Stage window)
                    window.close();
                if (admin) showReports(); else showBrowse();
            });
            popup("KITA AI help", new VBox(12, total, guidance, browseReports));
        });
        HBox header = new HBox(14, aiIcon(46), headerText, infoButton);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(17,22,17,22));
        header.setStyle("-fx-background-color: linear-gradient(to right, #062768, #185cc7); "
                + "-fx-background-radius: 16; -fx-border-color: transparent transparent #ffca23 transparent; "
                + "-fx-border-width: 0 0 3 0;");

        int pairs = collectPairs().size();
        Label matchCount = new Label(String.valueOf(pairs));
        matchCount.setStyle("-fx-text-fill: #082e72; -fx-font-size: 33px; -fx-font-weight: bold;");
        Label matchesLabel = new Label(pairs == 1 ? "Possible match" : "Possible matches");
        matchesLabel.setStyle("-fx-text-fill: #60769a; -fx-font-size: 13px;");
        Label tipTitle = new Label("Find what matters");
        tipTitle.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: #0e357f;");
        Label tip = new Label("Describe the item, its color, brand and where it was lost or found. "
                + "KITA compares existing campus reports and suggests possible matches.");
        tip.setWrapText(true);
        tip.setStyle("-fx-font-size: 12px; -fx-text-fill: #516b92;");
        Button find = studentShortcut("Find possible matches", ICON_SEARCH, () -> sendChat("Show possible matches"));
        Button status = studentShortcut(admin ? "Review claim requests" : "Check my claims",
                ICON_CLAIM, admin ? this::showAdminClaims : this::showClaims);
        Button browse = studentShortcut("Browse reports", ICON_LIST, admin ? this::showReports : this::showBrowse);
        for (Button action : new Button[]{find,status,browse}) {
            action.setMaxWidth(Double.MAX_VALUE);
            action.setAlignment(Pos.CENTER_LEFT);
            action.setStyle("-fx-background-color: #edf4ff; -fx-text-fill: #0a3b96; "
                    + "-fx-font-weight: bold; -fx-padding: 11 12; -fx-background-radius: 10; "
                    + "-fx-border-color: #d3e3ff; -fx-border-radius: 10;");
        }
        VBox insight = new VBox(12,
                new HBox(10, aiIcon(42), new VBox(4, matchCount,matchesLabel)),
                new Separator(), tipTitle, tip, find, status, browse);
        insight.setPadding(new Insets(18));
        insight.setMinWidth(0);
        insight.setPrefWidth(285);
        insight.setMaxWidth(290);
        insight.setStyle("-fx-background-color: white; -fx-background-radius: 15; "
                + "-fx-border-color: #c6d9fa; -fx-border-radius: 15;");
        ScrollPane insightScroller = new ScrollPane(insight);
        insightScroller.setFitToWidth(true);
        insightScroller.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        insightScroller.setMinSize(0, 0);
        insightScroller.setMaxWidth(290);
        insightScroller.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        BorderPane workspace = new BorderPane();
        workspace.setMinHeight(0);
        workspace.setCenter(panel);
        workspace.setRight(insightScroller);
        BorderPane.setMargin(insightScroller, new Insets(0, 0, 0, 12));
        VBox.setVgrow(workspace, Priority.ALWAYS);

        VBox view = new VBox(12, header, workspace);
        view.setId("kita-unified");
        view.setPadding(new Insets(12,16,12,16));
        view.setMinHeight(0);
        StackPane holder = new StackPane(view);
        StackPane.setAlignment(view, Pos.TOP_CENTER);
        view.prefHeightProperty().bind(holder.heightProperty());
        Runnable fitKita = () -> {
            boolean showSide = holder.getWidth() > 970;
            insightScroller.setVisible(showSide);
            insightScroller.setManaged(showSide);
            infoButton.setVisible(!showSide);
            infoButton.setManaged(!showSide);
        };
        holder.widthProperty().addListener((o,a,w) -> fitKita.run());
        fitKita.run();
        return holder;
    }

    private Node aiItemCard(Item item) {
        Label title = fieldLabel(item.title);
        title.setWrapText(true);
        VBox info = new VBox(4, title, smallGrey(item.location + " · " + item.date.format(DATE_FMT)));
        info.setMinWidth(0);
        HBox.setHgrow(info, Priority.ALWAYS);
        StackPane status = new StackPane();
        Button view = new Button("View item");
        view.setStyle(smallSolidBtn());
        view.setOnAction(e -> {
            if (!items.contains(item)) { addBubble("This report is no longer available.", false); return; }
            openScreen(buildDetailScreen(item, this::showAssistant, "Back to KITA AI"), aiNav, false, false);
        });
        HBox card = new HBox(12, itemPicture(item, 60, 60), info, status, view);
        card.setAlignment(Pos.CENTER_LEFT);
        card.getStyleClass().add("ai-item-card");
        card.setMaxWidth(Double.MAX_VALUE);
        Runnable refreshCard = () -> {
            boolean present = items.contains(item);
            title.setText(present ? item.title : "Report no longer available");
            status.getChildren().setAll(present ? ("Open".equals(statusOf(item))
                    ? pillLabel("Found".equals(item.type) ? "Available" : "Unresolved", Theme.TINT, Theme.BLUE)
                    : statusChip(item)) : smallGrey("Removed"));
            view.setDisable(!present);
        };
        refreshCard.run();
        aiCardRefreshers.add(refreshCard);
        return card;
    }

    private void addMatchCards(List<Item> hits, String term) {
        VBox cards = new VBox(8);
        cards.setPadding(new Insets(0, 0, 0, 42));
        for (Item item : hits) cards.getChildren().add(aiItemCard(item));
        if (!admin && !term.isBlank()) {
            Button watch = new Button("Notify me about new matches");
            watch.setStyle(smallBtn());
            watch.setOnAction(e -> {
                List<String> watched = myWatch(CurrentUser.getName());
                if (watched.stream().noneMatch(t -> t.equalsIgnoreCase(term))) watched.add(term);
                watch.setText("Watching for new matches");
                watch.setDisable(true);
                refreshWatchBox();
                updateMessagesBadge();
            });
            cards.getChildren().add(watch);
        }
        chatBox.getChildren().add(cards);
    }

    private void showConversationMatches() {
        List<Pair> pairs = collectPairs().stream()
                .filter(p -> "Open".equals(statusOf(p.found)) && "Open".equals(statusOf(p.lost))).toList();
        addBubble(pairs.isEmpty() ? "No possible matches right now. Describe an item to search the available reports."
                : "Possible matches from " + (admin ? "campus reports" : "your reports")
                + ". Staff must verify ownership before release.", false);
        for (Pair pair : pairs.subList(0, Math.min(4, pairs.size()))) {
            VBox result = new VBox(6, smallGrey("Lost report: " + pair.lost.title + " · " + pair.lost.location),
                    aiItemCard(pair.found));
            result.setPadding(new Insets(0, 0, 0, 42));
            chatBox.getChildren().add(result);
        }
        if (pairs.size() > 4) addBubble("Showing the top 4 pairs. Describe a particular item to narrow the results.", false);
    }

    private boolean isAssistantQuestion(String q) {
        return q.startsWith("how ") || q.startsWith("how do") || q.startsWith("what is")
                || q.contains("process") || q.contains("summary") || q.contains("statistic")
                || q.contains("how many") || q.contains("status") || q.contains("my post")
                || q.contains("my report") || q.contains("my claim") || q.contains("claim request")
                || q.equals("help") || q.contains("what can you do") || q.contains("contact admin")
                || q.matches("(hi|hello|hey|thanks|thank you)[!.?]*");
    }

    private void searchInConversation(String query) {
        String wanted = query.toLowerCase().contains("i found") ? "Lost" : "Found";
        Item probe = new Item(wanted.equals("Found") ? "Lost" : "Found", query, "", query, CurrentUser.getName());
        List<Item> hits = matchesFor(probe, items.size()).stream().map(m -> m.other)
                .filter(it -> "Open".equals(statusOf(it))).limit(3).toList();
        addBubble(hits.isEmpty() ? "No available reports match that description yet. Try a brand, color or location."
                : "Here " + (hits.size() == 1 ? "is a possible match" : "are " + hits.size() + " possible matches")
                + ". Check the item details before submitting a claim.", false);
        addMatchCards(hits, wanted.equals("Found") ? query : "");
    }

    private void contactAdminPopup() {
        VBox body = new VBox(8, wrapLabel("Visit the lost and found office with your school ID, or "
                + "send an email to the admin:"));
        for (UserService.Account a : UserService.accounts()) {
            if (a.role.equals("Admin")) {
                Label l = wrapLabel(a.name + "  -  " + a.email);
                l.setStyle("-fx-text-fill: " + DARK + "; -fx-font-weight: bold;");
                body.getChildren().add(l);
            }
        }
        popup("Contact admin", body);
    }

    // Matching results and assistant replies share this one conversation and input.
    private VBox buildChatPanel() {
        chatBox = new VBox(12);
        chatBox.setId("kita-conversation");
        chatBox.setPadding(new Insets(8, 10, 12, 6));
        chatBox.setMinHeight(0);
        chatScroll = new ScrollPane(chatBox);
        chatScroll.setId("kita-chat-scroll");
        chatScroll.setFitToWidth(true);
        chatScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        chatScroll.setMinHeight(80);
        chatBox.heightProperty().addListener((o, a, b) -> chatScroll.setVvalue(1.0));
        VBox.setVgrow(chatScroll, Priority.ALWAYS);

        FlowPane chips = new FlowPane(8, 6);
        chips.setAlignment(Pos.CENTER);
        String[] suggestions = admin
                ? new String[]{"Give me a summary", "Show possible matches", "Review claim requests"}
                : new String[]{"Find my item", "How do I claim?", "My report status"};
        for (String suggestion : suggestions) {
            Button chip = new Button(suggestion);
            chip.getStyleClass().add("ai-prompt");
            chip.setOnAction(e -> {
                if (admin && suggestion.equals("Review claim requests")) showAdminClaims();
                else sendChat(suggestion);
            });
            chips.getChildren().add(chip);
        }
        watchBox = new FlowPane(6, 6);
        watchBox.setId("kita-watchlist");
        watchBox.setMaxHeight(100);
        refreshWatchBox();
        TextField input = new TextField();
        input.setId("kita-input");
        input.setAccessibleText("Describe your item or ask KITA AI");
        input.setPromptText("Describe your lost item or ask KITA AI...");
        input.setStyle("-fx-padding: 11 12;");
        HBox.setHgrow(input, Priority.ALWAYS);
        Button send = new Button("Send");
        send.setId("kita-send");
        send.setStyle(primaryBtn());
        Runnable go = () -> {
            String text = input.getText();
            if (text.isBlank()) return;
            input.clear(); sendChat(text); input.requestFocus();
        };
        input.setOnAction(e -> go.run());
        send.setOnAction(e -> go.run());
        send.disableProperty().bind(input.textProperty().isEmpty());
        HBox composer = new HBox(10, input, send);
        composer.setAlignment(Pos.CENTER);
        composer.setId("kita-composer");
        addBubble("Hi " + firstName() + "! " + (admin
                ? "Ask for report summaries, review possible matches, or describe an item to search."
                : "Describe your lost item, or ask me about reports and claims."), false);
        VBox panel = new VBox(12, chatScroll, watchBox, chips, composer);
        panel.setId("kita-chat-card");
        panel.setMinHeight(0);
        panel.setPadding(new Insets(14));
        panel.setStyle("-fx-background-color: white; -fx-background-radius: 15; "
                + "-fx-border-color: #c7daf8; -fx-border-radius: 15;");
        return panel;
    }

    private String firstName() {
        String me = CurrentUser.getName();
        if (me == null || me.isBlank()) return "there";
        me = me.trim();
        int sp = me.indexOf(' ');
        return sp > 0 ? me.substring(0, sp) : me;
    }

    private void addBubble(String text, boolean mine) {
        Label l = new Label(text);
        l.setWrapText(true);
        l.maxWidthProperty().bind(chatBox.widthProperty().subtract(60).multiply(0.85));
        l.setMinWidth(0);
        l.setStyle("-fx-background-color: " + (mine ? "#1559c8" : "#edf3ff") + "; "
                + "-fx-text-fill: " + (mine ? "white" : "#12366b") + "; "
                + "-fx-background-radius: 17; -fx-padding: 11 15 11 15; -fx-font-size: 13px;");
        HBox row = mine ? new HBox(l) : new HBox(8, aiIcon(30), l);
        row.setAlignment(mine ? Pos.CENTER_RIGHT : Pos.TOP_LEFT);
        chatBox.getChildren().add(row);
    }

    private void sendChat(String text) {
        String query = text == null ? "" : text.trim();
        if (query.isEmpty()) return;
        addBubble(query, true);
        String q = query.toLowerCase();
        if (q.equals("find my item") || q.equals("find matches")) {
            addBubble("Describe the item, including its color, brand and where you lost it. I will show possible matches here.", false);
        } else if (isAssistantQuestion(q)) {
            addBubble(answer(query), false);
        } else if (q.contains("match") && tokens(q).stream().noneMatch(t ->
                items.stream().anyMatch(it -> tokens(it.title).contains(t)))) {
            showConversationMatches();
        } else {
            searchInConversation(query);
        }
        javafx.application.Platform.runLater(() -> chatScroll.setVvalue(1.0));
    }

    private String answer(String raw) {
        String q = raw.toLowerCase().trim();
        Set<String> words = new HashSet<>(Arrays.asList(q.split("[^a-z0-9]+")));
        String me = CurrentUser.getName();

        if (q.contains("help") || q.contains("what can you do")) {
            return "I can help you with:\n"
                    + "- Checking AI matches for your reports\n"
                    + "- Looking up your posts and their status\n"
                    + "- Searching reports (try: \"did anyone find my black wallet?\")\n"
                    + "- Showing the latest lost or found items\n"
                    + "- Explaining how to report a lost item, post a found item and claim an item\n"
                    + "- Explaining the recovery process and checking your claim requests";
        }

        if (words.contains("thanks") || words.contains("thank")) {
            return "You're welcome! Let me know if you need anything else.";
        }

        if (words.size() <= 3 && (words.contains("hi") || words.contains("hello")
                || words.contains("hey"))) {
            return "Hi " + firstName() + "! How can I help you today? You can ask about matches, "
                    + "your posts, or search for an item.";
        }

        if (q.contains("message") || q.contains("chat") || q.contains("contact")) {
            int n = unreadCount(me);
            return "You have " + n + " unread message" + (n == 1 ? "" : "s")
                    + ". Open Chats to read them.\n"
                    + "To contact the person who found your item, click Message finder on their "
                    + "post or in KITA AI. If you found something, click Message owner "
                    + "on the lost post.";
        }

        if (q.contains("my claim") || q.contains("claim status")
                || q.contains("status of my claim")) {
            return myClaimsAnswer();
        }

        if (q.contains("process") || q.contains("recovery") || q.contains("how does it work")
                || q.contains("how it works")) {
            return "The recovery process:\n"
                    + "1. A student reports a lost item, or posts a found item.\n"
                    + "2. KITA AI suggests possible matches (suggestions only).\n"
                    + "3. The owner sends a claim request with proof of ownership.\n"
                    + "4. The admin verifies the proof, then approves or rejects the claim.\n"
                    + "5. If approved, the student brings their school ID to the staff.\n"
                    + "6. At handover, the staff checks the student ID and releases the item. "
                    + "The item is then marked Recovered.";
        }

        if (q.contains("match")) {
            return matchAnswer();
        }

        if (q.contains("summary") || q.contains("statistic") || q.contains("stats")
                || q.contains("how many") || q.contains("dashboard")) {
            return summaryAnswer();
        }

        if (q.contains("my post") || q.contains("my report") || q.contains("my item")
                || q.contains("status")) {
            return myPostsAnswer(me);
        }

        if (words.contains("how") && !q.contains("claim") && (q.contains("report")
                || q.contains("post") || q.contains("submit") || q.contains("lost")
                || q.contains("found"))) {
            boolean forFound = q.contains("found") && !q.contains("lost");
            boolean idItem = words.contains("id") || q.contains("school id");
            if (forFound) {
                return "To post a found item:\n"
                        + "1. Click Report Item and choose Found.\n"
                        + "2. Pick the category, then enter what the item is, where and when you "
                        + "found it, and add a photo.\n"
                        + "3. Do not write secret details (like what is inside), so the real owner "
                        + "can prove it is theirs.\n"
                        + "4. Click Submit Report. The owner can then send a claim request, and the admin "
                        + "verifies ownership before the item is released.";
            }
            if (idItem) {
                return "To report a lost ID:\n"
                        + "1. Click Report Item and choose Lost.\n"
                        + "2. Category: ID / Cards. Item: for example \"School ID\".\n"
                        + "3. Enter where and when you lost it, and add details or a photo if you "
                        + "have one.\n"
                        + "4. Click Submit Report. I will check for possible matches. If a found ID matches, "
                        + "send a claim request so the admin can verify that it is yours.";
            }
            return "To report a lost item:\n"
                    + "1. Click Report Item and choose Lost.\n"
                    + "2. Pick the category, then enter the item name, where and when you lost it, "
                    + "and add a photo if you have one.\n"
                    + "3. Click Submit Report. I will check right away for possible matches.\n"
                    + "4. If a found item matches, click Report a Claim so the admin can verify "
                    + "ownership. (Found items work the same way: just choose Found.)";
        }

        if (q.contains("claim") || q.contains("get it back") || q.contains("retrieve")
                || q.contains("release") || q.contains("handover")) {
            return "To claim a found item:\n"
                    + "1. Find it in Browse Items or KITA AI, open View item, then click Report a Claim.\n"
                    + "2. Describe your proof of ownership (unique marks, what is inside, serial "
                    + "number).\n"
                    + "3. The admin reviews your proof. You can check the status in My Reports > My Claims.\n"
                    + "4. If approved, bring your school ID to the staff. They check that your student "
                    + "ID matches before giving you the item.";
        }

        if ((q.contains("show") || q.contains("list") || q.contains("recent")
                || q.contains("latest")) && (words.contains("lost") || words.contains("found"))) {
            boolean f = words.contains("found");
            boolean l = words.contains("lost");
            return recentAnswer(f && !l ? "Found" : "Lost");
        }

        Set<String> qt = tokens(q);
        if (!qt.isEmpty()) {
            String wantType = null;
            if (q.contains("lost") || q.contains("missing") || q.contains("looking for")
                    || q.contains("can't find") || q.contains("cannot find")
                    || q.contains("cant find")) {
                wantType = "Found";
            } else if (q.contains("i found")) {
                wantType = "Lost";
            }

            List<Match> hits = new ArrayList<>();
            for (Item it : items) {
                if (it.claimed) continue;
                if (wantType != null && !it.type.equals(wantType)) continue;
                Set<String> itemTokens = tokens(it.title + " " + it.description + " " + it.location);
                int inter = 0;
                for (String t : qt) if (itemTokens.contains(t)) inter++;
                int pct = (int) Math.round(100.0 * inter / qt.size());
                if (pct >= 34) hits.add(new Match(it, pct));
            }
            hits.sort((a, b) -> b.pct - a.pct);

            if (!hits.isEmpty()) {
                StringBuilder sb = new StringBuilder("Here is what I found:");
                for (int i = 0; i < Math.min(3, hits.size()); i++) {
                    Item it = hits.get(i).other;
                    sb.append("\n- ").append(it.type).append(": ").append(it.title)
                            .append(" at ").append(it.location)
                            .append(" (reported by ").append(it.reporter).append(")");
                }
                sb.append("\nIf one of these is yours, click Report a Claim and describe your proof of ownership.");
                return sb.toString();
            }
            return "I couldn't find a matching report for that yet. If you lost something, post it "
                    + "with Report Item and I will watch for matches automatically.";
        }

        return "I'm not sure about that. Try asking about matches, your posts, a summary, or how "
                + "to report an item. You can also type what you're looking for, like \"black umbrella\".";
    }

    private String myClaimsAnswer() {
        if (admin) {
            return "There are " + countClaims("Pending") + " claim request(s) waiting for review and "
                    + countClaims("Approved") + " approved claim(s) waiting for handover. "
                    + "Open Claims to review them.";
        }
        String me = CurrentUser.getName();
        List<Claim> mine = new ArrayList<>();
        for (Claim c : claims) {
            if (c.accountId.equalsIgnoreCase(CurrentUser.getStudentId()) && items.contains(c.item)) mine.add(c);
        }
        if (mine.isEmpty()) {
            return "You haven't sent any claim requests yet. If you see your item in Browse Items "
                    + "or KITA AI, click Report a Claim and describe your proof of ownership.";
        }
        StringBuilder sb = new StringBuilder("Your claim requests:");
        for (int i = mine.size() - 1, shown = 0; i >= 0 && shown < 5; i--, shown++) {
            Claim c = mine.get(i);
            sb.append("\n- ").append(c.item.title).append(": ").append(claimLabel(c.status));
            if (c.status.equals("Approved")) {
                sb.append(" - bring your school ID (Student ID ").append(c.studentId).append(") to the staff");
            }
        }
        sb.append("\nOpen My Reports > My Claims for the full details.");
        return sb.toString();
    }

    private String matchAnswer() {
        List<Pair> ps = collectPairs();
        if (ps.isEmpty()) {
            return admin
                    ? "I don't see any possible matches between lost and found reports right now."
                    : "I don't see any possible matches for your reports yet. I check again every "
                    + "time a new report is posted.";
        }
        StringBuilder sb = new StringBuilder(admin
                ? "Top possible matches right now:"
                : "Possible matches for your reports:");
        for (int i = 0; i < Math.min(3, ps.size()); i++) {
            Pair p = ps.get(i);
            sb.append("\n- Lost \"").append(p.lost.title).append("\" (").append(p.lost.location)
                    .append(") <-> Found \"").append(p.found.title).append("\" (")
                    .append(p.found.location).append(") - ").append(p.pct).append("% match");
        }
        sb.append("\nAsk KITA AI to show possible matches. These are only suggestions: "
                + "the admin verifies ownership before an item is released.");
        return sb.toString();
    }

    private String summaryAnswer() {
        int lost = 0, found = 0, claimed = 0;
        for (Item it : items) {
            if (it.type.equals("Lost")) lost++;
            else found++;
            if (it.claimed) claimed++;
        }
        int n = collectPairs().size();
        return "Right now there are " + items.size() + " reports: " + lost + " lost, " + found
                + " found, and " + claimed + " already recovered.\n"
                + "There " + (n == 1 ? "is " : "are ") + n + " possible AI match"
                + (n == 1 ? "" : "es") + (admin ? "" : " for your reports") + ".";
    }

    private String myPostsAnswer(String me) {
        List<Item> mine = new ArrayList<>();
        for (Item it : items) {
            if (it.reporter.equalsIgnoreCase(me)) mine.add(it);
        }
        if (mine.isEmpty()) {
            return "You haven't posted anything yet. Use Report Item and I will look for matches right away.";
        }
        StringBuilder sb = new StringBuilder("You have " + mine.size() + " report"
                + (mine.size() == 1 ? "" : "s") + ":");
        int shown = 0;
        for (int i = mine.size() - 1; i >= 0 && shown < 5; i--, shown++) {
            Item it = mine.get(i);
            sb.append("\n- ").append(it.type).append(": ").append(it.title).append(" - ")
                    .append(statusOf(it).toLowerCase());
            if (!it.claimed) {
                List<Match> m = matchesFor(it, 1);
                if (!m.isEmpty()) {
                    sb.append(" (best AI match: ").append(m.get(0).other.title)
                            .append(", ").append(m.get(0).pct).append("%)");
                }
            }
        }
        return sb.toString();
    }

    private String recentAnswer(String type) {
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (int i = items.size() - 1; i >= 0 && count < 5; i--) {
            Item it = items.get(i);
            if (!it.type.equals(type) || it.claimed) continue;
            sb.append("\n- ").append(it.title).append(" at ").append(it.location)
                    .append(" (reported by ").append(it.reporter).append(")");
            count++;
        }
        if (count == 0) {
            return "There are no active " + type.toLowerCase() + " reports right now.";
        }
        return "Latest " + type.toLowerCase() + " reports:" + sb;
    }

    // =====================================================
    // MESSAGES
    // =====================================================
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("h:mm a");

    static class Message implements java.io.Serializable {
        private static final long serialVersionUID = 1L;
        Item item;
        String inquirer;
        String from;
        String to;
        String text;
        LocalDateTime time = LocalDateTime.now();
        boolean read;

        Message(Item item, String inquirer, String from, String to, String text) {
            this.item = item;
            this.inquirer = inquirer;
            this.from = from;
            this.to = to;
            this.text = text;
        }
    }

    static class Convo {
        Item item;
        String inquirer;
        Message last;
        int unread;

        Convo(Item item, String inquirer) {
            this.item = item;
            this.inquirer = inquirer;
        }
    }

    private static final List<Message> messages = new ArrayList<>();

    /** Complete on-device archive with shared object identity for item-linked claims and chats. */
    private static final class SavedState implements java.io.Serializable {
        private static final long serialVersionUID = 1L;
        final List<Item> savedItems = new ArrayList<>(items);
        final List<Claim> savedClaims = new ArrayList<>(claims);
        final List<Message> savedMessages = new ArrayList<>(messages);
        final List<LogEntry> savedAudit = new ArrayList<>(auditLog);
        final Map<String,String> savedUsers = new LinkedHashMap<>(users);
        final Map<String,LocalDateTime> savedSince = new HashMap<>(userSince);
    }

    private static synchronized void saveState() {
        CampusLocalStore.saveData(new SavedState());
    }

    public static void persist() { saveState(); }

    static {
        Object saved = CampusLocalStore.loadData();
        if (saved instanceof SavedState state) {
            items.setAll(state.savedItems);
            claims.addAll(state.savedClaims);
            messages.addAll(state.savedMessages);
            auditLog.setAll(state.savedAudit);
            users.putAll(state.savedUsers);
            userSince.putAll(state.savedSince);
        }
        items.addListener((javafx.collections.ListChangeListener<Item>) change -> saveState());
    }


    private static List<Message> thread(Item item, String inquirer) {
        List<Message> out = new ArrayList<>();
        for (Message m : messages) {
            if (m.item == item && m.inquirer.equalsIgnoreCase(inquirer)) out.add(m);
        }
        return out;
    }

    private static int unreadCount(String me) {
        int n = 0;
        for (Message m : messages) {
            if (m.to.equalsIgnoreCase(me) && !m.read && items.contains(m.item)) n++;
        }
        return n;
    }

    private static void markRead(Item item, String inquirer, String me) {
        for (Message m : messages) {
            if (m.item == item && m.inquirer.equalsIgnoreCase(inquirer)
                    && m.to.equalsIgnoreCase(me)) {
                m.read = true;
            }
        }
        saveState();
    }

    private static List<Convo> collectConvos(String me) {
        Map<String, Convo> map = new LinkedHashMap<>();
        for (Message m : messages) {
            if (!items.contains(m.item)) continue;
            boolean iAmInquirer = m.inquirer.equalsIgnoreCase(me);
            boolean iAmPoster = m.item.reporter.equalsIgnoreCase(me);
            if (!iAmInquirer && !iAmPoster) continue;

            String key = System.identityHashCode(m.item) + "|" + m.inquirer.toLowerCase();
            Convo c = map.computeIfAbsent(key, k -> new Convo(m.item, m.inquirer));
            c.last = m;
            if (m.to.equalsIgnoreCase(me) && !m.read) c.unread++;
        }
        List<Convo> list = new ArrayList<>(map.values());
        list.sort((a, b) -> b.last.time.compareTo(a.last.time));
        return list;
    }

    private void updateMessagesBadge() {
        String me = CurrentUser.getName();
        int unread = unreadNoticeCount();
        setBadge(notifNav, unread);
        if (bellBadge != null) {
            bellBadge.setText(String.valueOf(unread));
            bellBadge.setVisible(unread > 0);
        }
        setBadge(chatsNav, unreadCount(me));
        if (admin) {
            setBadge(claimsNav, countClaims("Pending"));
        } else {
            setBadge(myNav, approvedCount());
        }
    }

    private static String firstWord(String name) {
        if (name == null || name.isBlank()) return "";
        String n = name.trim();
        int sp = n.indexOf(' ');
        return sp > 0 ? n.substring(0, sp) : n;
    }

    // CampusFind Messenger: a conversation, the messages, and the linked item
    // are shown together inside the regular workspace (not in a modal dialog).
    private Item selectedChatItem;
    private String selectedChatInquirer;

    /** Messenger-style non-blocking notification for an unread conversation. */
    private void showIncomingToast(Convo conversation) {
        String me = CurrentUser.getName();
        String sender = conversation.item.reporter.equalsIgnoreCase(me)
                ? conversation.inquirer : conversation.item.reporter;
        Label title = new Label("New message from " + sender);
        title.setStyle("-fx-font-size: 14px; -fx-text-fill: white; -fx-font-weight: bold;");
        CampusPreferences chatPref = CampusPreferences.current();
        Label preview = new Label(!chatPref.showMessagePreview ? "You have a new message."
                : conversation.last == null ? "Open your chat" : conversation.last.text);
        preview.setMaxWidth(230);
        preview.setWrapText(true);
        preview.setStyle("-fx-text-fill: #e9f2ff; -fx-font-size: 12px;");
        Button open = new Button("Open Chat");
        open.setStyle("-fx-background-color: #ffca23; -fx-background-radius: 13; "
                + "-fx-text-fill: #092b6d; -fx-font-weight: bold; -fx-padding: 8 18;");
        VBox toast = new VBox(7, title, preview, open);
        toast.setPadding(new Insets(15));
        toast.setMaxWidth(270);
        toast.setStyle("-fx-background-color: #082f79; -fx-background-radius: 14; "
                + "-fx-border-color: #ffca23; -fx-border-radius: 14; "
                + "-fx-effect: dropshadow(gaussian, rgba(4,18,43,0.45), 22, 0.12, 0, 5);");
        StackPane.setAlignment(toast, Pos.BOTTOM_RIGHT);
        StackPane.setMargin(toast, new Insets(0, 20, 20, 0));
        open.setOnAction(e -> {
            container.getChildren().remove(toast);
            openChat(conversation.item, conversation.inquirer);
        });
        container.getChildren().add(toast);
        javafx.animation.PauseTransition clear = new javafx.animation.PauseTransition(javafx.util.Duration.seconds(8));
        clear.setOnFinished(e -> container.getChildren().remove(toast));
        clear.play();
    }

    private void openChat(Item item, String inquirer) {
        if (item == null || inquirer == null || item.reporter.equalsIgnoreCase(inquirer)) return;
        selectedChatItem = item;
        selectedChatInquirer = inquirer;
        showMessages();
    }

    private HBox messengerConversationRow(Convo convo, String me, boolean selected) {
        boolean poster = convo.item.reporter.equalsIgnoreCase(me);
        String other = poster ? convo.inquirer : convo.item.reporter;
        Label person = new Label(other);
        person.setStyle("-fx-text-fill: #112e61; -fx-font-weight: bold; -fx-font-size: 13px;");
        Label subject = new Label(convo.item.title);
        subject.setStyle("-fx-text-fill: #426893; -fx-font-size: 11px;");
        String preview = convo.last == null ? "Start a conversation about this item"
                : (convo.last.from.equalsIgnoreCase(me) ? "You: " : "") + convo.last.text;
        if (preview.length() > 42) preview = preview.substring(0, 39) + "...";
        Label snippet = new Label(preview);
        snippet.setStyle("-fx-text-fill: #566a86; -fx-font-size: 11px;");
        VBox text = new VBox(3, person, subject, snippet);
        text.setMinWidth(0);
        HBox.setHgrow(text, Priority.ALWAYS);
        HBox row = new HBox(9, smallAvatar(other, 36), text);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(9));
        row.setStyle("-fx-background-color: " + (selected ? "#ffecac" : "white")
                + "; -fx-background-radius: 10; -fx-border-color: "
                + (selected ? "#ffca23" : "#dde9f8") + "; -fx-border-radius: 10;");
        if (convo.unread > 0) {
            Label count = new Label(String.valueOf(convo.unread));
            count.getStyleClass().add("messenger-unread");
            row.getChildren().add(count);
        }
        row.setCursor(Cursor.HAND);
        row.setOnMouseClicked(e -> openChat(convo.item, convo.inquirer));
        return row;
    }

    private Node messengerItemInfo(Item item) {
        VBox details = new VBox(11);
        details.setPadding(new Insets(15));
        details.getStyleClass().add("messenger-surface");
        details.setPrefWidth(248);
        details.setMinWidth(0);
        Label heading = new Label("Related Item");
        heading.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #0b357c;");
        Label title = new Label(item.title);
        title.setWrapText(true);
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #102e61;");
        StackPane photo = new StackPane(itemPicture(item, 204, 135));
        photo.setStyle("-fx-background-color: #edf4ff; -fx-background-radius: 12;");
        details.getChildren().addAll(heading, photo, title, statusChip(item),
                messengerInfoLine("Category", item.category),
                messengerInfoLine("Location", item.location),
                messengerInfoLine("Reported by", item.reporter),
                messengerInfoLine("Reported", item.date.format(DATE_FMT)));
        Button report = new Button("View Item Details");
        report.setMaxWidth(Double.MAX_VALUE);
        report.setStyle("-fx-background-color: #ffca23; -fx-text-fill: #0c3079; "
                + "-fx-font-weight: bold; -fx-background-radius: 10; -fx-padding: 10;");
        report.setOnAction(e -> showItemDetail(item));
        details.getChildren().add(report);
        return details;
    }

    private Node messengerInfoLine(String key, String value) {
        Label k = new Label(key);
        k.setStyle("-fx-text-fill: #5b7494; -fx-font-size: 11px;");
        Label v = new Label(value == null || value.isBlank() ? "Not specified" : value);
        v.setWrapText(true);
        v.setStyle("-fx-text-fill: #183965; -fx-font-size: 12px; -fx-font-weight: bold;");
        return new VBox(2, k, v);
    }

private Node buildMessagesView() {
    String me = CurrentUser.getName();
    List<Convo> conversations = collectConvos(me);
    Convo selected = null;
    if (selectedChatItem != null && selectedChatInquirer != null && items.contains(selectedChatItem)) {
        for (Convo c : conversations) {
            if (c.item == selectedChatItem && c.inquirer.equalsIgnoreCase(selectedChatInquirer)) {
                selected = c;
                break;
            }
        }
        if (selected == null) selected = new Convo(selectedChatItem, selectedChatInquirer);
    } else {
        selectedChatItem = null;
        selectedChatInquirer = null;
    }
    if (selected == null && !conversations.isEmpty()) selected = conversations.getFirst();
    if (selected != null) {
        selectedChatItem = selected.item;
        selectedChatInquirer = selected.inquirer;
        markRead(selected.item, selected.inquirer, me);
        selected.unread = 0;
        for (Convo c : conversations) {
            if (c.item == selected.item && c.inquirer.equalsIgnoreCase(selected.inquirer))
                c.unread = 0;
        }
        updateMessagesBadge();
    }
    final Convo active = selected;

    // A single Messenger workspace is shared by Admin and Student accounts.
    Label title = new Label("Messages");
    title.setStyle("-fx-text-fill: white; -fx-font-size: 23px; -fx-font-weight: bold;");
    Label subtitle = new Label(admin
            ? "Chat with students about campus lost and found reports"
            : "Chat with students and administrators about your lost and found items");
    subtitle.setWrapText(true);
    subtitle.setStyle("-fx-text-fill: #e8f2ff; -fx-font-size: 12px;");
    StackPane logo = new StackPane(new Group(svg(ICON_CHAT, 26, "#ffca23")));
    logo.setMinSize(44,44); logo.setPrefSize(44,44);
    HBox banner = new HBox(15, logo, new VBox(3,title,subtitle));
    banner.setAlignment(Pos.CENTER_LEFT);
    banner.setPadding(new Insets(13,22,13,20));
    banner.setId("cf-messenger-heading");
    banner.setStyle("-fx-background-color: linear-gradient(to right, #072a72, #0d57b8); "
            + "-fx-background-radius: 16; -fx-border-color: #ffca23; -fx-border-width: 0 0 3 0;");

    Label inboxLabel = new Label("Conversations");
    inboxLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #0c3175;");
    Button newChat = new Button("+ New");
    newChat.setStyle("-fx-background-color: #ffca23; -fx-text-fill: #092d72; "
            + "-fx-background-radius: 10; -fx-font-weight: bold; -fx-padding: 7 10;");
    newChat.setOnAction(e -> { if (admin) showReports(); else showBrowse(); });
    Region inboxSpace = new Region();
    HBox.setHgrow(inboxSpace, Priority.ALWAYS);
    HBox inboxHeader = new HBox(8, inboxLabel, inboxSpace, newChat);
    inboxHeader.setAlignment(Pos.CENTER_LEFT);
    TextField searchInput = new TextField();
    searchInput.setPromptText("Search conversations...");
    searchInput.setStyle("-fx-background-radius: 17; -fx-padding: 10 14; -fx-background-color: #edf4ff; "
            + "-fx-border-color: #cbdcf5; -fx-border-radius: 17; -fx-text-fill: #102f68;");

    VBox threads = new VBox(7);
    String[] activeFilter = {"All"};
    Runnable renderList = () -> {
        threads.getChildren().clear();
        String q = searchInput.getText().strip().toLowerCase();
        List<Convo> options = new ArrayList<>(conversations);
        if (active != null && !options.contains(active)) options.add(0,active);
        for (Convo c : options) {
            boolean poster = c.item.reporter.equalsIgnoreCase(me);
            String other = poster ? c.inquirer : c.item.reporter;
            if (!q.isEmpty() && !other.toLowerCase().contains(q)
                    && !c.item.title.toLowerCase().contains(q)) continue;
            if (activeFilter[0].equals("Unread") && c.unread <= 0) continue;
            if (activeFilter[0].equals("Active") && c.item.claimed) continue;
            if (activeFilter[0].equals("Resolved") && !c.item.claimed) continue;
            threads.getChildren().add(messengerConversationRow(c,me,
                    active != null && active.item == c.item
                            && active.inquirer.equalsIgnoreCase(c.inquirer)));
        }
        if (threads.getChildren().isEmpty()) {
            Label nothing = new Label(conversations.isEmpty() && active == null
                    ? "No conversations yet. Open an item and choose Message Owner or Message Finder to start."
                    : "No conversations match this search or filter.");
            nothing.setWrapText(true);
            nothing.setStyle("-fx-text-fill: #627b9f; -fx-padding: 18 8; -fx-font-size: 12px;");
            threads.getChildren().add(nothing);
        }
    };
    FlowPane filters = new FlowPane(6,6);
    filters.setAlignment(Pos.CENTER_LEFT);
    for (String filter : new String[]{"All", "Unread", "Active", "Resolved"}) {
        Button chip = new Button(filter);
        chip.setStyle("-fx-background-radius: 14; -fx-font-weight: bold; -fx-font-size: 11px; "
                + "-fx-padding: 6 10; -fx-text-fill: " + (filter.equals("All") ? "#072c6c" : "#3d5780")
                + "; -fx-background-color: " + (filter.equals("All") ? "#ffca23" : "#edf4ff") + ";");
        chip.setOnAction(e -> {
            activeFilter[0] = filter;
            for (Node n : filters.getChildren()) if (n instanceof Button b) {
                boolean on = b == chip;
                b.setStyle("-fx-background-radius: 14; -fx-font-weight: bold; -fx-font-size: 11px; "
                        + "-fx-padding: 6 10; -fx-text-fill: " + (on ? "#072c6c" : "#3d5780")
                        + "; -fx-background-color: " + (on ? "#ffca23" : "#edf4ff") + ";");
            }
            renderList.run();
        });
        filters.getChildren().add(chip);
    }
    searchInput.textProperty().addListener((o,a,b)->renderList.run());
    renderList.run();
    ScrollPane listScroller = new ScrollPane(threads);
    listScroller.setMinHeight(0);
    listScroller.setFitToWidth(true);
    listScroller.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
    listScroller.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
    VBox.setVgrow(listScroller,Priority.ALWAYS);
    VBox left = new VBox(11, inboxHeader, searchInput, filters, listScroller);
    left.getStyleClass().add("messenger-surface");
    left.setId("cf-messenger-inbox");
    left.setPadding(new Insets(16));
    left.setPrefWidth(292); left.setMinWidth(230); left.setMaxWidth(325);

    VBox middle = new VBox(10);
    middle.getStyleClass().add("messenger-surface");
    middle.setId("cf-messenger-thread-panel");
    middle.setPadding(new Insets(14));
    middle.setMinWidth(280);
    HBox.setHgrow(middle, Priority.ALWAYS);
    Node itemInfo;
    if (active == null) {
        Label emptyHeader = new Label("Select a conversation");
        emptyHeader.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #0b3279;");
        Node empty = emptyState(ICON_CHAT,"#1559c8","Your conversations appear here",
                "Messages are linked to lost and found reports. Select an item to start a conversation.",
                "Browse Items", admin ? this::showReports : this::showBrowse);
        middle.getChildren().addAll(emptyHeader, empty);
        VBox help = new VBox(11);
        help.getStyleClass().add("messenger-surface");
        help.setPrefWidth(246); help.setMinWidth(210);
        help.setPadding(new Insets(15));
        Label infoHeading = new Label("Item & Conversation Info");
        infoHeading.setWrapText(true);
        infoHeading.setStyle("-fx-font-size: 15px; -fx-text-fill: #0e347a; -fx-font-weight: bold;");
        Label infoCopy = new Label("An item's photo, status, location and report information appear here after you open its chat.");
        infoCopy.setWrapText(true);
        infoCopy.setStyle("-fx-text-fill: #557197; -fx-font-size: 12px;");
        help.getChildren().addAll(premiumIcon(ICON_CLAIM,"#1258b7","#e7f0ff"), infoHeading, infoCopy);
        itemInfo = help;
    } else {
        Item item = active.item;
        String other = item.reporter.equalsIgnoreCase(me) ? active.inquirer : item.reporter;
        Label name = new Label(other);
        name.setStyle("-fx-font-weight: bold; -fx-font-size: 16px; -fx-text-fill: #0b3279;");
        Label topic = new Label("Discussing: " + item.title);
        topic.setStyle("-fx-text-fill: #60799d; -fx-font-size: 11px;");
        VBox identity = new VBox(3, name, topic);
        identity.setMinWidth(0);
        HBox.setHgrow(identity,Priority.ALWAYS);
        Button itemInfoButton = new Button("Item info");
        itemInfoButton.setAccessibleText("Show information about " + item.title);
        itemInfoButton.setStyle("-fx-background-color: #ffca23; -fx-text-fill: #092d70; "
                + "-fx-background-radius: 10; -fx-font-size: 11px; -fx-font-weight: bold;");
        itemInfoButton.setOnAction(e -> popup("Related item", messengerItemInfo(item)));
        Button viewItem = new Button("View item");
        viewItem.setStyle("-fx-background-color: #edf4ff; -fx-text-fill: #0e4eb4; "
                + "-fx-border-color: #c6daf9; -fx-border-radius: 10; -fx-background-radius: 10; "
                + "-fx-font-size: 11px; -fx-font-weight: bold;");
        viewItem.setOnAction(e -> showItemDetail(item));
        HBox contact = new HBox(8, smallAvatar(other, 40), identity, itemInfoButton, viewItem);
        contact.setAlignment(Pos.CENTER_LEFT);
        contact.setPadding(new Insets(8,6,12,6));
        contact.setStyle("-fx-border-color: transparent transparent #dfeafa transparent;");
        VBox bubbles = new VBox(11);
        bubbles.setPadding(new Insets(14));
        ScrollPane history = new ScrollPane(bubbles);
        history.setMinHeight(0);
        history.setFitToWidth(true);
        history.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        history.getStyleClass().add("messenger-thread");
        history.setStyle("-fx-background: #f7faff; -fx-background-color: #f7faff;");
        VBox.setVgrow(history,Priority.ALWAYS);
        bubbles.heightProperty().addListener((o,a,b)->history.setVvalue(1.0));
        Runnable redraw = () -> {
            bubbles.getChildren().clear();
            List<Message> conversation = thread(item,active.inquirer);
            if (conversation.isEmpty()) bubbles.getChildren().add(compactEmptyHint(
                    "Start your conversation with " + other + " about " + item.title + "."));
            for (Message message : conversation) {
                boolean mine = message.from.equalsIgnoreCase(me);
                Label bubble = new Label(message.text);
                bubble.setMaxWidth(385);
                bubble.setWrapText(true);
                bubble.setStyle("-fx-background-color: " + (mine ? "#1559c8" : "#e7effc")
                        + "; -fx-text-fill: " + (mine ? "white" : "#102e61")
                        + "; -fx-background-radius: 17; -fx-padding: 10 14; -fx-font-size: 12px;");
                Label time = new Label(message.time.format(TIME_FMT)
                        + (mine ? (message.read ? "  ·  Seen" : "  ·  Sent") : ""));
                time.setStyle("-fx-text-fill: #637da4; -fx-font-size: 10px;");
                VBox entry = new VBox(4,bubble,time);
                entry.setAlignment(mine ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
                HBox line = new HBox(entry);
                line.setAlignment(mine ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
                bubbles.getChildren().add(line);
            }
        };
        redraw.run();
        TextField composer = new TextField();
        composer.setPromptText("Type a message...");
        composer.setStyle("-fx-background-color: #f8fbff; -fx-border-color: #b9d2f3; "
                + "-fx-background-radius: 18; -fx-border-radius: 18; -fx-padding: 11 14;");
        HBox.setHgrow(composer,Priority.ALWAYS);
        Button send = new Button("Send");
        send.setStyle("-fx-background-color: #1559c8; -fx-text-fill: white; "
                + "-fx-font-weight: bold; -fx-background-radius: 16; -fx-padding: 11 19;");
        Runnable transmit = () -> {
            String text = composer.getText().strip();
            if (text.isEmpty()) return;
            Message posted = new Message(item,active.inquirer,me,other,text);
            messages.add(posted);
            active.last = posted;
            for (Convo c : conversations) {
                if (c.item == item && c.inquirer.equalsIgnoreCase(active.inquirer)) c.last = posted;
            }
            saveState();
            composer.clear();
            redraw.run();
            renderList.run();
            updateMessagesBadge();
        };
        composer.setOnAction(e -> transmit.run());
        send.setOnAction(e -> transmit.run());
        HBox inputRow = new HBox(9,composer,send);
        inputRow.setAlignment(Pos.CENTER_LEFT);
        inputRow.setPadding(new Insets(9,0,1,0));
        middle.getChildren().addAll(contact,history,inputRow);
        itemInfo = messengerItemInfo(item);
    }
    ScrollPane itemScroller = new ScrollPane(itemInfo);
    itemScroller.setFitToWidth(true);
    itemScroller.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
    itemScroller.setMinSize(0, 0);
    itemScroller.setPrefWidth(245);
    itemScroller.setMaxWidth(260);
    itemScroller.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
    HBox split = new HBox(10,left,middle,itemScroller);
    split.setMinHeight(0);
    split.setPrefHeight(460);
    split.setMaxWidth(Double.MAX_VALUE);
    left.setMinHeight(0);
    middle.setMinHeight(0);
    split.getStyleClass().add("cf-v2-messenger-split");
    // Keep a readable two-column conversation on smaller laptop windows.
    itemScroller.visibleProperty().bind(split.widthProperty().greaterThan(865));
    itemScroller.managedProperty().bind(itemScroller.visibleProperty());
    VBox screen = new VBox(11,banner,split);
    screen.setMinWidth(0);
    screen.setMinHeight(0);
    VBox.setVgrow(split, Priority.ALWAYS);
    ScrollPane page = pageOf(screen);
    page.setId("campusfind-messenger");
    page.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
    Runnable fit = () -> split.setPrefHeight(Math.max(290,
            page.getViewportBounds().getHeight() - 174));
    page.viewportBoundsProperty().addListener((o,old,value)->fit.run());
    fit.run();
    return page;
}

        private static ImageView photoView(Image img, double w, double h) {
        ImageView v = new ImageView(img);
        v.setFitWidth(w);
        v.setFitHeight(h);
        v.setPreserveRatio(false);

        double iw = img.getWidth();
        double ih = img.getHeight();
        double target = w / h;
        double vw = iw;
        double vh = ih;
        if (iw / ih > target) vw = ih * target;
        else vh = iw / target;
        v.setViewport(new Rectangle2D((iw - vw) / 2, (ih - vh) / 2, vw, vh));

        Rectangle clip = new Rectangle(w, h);
        clip.setArcWidth(16);
        clip.setArcHeight(16);
        v.setClip(clip);
        return v;
    }

    private StackPane smallAvatar(String name, double size) {
        Circle circle = new Circle(size / 2, Color.web(Theme.BLUE));
        String letter = (name == null || name.isBlank())
                ? "?" : name.trim().substring(0, 1).toUpperCase();
        Label l = new Label(letter);
        l.setStyle("-fx-text-fill: -cf-on-accent; -fx-font-weight: bold; -fx-font-size: "
                + (size * 0.42) + "px;");
        StackPane p = new StackPane(circle, l);
        p.setMinSize(size, size);
        p.setPrefSize(size, size);
        p.setMaxSize(size, size);
        return p;
    }

    // =====================================================
    // MY POSTS (shown inside the profile popup)
    // =====================================================
    private Node buildMyPosts(Runnable onChange) {
        String me = CurrentUser.getName();

        int total = 0, lost = 0, found = 0, claimed = 0;
        VBox list = new VBox(8);

        for (int i = items.size() - 1; i >= 0; i--) {
            Item it = items.get(i);
            if (!it.reporter.equalsIgnoreCase(me)) continue;

            total++;
            if (it.type.equals("Lost")) lost++;
            else found++;
            if (it.claimed) claimed++;

            list.getChildren().add(buildMyPostRow(it, onChange));
        }

        Label summary = new Label("Total: " + total + "   Lost: " + lost
                + "   Found: " + found + "   Recovered: " + claimed);
        summary.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: 12px;");

        VBox box = new VBox(10, summary);
        if (total == 0) {
            Label none = new Label("You haven't posted anything yet.");
            none.setStyle("-fx-text-fill: " + GREY_TEXT + ";");
            box.getChildren().add(none);
        } else {
            box.getChildren().add(list);
        }
        return box;
    }

    private VBox buildMyPostRow(Item it, Runnable onChange) {
        boolean isLost = it.type.equals("Lost");

        Label badge = new Label(it.type);
        badge.setStyle("-fx-background-color: " + (isLost ? "#fee2e2" : "#dcfce7") + "; "
                + "-fx-text-fill: " + (isLost ? "#b91c1c" : "#15803d") + "; "
                + "-fx-font-weight: bold; -fx-background-radius: 10; -fx-padding: 2 10 2 10;");

        Label status = statusChip(it);

        HBox top = new HBox(8, badge, status);
        top.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label(it.title);
        title.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + DARK + ";");

        Label loc = new Label("Location: " + it.location);
        loc.setStyle("-fx-text-fill: -cf-muted; -fx-font-size: 12px;");

        VBox row = new VBox(4, top, title, loc);
        if (it.photo != null) row.getChildren().add(photoView(it.photo, 360, 110));

        HBox actions = new HBox(8);
        if (!it.claimed && isLost) {
            Button claim = new Button("Mark as recovered");
            claim.setStyle("-fx-background-color: " + Theme.BLUE + "; -fx-text-fill: -cf-on-accent; "
                    + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-cursor: hand;");
            claim.setOnAction(e -> {
                markRecovered(it);
                refresh();
                onChange.run();
            });
            actions.getChildren().add(claim);
        }

        Button delete = new Button("Delete post");
        delete.setStyle("-fx-background-color: -cf-soft; -fx-text-fill: -cf-danger; "
                + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-cursor: hand;");
        delete.setOnAction(e -> {
            deleteItem(it);
            refresh();
            onChange.run();
        });
        actions.getChildren().add(delete);

        row.getChildren().add(actions);
        row.setPadding(new Insets(10));
        row.setStyle("-fx-background-color: -cf-soft; -fx-background-radius: 10;");
        return row;
    }

    private void openReportDialog() {
        showReport();
    }
}

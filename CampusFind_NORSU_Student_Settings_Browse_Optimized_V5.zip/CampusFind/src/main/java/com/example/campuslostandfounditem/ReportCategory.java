package com.example.campuslostandfounditem;

import java.util.Locale;

/** Item words determine the category and a question the finder can answer offline. */
enum ReportCategory {
    CARDS("ID / Cards", "What are the last four characters of the card number, kept hidden in the photo?", "id|badge|card|cards|identification"),
    WALLET("Wallet / Money", "What identifying detail is inside the wallet?", "wallet|purse|coin purse"),
    GADGET("Phone / Gadget", "What private engraving or serial-number suffix identifies the device?", "gadget|electronics|device"),
    KEYS("Keys", "What code or marking is on the reverse of a key, hidden in the photo?", "keys|key|keychain|keyring"),
    BAG("Bag", "What is inside one of the bag’s pockets?", "bag|backpack|rucksack|handbag|satchel"),
    CLOTHING("Clothing", "What is written on the inside label?", "clothing|jacket|uniform|sweater|shirt|hoodie|coat"),
    SUPPLIES("School Supplies", "What personal marking is inside the item or hidden under its cover?", "school supplies|stationery"),
    BOTTLES("Bottles & Tumblers", "What marking is on the bottom of the bottle or tumbler?",
            "bottle|bottles|tumbler|tumblers|flask|thermos|drinkware"),
    UMBRELLAS("Umbrellas", "What marking is inside the umbrella canopy?", "umbrella|umbrellas|parasol|payong"),
    EYEWEAR("Eyewear", "What is printed inside one arm of the glasses?", "glasses|eyeglasses|sunglasses|spectacles|eyewear|salamin"),
    OTHER("Other", "What identifying detail is hidden from view?", "miscellaneous");

    final String label;
    private final String question;
    private final String words;

    ReportCategory(String label, String question, String words) {
        this.label = label;
        this.question = question;
        this.words = words;
    }

    private record ItemRule(ReportCategory category, String words, String question) {}

    // Recognize compound item names before their individual words.
    private static final ItemRule[] RULES = {
            new ItemRule(SUPPLIES, "pencil case|pen case", "What is inside the pencil case?"),
            new ItemRule(BAG, "laptop bag|laptop backpack|camera bag", "What is inside one of the bag’s pockets?"),
            new ItemRule(GADGET, "phone case", "What marking is on the inside of the phone case?"),
            new ItemRule(EYEWEAR, "glasses case|eyeglass case", "What color is the lining inside the glasses case?"),
            new ItemRule(GADGET, "charger|adapter|power bank", "What are the last four characters of its serial number, kept hidden in the photo?"),
            new ItemRule(GADGET, "phone|iphone|smartphone|cellphone|mobile|tablet|ipad", "What image is on the lock screen?"),
            new ItemRule(GADGET, "laptop|computer", "What are the last four characters of the laptop serial number, kept hidden in the photo?"),
            new ItemRule(GADGET, "earbuds|earphones|headphones", "What private marking is inside the case or under the ear cushion?"),
            new ItemRule(SUPPLIES, "notebook|journal|book|planner", "What is written inside the cover?"),
            new ItemRule(SUPPLIES, "pen|pencil|marker", "What personal marking is inside the cap or hidden under the grip?"),
            new ItemRule(WALLET, "cash|money|coins", "Which denominations were in the group of notes or coins?")
    };

    private static String normalize(String text) {
        return text.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").strip();
    }

    private static boolean containsWord(String paddedName, String words) {
        for (String word : words.split("\\|")) {
            if (paddedName.contains(" " + word + " ")) return true;
        }
        return false;
    }

    static ReportCategory infer(String name) {
        String text = " " + normalize(name) + " ";
        for (ItemRule rule : RULES) if (containsWord(text, rule.words)) return rule.category;
        for (ReportCategory category : values()) if (containsWord(text, category.words)) return category;
        return null;
    }

    static String questionFor(String name, ReportCategory category) {
        if (category == null) return name.isBlank() ? "" : OTHER.question;
        String text = " " + normalize(name) + " ";
        for (ItemRule rule : RULES) {
            if (rule.category == category && containsWord(text, rule.words)) return rule.question;
        }
        return category.question;
    }

    static boolean answerAppearsPublic(String answer, String publicText) {
        String normalized = normalize(answer);
        return !normalized.isEmpty() && (" " + normalize(publicText) + " ").contains(" " + normalized + " ");
    }

    boolean matches(String search) {
        String query = normalize(search);
        if (normalize(label + " " + words).contains(query)) return true;
        for (ItemRule rule : RULES) {
            if (rule.category == this && normalize(rule.words).contains(query)) return true;
        }
        return false;
    }
}

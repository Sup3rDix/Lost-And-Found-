package com.example.campuslostandfounditem;

import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;

import java.io.File;
import java.util.function.Function;

public class profileui {

    private static final String DARK_TEXT = "-cf-ink";

    // main.java gives us a function that builds the "My posts" list.
    // The Runnable it receives must be called after a change (claim / delete)
    // so this popup redraws itself.
    private static Function<Runnable, Node> postsProvider;

    public static void setPostsProvider(Function<Runnable, Node> provider) {
        postsProvider = provider;
    }

    /** Round avatar: shows the profile picture, or the first letter of the name. */
    public static StackPane avatar(double size) {
        Circle bg = new Circle(size / 2, Color.web(Theme.BLUE));

        Label initial = new Label();
        initial.setStyle("-fx-text-fill: -cf-on-accent; -fx-font-weight: bold; -fx-font-size: "
                + (size * 0.4) + "px;");
        initial.textProperty().bind(Bindings.createStringBinding(
                CurrentUser::getInitial, CurrentUser.nameProperty()));

        ImageView pic = new ImageView();
        pic.setFitWidth(size);
        pic.setFitHeight(size);
        pic.setClip(new Circle(size / 2, size / 2, size / 2));

        Runnable refresh = () -> {
            Image img = CurrentUser.getPhoto();
            if (img == null) {
                pic.setImage(null);
                pic.setVisible(false);
                initial.setVisible(true);
            } else {
                cropToSquare(pic, img);
                pic.setVisible(true);
                initial.setVisible(false);
            }
        };
        CurrentUser.photoProperty().addListener((o, a, b) -> refresh.run());
        refresh.run();

        StackPane box = new StackPane(bg, initial, pic);
        box.setMinSize(size, size);
        box.setPrefSize(size, size);
        box.setMaxSize(size, size);
        return box;
    }

    /** Makes any node (avatar, name label...) open the profile popup when clicked. */
    public static void openOnClick(Node node) {
        node.setCursor(Cursor.HAND);
        node.setOnMouseClicked(e -> openProfile(node.getScene().getWindow()));
    }

    /** Profile popup: big avatar, name, change / remove profile picture. */
    public static void openProfile(Window owner) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.initStyle(StageStyle.TRANSPARENT);

        Label title = new Label("Your profile");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + DARK_TEXT + ";");

        StackPane bigAvatar = avatar(110);

        Label name = new Label();
        name.textProperty().bind(CurrentUser.nameProperty());
        name.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: " + DARK_TEXT + ";");

        Label role = new Label(CurrentUser.isAdmin() ? "Admin" : "Student");
        role.setStyle("-fx-font-size: 13px; -fx-text-fill: -cf-muted;");

        Button change = new Button("Change profile picture");
        change.setMaxWidth(Double.MAX_VALUE);
        change.setStyle(btn(Theme.BLUE, Theme.onAccent));
        change.setOnAction(e -> {
            FileChooser fc = new FileChooser();
            fc.setTitle("Choose a profile picture");
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter(
                    "Images", "*.png", "*.jpg", "*.jpeg", "*.gif"));
            File file = fc.showOpenDialog(dialog);
            if (file != null) {
                if (file.length() > 5_000_000L) {
                    new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR,
                            "Choose a profile image smaller than 5 MB.").showAndWait();
                    return;
                }
                Image img = new Image(file.toURI().toString(), 512, 512, true, true);
                if (!img.isError()) {
                    try {
                        String stored = CampusLocalStore.keepPhoto(file);
                        CurrentUser.setPhoto(new Image(stored, 512, 512, true, true));
                    } catch (java.io.IOException ex) {
                        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                                javafx.scene.control.Alert.AlertType.ERROR, "Unable to save the profile photo: " + ex.getMessage());
                        alert.showAndWait();
                    }
                }
            }
        });

        Button remove = new Button("Remove photo");
        remove.setMaxWidth(Double.MAX_VALUE);
        remove.setStyle(btn("-cf-soft", DARK_TEXT));
        remove.setOnAction(e -> CurrentUser.setPhoto(null));

        Button close = new Button("Close");
        close.setCancelButton(true);
        close.setMaxWidth(Double.MAX_VALUE);
        close.setStyle(btn("-cf-soft", DARK_TEXT));
        close.setOnAction(e -> dialog.close());

        HBox photoButtons = new HBox(10, change, remove);
        HBox.setHgrow(change, javafx.scene.layout.Priority.ALWAYS);
        HBox.setHgrow(remove, javafx.scene.layout.Priority.ALWAYS);

        // ---------- My posts (so the person can monitor their own reports) ----------
        Label postsTitle = new Label("My posts");
        postsTitle.setMaxWidth(Double.MAX_VALUE);
        postsTitle.setAlignment(Pos.CENTER_LEFT);
        postsTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: "
                + DARK_TEXT + ";");

        VBox postsBox = new VBox(8);
        Runnable[] rebuild = new Runnable[1];
        rebuild[0] = () -> {
            postsBox.getChildren().clear();
            if (postsProvider != null) {
                postsBox.getChildren().add(postsProvider.apply(rebuild[0]));
            }
        };
        rebuild[0].run();

        ScrollPane postsScroll = new ScrollPane(postsBox);
        postsScroll.setFitToWidth(true);
        postsScroll.setPrefHeight(240);
        postsScroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        VBox box = new VBox(10, title, bigAvatar, name, role, photoButtons,
                new Separator(), postsTitle, postsScroll, close);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(24));
        box.setPrefWidth(470);
        box.setStyle("-fx-background-color: -cf-panel; -fx-background-radius: 12; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.35), 18, 0, 0, 4);");
        VBox.setMargin(photoButtons, new Insets(8, 0, 0, 0));

        StackPane wrapper = new StackPane(box);
        wrapper.setPadding(new Insets(20));
        wrapper.setStyle("-fx-background-color: transparent;");

        CampusStyle.install(wrapper);
        Scene scene = new Scene(wrapper);
        scene.setFill(Color.TRANSPARENT);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private static String btn(String bg, String fg) {
        return "-fx-background-color: " + bg + "; -fx-text-fill: " + fg + "; "
                + "-fx-font-weight: bold; -fx-background-radius: 6; "
                + "-fx-padding: 8 16 8 16; -fx-cursor: hand;";
    }

    // crops any picture to a centered square so it never looks stretched
    private static void cropToSquare(ImageView view, Image img) {
        double w = img.getWidth();
        double h = img.getHeight();
        double side = Math.min(w, h);
        view.setImage(img);
        view.setViewport(new Rectangle2D((w - side) / 2, (h - side) / 2, side, side));
    }
}
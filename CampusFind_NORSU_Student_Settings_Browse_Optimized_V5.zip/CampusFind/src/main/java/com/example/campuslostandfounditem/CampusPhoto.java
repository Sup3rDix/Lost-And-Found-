package com.example.campuslostandfounditem;

import java.io.IOException;
import java.util.function.Consumer;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

/** A device-wide photo is available on the login screen, before an account is known. */
final class CampusPhoto extends Region {
    private static final java.util.Map<PhotoChoice, Image> images = new java.util.EnumMap<>(PhotoChoice.class);
    private static PhotoChoice selected = PhotoChoice.load();
    private final ImageView picture = new ImageView();
    private PhotoChoice choice;

    CampusPhoto() { this(selected); }

    CampusPhoto(PhotoChoice initial) {
        picture.setManaged(false);
        picture.setSmooth(true);
        picture.setMouseTransparent(true);
        getChildren().add(picture);
        setStyle("-fx-background-color: #062a72;");
        setMinSize(0, 0);
        display(initial);
    }

    private void display(PhotoChoice selection) {
        choice = selection;
        picture.setImage(images.computeIfAbsent(selection,
                option -> new Image(CampusPhoto.class.getResource(option.filename).toExternalForm())));
        requestLayout();
    }

    @Override protected void layoutChildren() {
        double w = getWidth(), h = getHeight();
        Image image = picture.getImage();
        if (w <= 0 || h <= 0 || image == null || image.getWidth() <= 0 || image.getHeight() <= 0) return;
        var crop = choice.framing.fit(image.getWidth(), image.getHeight(), w, h);
        picture.setViewport(new Rectangle2D(crop.x(), crop.y(), crop.width(), crop.height()));
        picture.setFitWidth(crop.displayWidth());
        picture.setFitHeight(crop.displayHeight());
        picture.relocate((w - crop.displayWidth()) / 2, (h - crop.displayHeight()) / 2);
    }

    Button changeButton() { return changeButton(new CampusPhoto[0]); }

    Button changeButton(CampusPhoto... linkedLayers) {
        Button button = new Button("Change photo");
        button.getStyleClass().add("photo-action");
        button.setAccessibleText("Choose campus background photo");
        button.setOnAction(e -> choose(button.getScene().getWindow(), selection -> {
            display(selection);
            for (CampusPhoto linked : linkedLayers) linked.display(selection);
        }));
        return button;
    }

    private static void choose(Window owner, Consumer<PhotoChoice> onPick) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.setTitle("Campus photo");
        Label title = new Label("Choose a campus photo");
        title.getStyleClass().add("editorial-title");
        Label hint = new Label("Shown on sign-in and student Home on this computer.");
        hint.setWrapText(true);
        Label error = new Label();
        error.setWrapText(true);
        error.setManaged(false);
        error.setStyle("-fx-text-fill: -cf-danger;");
        FlowPane options = new FlowPane(12, 12);
        for (PhotoChoice option : PhotoChoice.values()) {
            CampusPhoto thumb = new CampusPhoto(option);
            thumb.setPrefSize(192, 124);
            Label name = new Label(option.title);
            name.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");
            Label status = new Label(option == selected ? "✓ Current photo" : "Use this photo");
            VBox content = new VBox(6, thumb, name, status);
            Button card = new Button();
            card.setGraphic(content);
            card.setAccessibleText(option.title + (option == selected ? ", current photo" : ""));
            card.getStyleClass().add("photo-choice");
            if (option == selected) card.getStyleClass().add("current-photo");
            card.setOnAction(e -> {
                if (option != selected) {
                    try {
                        option.save();
                    } catch (IOException | SecurityException ex) {
                        error.setText("The photo could not be saved. Check that your user folder is writable.");
                        error.setManaged(true);
                        return;
                    }
                    selected = option;
                }
                onPick.accept(option);
                dialog.close();
            });
            options.getChildren().add(card);
        }
        Button close = new Button("Cancel");
        close.setCancelButton(true);
        close.setOnAction(e -> dialog.close());
        VBox body = new VBox(12, title, hint, options, error, close);
        body.setPadding(new Insets(20));
        body.setAlignment(Pos.TOP_LEFT);
        ScrollPane scroll = new ScrollPane(body);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: -cf-bg;");
        CampusStyle.install(scroll);
        dialog.setScene(new Scene(scroll, Math.min(530, owner.getWidth() - 32), Math.min(590, owner.getHeight() - 48)));
        dialog.showAndWait();
    }
}

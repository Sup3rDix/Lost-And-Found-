package com.example.campuslostandfounditem;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.AtomicMoveNotSupportedException;

enum PhotoChoice {
    NORSU("NORSU main building", "norsu-main-building.png", new PhotoFraming(.30, .06, .70, .72)),
    BENCH("Campus bench", "campus.jpg", new PhotoFraming(.42, .36, .85, .94)),
    LIBRARY("Library study table", "library.jpg", new PhotoFraming(.30, .30, .70, .82)),
    COURTYARD("Rainy courtyard", "courtyard.jpg", new PhotoFraming(.30, .35, .70, .81));

    final String title;
    final String filename;
    final PhotoFraming framing;
    private static final Path SETTING = Path.of(System.getProperty("user.home"), ".campusfind-photo-norsu-blue");

    PhotoChoice(String title, String filename, PhotoFraming framing) {
        this.title = title;
        this.filename = filename;
        this.framing = framing;
    }

    static PhotoChoice load() {
        try {
            return PhotoChoice.valueOf(Files.readString(SETTING).trim());
        } catch (IOException | IllegalArgumentException | SecurityException ignored) {
            return NORSU;
        }
    }

    void save() throws IOException {
        Path tmp = Files.createTempFile(SETTING.getParent(), ".campusfind-photo-", ".tmp");
        try {
            Files.writeString(tmp, name());
            try {
                Files.move(tmp, SETTING, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException | FileAlreadyExistsException ex) {
                Files.move(tmp, SETTING, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

}

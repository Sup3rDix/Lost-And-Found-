package com.example.campuslostandfounditem;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.image.Image;

import java.util.HashMap;
import java.util.Map;

/**
 * Remembers who is logged in (name + profile picture).
 * Uses JavaFX properties so every screen updates automatically
 * when the name or photo changes.
 */
public class CurrentUser {

    private static final StringProperty name = new SimpleStringProperty("");
    private static final ObjectProperty<Image> photo = new SimpleObjectProperty<>();
    private static boolean admin = false;

    // keeps each person's photo while the app is open (even after log out / log in)
    private static final Map<String, Image> savedPhotos = new HashMap<>();

    public static void set(String fullName, boolean isAdmin) {
        name.set(fullName);
        admin = isAdmin;
        photo.set(savedPhotos.get(fullName.toLowerCase()));
    }

    public static String getName() { return name.get(); }
    public static StringProperty nameProperty() { return name; }

    public static boolean isAdmin() { return admin; }

    public static Image getPhoto() { return photo.get(); }
    public static ObjectProperty<Image> photoProperty() { return photo; }

    public static void setPhoto(Image img) {
        photo.set(img);
        String key = name.get().toLowerCase();
        if (img == null) savedPhotos.remove(key);
        else savedPhotos.put(key, img);
        if (!studentId.isBlank()) {
            UserService.updatePhoto(studentId, img == null ? "" : img.getUrl());
        }
    }

    // first letter of the name, shown inside the avatar when there is no photo
    public static String getInitial() {
        String n = name.get();
        return (n == null || n.isBlank()) ? "?" : n.trim().substring(0, 1).toUpperCase();
    }

    // the student ID and email of the account that is logged in (used for claims)
    private static String studentId = "";
    private static String email = "";

    public static void setProfile(String id, String mail) {
        studentId = id == null ? "" : id;
        email = mail == null ? "" : mail;
        UserService.Account a = UserService.findById(studentId);
        if (a != null && a.photoUri != null && !a.photoUri.isBlank()) {
            try { photo.set(new Image(a.photoUri, 256, 256, true, true, false)); }
            catch (RuntimeException ex) { photo.set(null); }
        }
    }

    public static String getStudentId() { return studentId; }
    public static String getEmail() { return email; }

    public static void updateIdentity(String fullName, String mail) {
        name.set(fullName);
        email = mail;
    }

    public static void clear() {
        name.set("");
        photo.set(null);
        admin = false;
        studentId = "";
        email = "";
    }
}
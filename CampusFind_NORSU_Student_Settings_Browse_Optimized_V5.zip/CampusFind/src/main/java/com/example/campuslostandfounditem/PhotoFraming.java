package com.example.campuslostandfounditem;

/** Keeps an important part of a photograph visible across different panel shapes. */
record PhotoFraming(double left, double top, double right, double bottom) {
    record Crop(double x, double y, double width, double height, double displayWidth, double displayHeight) {}

    Crop fit(double sourceWidth, double sourceHeight, double panelWidth, double panelHeight) {
        double cover = Math.max(panelWidth / sourceWidth, panelHeight / sourceHeight);
        double subjectWidth = (right - left) * sourceWidth;
        double subjectHeight = (bottom - top) * sourceHeight;
        double scale = Math.min(cover, Math.min(panelWidth / subjectWidth, panelHeight / subjectHeight));

        double width = Math.min(sourceWidth, panelWidth / scale);
        double height = Math.min(sourceHeight, panelHeight / scale);
        double centerX = sourceWidth * (left + right) / 2;
        double centerY = sourceHeight * (top + bottom) / 2;
        double x = Math.clamp(centerX - width / 2, 0, sourceWidth - width);
        double y = Math.clamp(centerY - height / 2, 0, sourceHeight - height);
        return new Crop(x, y, width, height, width * scale, height * scale);
    }
}

package com.example.campuslostandfounditem;

// Starts the app. It must NOT extend Application, so the packaged jar/exe can start.
public class Launcher {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
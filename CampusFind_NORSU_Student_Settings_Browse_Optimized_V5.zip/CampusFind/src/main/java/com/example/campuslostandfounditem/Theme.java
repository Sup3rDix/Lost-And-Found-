package com.example.campuslostandfounditem;


/** Fixed NORSU-inspired blue, white and yellow styling shared by student and admin screens. */
public class Theme {
    public static final String DEFAULT = "#1559c8";
    public static String selected = DEFAULT;
    public static boolean dark = false;
    public static String ink, muted, panel, canvas, edge, onAccent;
    /** name + color of the ready-made themes */
    public static final String[][] PRESETS = {
            {"Emerald", DEFAULT},
            {"Gold", "#92732d"},
            {"Sky Blue", "#1877f2"},
            {"Pink", "#ec4899"},
            {"Green", "#16a34a"},
            {"Purple", "#7c3aed"},
            {"Orange", "#ea580c"},
            {"Teal", "#0e9aa7"},
            {"Red", "#dc2626"},
            {"Navy", "#1e40af"}
    };

    public static String NAME = "NORSU Blue";
    public static String BLUE = DEFAULT;        // main color: buttons, highlights
    public static String BLUE_DARK;             // buttons when the mouse is over them
    public static String SIDE_TOP;              // top of the sidebar / side panels
    public static String BANNER_END;            // end of the welcome banner
    public static String TINT;                  // very light color for chips and icon bubbles
    public static String TINT_SOFT;             // even lighter
    public static String TINT_HOVER;
    public static String TINT_LINE;             // light lines and borders

    static {
        apply(DEFAULT);
    }

    /** Nobody is logged in (login pages) or the person logged out: the default theme. */
    public static void useDefault() {
        dark = false;
        apply(DEFAULT);
    }

    /** All users share the same fixed Emerald appearance. */
    public static void loadFor(String accountId) {
        useDefault();
    }

    private static void apply(String hex) {
        selected = hex;
        ink = "#12294a";
        muted = "#566a86";
        panel = "#ffffff";
        canvas = "#f1f6ff";
        edge = "#ccdbf0";
        // Keep the actual swatch intact. Adjust the display tone on each surface
        // so links, navigation icons and small type work for custom colors too.
        BLUE = readable(hex, panel);
        onAccent = foreground(BLUE);
        BLUE_DARK = mix(BLUE, ink, 0.10);
        SIDE_TOP = "#062a72";
        BANNER_END = "#0954b7";
        TINT = mix(BLUE, panel, 0.82);
        TINT_SOFT = mix(BLUE, panel, 0.90);
        TINT_HOVER = mix(BLUE, panel, 0.74);
        TINT_LINE = mix(BLUE, panel, 0.55);
        NAME = "NORSU Blue";

    }

    private static double linear(double value) {
        return value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
    }

    private static double luminance(String hex) {
        int color = rgb(hex);
        return 0.2126 * linear(channel(color, 16) / 255.0)
                + 0.7152 * linear(channel(color, 8) / 255.0)
                + 0.0722 * linear(channel(color, 0) / 255.0);
    }

    static double contrast(String a, String b) {
        double x = luminance(a), y = luminance(b);
        return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
    }

    static String foreground(String background) {
        return contrast("#ffffff", background) > contrast("#090812", background) ? "#ffffff" : "#090812";
    }

    static String readable(String color, String background) {
        String endpoint = foreground(background);
        for (int step = 0; step <= 20; step++) {
            String tone = mix(color, endpoint, step / 20.0);
            if (contrast(tone, background) >= 4.6) return tone;
        }
        return endpoint;
    }

    private static int rgb(String hex) {
        return Integer.parseInt(hex.substring(1), 16);
    }

    private static int channel(int color, int shift) {
        return (color >> shift) & 255;
    }

    /** Interpolate two six-digit RGB colors. */
    public static String mix(String a, String b, double amount) {
        int start = rgb(a), end = rgb(b), result = 0;
        for (int shift : new int[]{16, 8, 0}) {
            int first = channel(start, shift);
            int last = channel(end, shift);
            result |= (int) Math.round(first + (last - first) * amount) << shift;
        }
        return String.format("#%06x", result);
    }
}

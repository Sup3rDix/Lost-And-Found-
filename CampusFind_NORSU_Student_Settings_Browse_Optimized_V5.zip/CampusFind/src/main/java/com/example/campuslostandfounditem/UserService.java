package com.example.campuslostandfounditem;

import java.io.Serializable;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.util.Base64;
import java.util.Arrays;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Keeps accounts in local storage between application sessions.
 *
 * Built-in admin:   ID "admin"   password "admin123"   email "admin@campus.edu"
 * To register another ADMIN account the person must type the admin access code below.
 *
 * New student registration asks for program and year level, not graduation year.
 * Legacy accounts may still have a graduation year for the existing account policy.
 */
public class UserService {

    public static final String ADMIN_CODE = "NORSU-BSC-LF26";

    /** how many years after graduation a student account may be deleted */
    public static final int GAP_YEARS = 3;

    public static class Account implements Serializable {
        private static final long serialVersionUID = 1L;
        public final String role;          // "Student" or "Admin"
        public String name;
        public final String studentId;     // for the admin: the admin ID
        public String email;
        public String password;            // can be changed (forgot password)
        public final int gradYear;         // expected year of graduation, retained for account policies
        public String program = "";
        public String phone = "";
        public String section = "";
        public String photoUri = "";
        public LocalDateTime updated = LocalDateTime.now();
        public int yearLevel = 0;         // 1 to 5, displayed in the student profile
        public final boolean assistant;    // an assistant admin added by the main admin
        public final LocalDateTime created = LocalDateTime.now();

        public Account(String role, String name, String studentId, String email, String password,
                       int gradYear) {
            this(role, name, studentId, email, password, gradYear, false);
        }

        public Account(String role, String name, String studentId, String email, String password,
                       int gradYear, boolean assistant) {
            this.role = role;
            this.name = name;
            this.studentId = studentId;
            this.email = email;
            this.password = password.startsWith("pbkdf2$") ? password : hashPassword(password);
            this.gradYear = gradYear;
            this.assistant = assistant;
        }

        /** true when the student graduated at least GAP_YEARS years ago */
        public boolean canBeDeleted() {
            return role.equals("Student") && gradYear > 0
                    && LocalDate.now().getYear() >= gradYear + GAP_YEARS;
        }
    }

    private static final List<Account> accounts = new ArrayList<>();

    static {
        Object saved = CampusLocalStore.loadAccounts();
        if (saved instanceof List<?> list && !list.isEmpty()) {
            for (Object entry : list) {
                if (entry instanceof Account account) accounts.add(account);
            }
        }
        if (accounts.isEmpty()) {
            accounts.add(new Account("Admin", "Admin", "admin", "admin@campus.edu", "admin123", 0));
            saveAccounts();
        }
    }

    /** Passwords are saved as salted PBKDF2 hashes rather than readable strings. */
    private static String hashPassword(String plain) {
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            PBEKeySpec spec = new PBEKeySpec(plain.toCharArray(), salt, 120000, 256);
            try {
                byte[] hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
                return "pbkdf2$120000$" + Base64.getEncoder().encodeToString(salt) + "$"
                        + Base64.getEncoder().encodeToString(hash);
            } finally {
                spec.clearPassword();
            }
        } catch (Exception ex) {
            throw new IllegalStateException("Password hashing is unavailable", ex);
        }
    }

    private static boolean passwordMatches(String entered, String stored) {
        if (!stored.startsWith("pbkdf2$")) return stored.equals(entered); // older local data
        try {
            String[] p = stored.split("\\$");
            byte[] salt = Base64.getDecoder().decode(p[2]);
            byte[] expected = Base64.getDecoder().decode(p[3]);
            PBEKeySpec spec = new PBEKeySpec(entered.toCharArray(), salt,
                    Integer.parseInt(p[1]), expected.length * 8);
            try {
                byte[] actual = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                        .generateSecret(spec).getEncoded();
                return java.security.MessageDigest.isEqual(actual, expected);
            } finally {
                spec.clearPassword();
            }
        } catch (Exception ex) {
            return false;
        }
    }

    public static void saveAccounts() { CampusLocalStore.saveAccounts(new ArrayList<>(accounts)); }

    public static List<Account> accounts() {
        return accounts;
    }

    /** Creates an account. Returns null when it worked, otherwise the message to show. */
    public static String register(String role, String fullName, String id, String email,
                                  String password, String adminCode, String gradYearText) {
        if (fullName.isBlank()) return "Please enter your full name.";
        if (id.isBlank()) return role.equals("Admin") ? "Please enter an admin ID."
                : "Please enter your student ID.";
        if (!email.contains("@") || !email.contains(".")) return "Please enter a valid email address.";
        if (password.length() < 6) return "The password must have at least 6 characters.";
        if (role.equals("Admin")) {
            return "Admin accounts are created by the main admin.";
        }

        int gradYear = 0;
        // Graduation year is no longer collected at student sign-up.
        // Keep 0 for new accounts; old stored values remain untouched.

        for (Account a : accounts) {
            if (a.studentId.equalsIgnoreCase(id)) return "That ID is already registered.";
            if (a.email.equalsIgnoreCase(email)) return "That email is already registered.";
        }

        accounts.add(new Account(role, fullName.trim(), id.trim(), email.trim(), password, gradYear));
        saveAccounts();
        main.audit(fullName.trim(), "User registered", role);
        return null;
    }

    /** Registers with program and year level. No expected-graduation-year field. */
    public static String registerStudent(String fullName, String id, String email, String password,
                                         String confirmPassword, String program, int yearLevel) {
        if (program == null || program.isBlank()) return "Please enter your program or course.";
        if (yearLevel < 1 || yearLevel > 5) return "Please select your year level.";
        if (!password.equals(confirmPassword)) return "The two passwords do not match.";
        String result = register("Student", fullName, id, email, password, "", "");
        if (result != null) return result;
        Account created = accounts.get(accounts.size() - 1);
        created.program = program.trim();
        created.yearLevel = yearLevel;
        saveAccounts();
        return null;
    }

    /** Lookup by stable account ID; never use a mutable full name to identify an account. */
    public static Account findById(String id) {
        if (id == null) return null;
        for (Account a : accounts) if (a.studentId.equalsIgnoreCase(id)) return a;
        return null;
    }

    /** Return an error message, or null after saving a validated profile change. */
    public static String updateStudent(String id, String name, String email, String phone,
                                       String program, int yearLevel, String section) {
        Account user = findById(id);
        if (user == null || !"Student".equals(user.role)) return "Student account not found.";
        if (name == null || name.isBlank()) return "Enter your full name.";
        if (email == null || !email.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+")) return "Enter a valid email address.";
        if (program == null || program.isBlank()) return "Enter your program or course.";
        if (yearLevel < 1 || yearLevel > 5) return "Select a year level from 1 through 5.";
        for (Account a : accounts) {
            if (a == user) continue;
            if (a.email.equalsIgnoreCase(email.strip())) return "Email is already used.";
            if (a.name.equalsIgnoreCase(name.strip())) return "Another account already uses that name.";
        }
        user.name = name.strip();
        user.email = email.strip();
        user.phone = phone == null ? "" : phone.strip();
        user.program = program.strip();
        user.yearLevel = yearLevel;
        user.section = section == null ? "" : section.strip();
        user.updated = LocalDateTime.now();
        saveAccounts();
        return null;
    }

    public static boolean verifyPassword(String id, String plainPassword) {
        Account account = findById(id);
        return account != null && plainPassword != null && passwordMatches(plainPassword, account.password);
    }

    /** The old password is mandatory; never expose stored password hashes in UI. */
    public static String changePassword(String id, String oldPassword, String newPassword, String confirm) {
        Account user = findById(id);
        if (user == null) return "Account not found.";
        if (oldPassword == null || !passwordMatches(oldPassword, user.password)) return "Current password is incorrect.";
        if (newPassword == null || newPassword.length() < 8) return "Use a new password of at least 8 characters.";
        if (!newPassword.equals(confirm)) return "New passwords do not match.";
        user.password = hashPassword(newPassword);
        user.updated = LocalDateTime.now();
        saveAccounts();
        return null;
    }

    public static void updatePhoto(String id, String localUri) {
        Account user = findById(id);
        if (user == null) return;
        user.photoUri = localUri == null ? "" : localUri;
        user.updated = LocalDateTime.now();
        saveAccounts();
    }

    // ---------- assistant admins (only the main admin can add or remove them) ----------
    private static int maxAssistants = 3;

    public static int getMaxAssistants() {
        return maxAssistants;
    }

    public static void setMaxAssistants(int n) {
        maxAssistants = Math.max(1, n);
    }

    public static int assistantCount() {
        int n = 0;
        for (Account a : accounts) {
            if (a.assistant) n++;
        }
        return n;
    }

    /** the built-in admin (not an assistant) */
    public static boolean isMainAdmin(String id) {
        for (Account a : accounts) {
            if (a.role.equals("Admin") && !a.assistant && a.studentId.equalsIgnoreCase(id)) return true;
        }
        return false;
    }

    /** Adds an assistant admin. Returns null when it worked, otherwise the message to show. */
    public static String addAssistant(String fullName, String id, String email, String password) {
        if (assistantCount() >= maxAssistants) {
            return "You already added " + maxAssistants + " assistant admin(s). Raise the limit first.";
        }
        if (fullName.isBlank()) return "Please enter the full name.";
        if (id.isBlank()) return "Please enter an admin ID for the assistant.";
        if (!email.contains("@") || !email.contains(".")) return "Please enter a valid email address.";
        if (password.length() < 6) return "The temporary password must have at least 6 characters.";
        for (Account a : accounts) {
            if (a.studentId.equalsIgnoreCase(id)) return "That ID is already registered.";
            if (a.email.equalsIgnoreCase(email)) return "That email is already registered.";
        }
        accounts.add(new Account("Admin", fullName.trim(), id.trim(), email.trim(), password, 0, true));
        saveAccounts();
        return null;
    }

    /** Log in with the student ID (or admin ID) or the email. Returns null if it does not match. */
    public static Account login(String idOrEmail, String password) {
        for (Account a : accounts) {
            boolean who = a.studentId.equalsIgnoreCase(idOrEmail) || a.email.equalsIgnoreCase(idOrEmail);
            if (who && passwordMatches(password, a.password)) return a;
        }
        return null;
    }

    /**
     * Forgot password: the person proves who they are with the ID and the email of the account,
     * then chooses a new password. (An admin also needs the admin access code.)
     * Returns null when it worked, otherwise the message to show.
     */
    public static String resetPassword(String role, String id, String email, String newPassword,
                                       String confirm, String adminCode) {
        if (id.isBlank() || email.isBlank()) {
            return "Please enter your ID and the email you registered with.";
        }
        if (newPassword.length() < 6) return "The new password must have at least 6 characters.";
        if (!newPassword.equals(confirm)) return "The two passwords do not match.";

        for (Account a : accounts) {
            if (a.role.equals(role) && a.studentId.equalsIgnoreCase(id)
                    && a.email.equalsIgnoreCase(email)) {
                if (role.equals("Admin") && !ADMIN_CODE.equals(adminCode)) {
                    return "The admin access code is not correct.";
                }
                a.password = hashPassword(newPassword);
                saveAccounts();
                main.audit(a.name, "User password reset", role);
                return null;
            }
        }
        return "We could not find an account with that ID and email.";
    }

    public static boolean isAdmin(String username, String password) {
        Account a = login(username, password);
        return a != null && a.role.equals("Admin");
    }
}
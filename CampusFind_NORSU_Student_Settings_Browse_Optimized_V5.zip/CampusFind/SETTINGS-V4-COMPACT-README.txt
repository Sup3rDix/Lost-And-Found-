CampusFind — NORSU Compact Settings V4 (2026-11-18)
===================================================
Based on: CampusFind_NORSU_Settings_Profile_Sync_V3.zip

CHANGES
- Admin Settings now opens a compact four-column overview: Account & Security,
  Notifications & KITA AI, Claim & Item Policies, Assistant Admins, and Backup.
- Student Settings now opens a profile/academic summary and four clickable
  settings categories: Notifications, Messenger, Privacy/Security, Accessibility.
- The overview is designed to fit without a scrollbar at normal desktop sizes;
  the window's main scrollbar remains available at unusually small sizes.
- Full student profile edits, detailed notifications and Messenger settings,
  accessibility options, and security settings now live in focused category pages.
- Change Profile Photo returns to the edit profile page.
- Admin overview controls are functional: password change, saved notification
  switches, existing unclaimed-item rule, manage assistants, CSV export, backups.
- No theme switcher was added. The NORSU logo and campus images remain unchanged.
- The underlying local-profile sync, account security checks, reports, claims,
  chat system, and KITA AI are retained.

LIMITATIONS
- Settings and profile records are local to this computer; sharing/synchronizing
  across separate computers requires a shared backend.
- Claim deadlines/pickup schedules remain managed in the existing Claims flow;
  no new unimplemented deadline features or 2FA controls were added.
- Full JavaFX compilation/runtime validation was unavailable in the build
  environment because Maven Central could not be reached.

HOW TO RUN ON WINDOWS 11
1. Extract the project ZIP.
2. Open PowerShell in the CampusFind folder.
3. Run: .\mvnw.cmd clean javafx:run
4. Test Student Settings and Admin Settings at your actual screen size.

TEST CHECKLIST
[ ] Admin Settings opens without a vertical scrollbar at standard resolution.
[ ] Admin password change rejects incorrect current password.
[ ] Admin notification settings persist after restart.
[ ] Main admin can save unclaimed-item period and export/back up records.
[ ] Assistant admin cannot edit main-admin-only policies.
[ ] Student profile summary displays saved image, course and year level.
[ ] Edit Profile opens full editor and saves updated details.
[ ] Admin > Manage Users > View Profile sees those saved updates.
[ ] Messenger notification preferences persist on this computer.
[ ] Smaller windows can still scroll instead of clipping content.

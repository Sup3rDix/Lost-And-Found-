@echo off
setlocal
cd /d "%~dp0"
call mvnw.cmd clean javafx:run
if errorlevel 1 (
  echo.
  echo CampusFind could not start. Check the Maven message above.
  echo This project needs JDK 21 and internet access for its first Maven download.
  pause
  exit /b 1
)

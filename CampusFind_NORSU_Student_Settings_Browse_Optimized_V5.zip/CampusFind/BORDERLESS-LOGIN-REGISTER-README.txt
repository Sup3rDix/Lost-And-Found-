CampusFind — Borderless Login & Student Registration (NORSU)
==========================================================

Design update (18 November 2026):
- Login and registration now use an unboxed, centered transparent layout.
- The source campus main-building photo remains full-screen.
- The exact NORSU seal already included in the project is retained.
- A soft background blur and full-screen radial blue tint replace the old
  bordered rectangular glass card. There is no form panel border or shadow.
- Text fields have soft translucent pill surfaces for readability.
- Buttons and links retain the approved blue/white/yellow color scheme.
- Registration retains the student name, ID, Program/Course, Year Level,
  Expected Graduation Year, email, password and confirm-password fields.
- Existing registration/login handlers and account validation are preserved.
- Forgot Password also inherits the borderless form styling.
- The photo chooser remains available on the authentication screen.
- No Admin/Student dashboard or Messenger source files were changed.

Files changed:
  src/main/java/com/example/campuslostandfounditem/HelloApplication.java
  src/main/resources/com/example/campuslostandfounditem/campus.css

Windows 11:
  1. Extract ZIP and open PowerShell in CampusFind.
  2. Run: .\mvnw.cmd clean javafx:run

Requirements: Java 21 and Maven downloads/JavaFX dependencies (first run
requires network access if not cached).

Validation: Static source checks and ZIP integrity test were performed.
The full JavaFX application could not be compiled/launched in the build
container because the Maven dependency server is not reachable.
